class_name Ui
extends RefCounted
## Small UI toolkit: one consistent glass/neon look for every menu screen.

const BG := Color(0.03, 0.045, 0.08)
const PANEL := Color(0.05, 0.075, 0.12, 0.82)
const ACCENT := Color(0.10, 0.82, 1.0)
const HOT := Color(1.0, 0.48, 0.10)
const GOOD := Color(0.30, 0.95, 0.45)
const GOLD := Color(1.0, 0.82, 0.25)
const DIM := Color(0.62, 0.70, 0.80)


static func box(c: Color, radius: int = 10, border: Color = Color(1, 1, 1, 0.0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(radius)
	if bw > 0:
		s.border_color = border
		s.set_border_width_all(bw)
	s.content_margin_left = 18
	s.content_margin_right = 18
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


static func label(text: String, size: int = 22, color: Color = Color.WHITE, bold_outline: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if bold_outline:
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		l.add_theme_constant_override("outline_size", 6)
	return l


## Brand lock-up  LEMOV | CAR GAMES  (size = font size of the big word)
static func logo(size: int = 120) -> HBoxContainer:
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", int(size * 0.15))
	hb.add_child(label("LEMOV", size, Color.WHITE, true))
	var bar := ColorRect.new()
	bar.color = HOT
	bar.custom_minimum_size = Vector2(maxf(4.0, size * 0.045), size * 0.72)
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(bar)
	var sub := label("CAR\nGAMES", int(size * 0.31), HOT, true)
	sub.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sub.add_theme_constant_override("line_spacing", -int(size * 0.05))
	hb.add_child(sub)
	return hb


static func panel(color: Color = PANEL, radius: int = 18) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", box(color, radius, Color(1, 1, 1, 0.10), 1))
	return p


static func button(text: String, cb: Callable, accent: Color = ACCENT, size: int = 26, min_size: Vector2 = Vector2(300, 64)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_color_override("font_color", Color(0.92, 0.96, 1.0))
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", accent)
	b.add_theme_stylebox_override("normal", _btn_box(Color(0.06, 0.09, 0.15, 0.78), accent, false))
	b.add_theme_stylebox_override("hover", _btn_box(Color(0.10, 0.18, 0.28, 0.92), accent, true))
	b.add_theme_stylebox_override("pressed", _btn_box(accent.darkened(0.55), accent, true))
	b.add_theme_stylebox_override("disabled", _btn_box(Color(0.05, 0.06, 0.08, 0.6), Color(0.3, 0.3, 0.3), false))
	b.pressed.connect(func():
		G.ui("ui_click")
		cb.call())
	b.mouse_entered.connect(func():
		G.ui("ui_select", -16.0)
		var t := b.create_tween()
		t.tween_property(b, "scale", Vector2(1.03, 1.03), 0.1)
	)
	b.mouse_exited.connect(func():
		var t := b.create_tween()
		t.tween_property(b, "scale", Vector2.ONE, 0.12)
	)
	b.resized.connect(func(): b.pivot_offset = b.size * 0.5)
	return b


static func _btn_box(c: Color, accent: Color, hot: bool) -> StyleBoxFlat:
	var s := box(c, 8, accent if hot else Color(1, 1, 1, 0.12), 2 if hot else 1)
	s.border_width_left = 7 if hot else 4
	s.border_color = accent if hot else accent.darkened(0.2)
	s.content_margin_left = 24
	s.shadow_color = Color(accent.r, accent.g, accent.b, 0.35 if hot else 0.0)
	s.shadow_size = 10 if hot else 0
	return s


static func bar(value: float, color: Color = ACCENT, w: float = 220.0) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(w, 14)
	c.draw.connect(func():
		c.draw_rect(Rect2(0, 3, w, 8), Color(1, 1, 1, 0.10))
		c.draw_rect(Rect2(0, 3, w * clampf(value, 0.0, 1.0), 8), color)
		for i in range(1, 10):
			c.draw_rect(Rect2(w * float(i) / 10.0 - 1, 3, 2, 8), Color(0, 0, 0, 0.45))
	)
	return c


static func stat_row(name: String, value: float, color: Color = ACCENT) -> HBoxContainer:
	var h := HBoxContainer.new()
	var l := label(name, 18, DIM)
	l.custom_minimum_size = Vector2(180, 0)
	h.add_child(l)
	h.add_child(bar(value, color))
	return h


static func slider_row(name: String, vmin: float, vmax: float, val: float, step: float, cb: Callable, fmt: String = "%d%%", scale: float = 100.0) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 16)
	var l := label(name, 22, Color(0.9, 0.95, 1.0))
	l.custom_minimum_size = Vector2(250, 0)
	h.add_child(l)
	var sl := HSlider.new()
	sl.min_value = vmin
	sl.max_value = vmax
	sl.step = step
	sl.value = val
	sl.custom_minimum_size = Vector2(320, 36)
	sl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sl.add_theme_stylebox_override("slider", box(Color(1, 1, 1, 0.12), 4))
	sl.add_theme_stylebox_override("grabber_area", box(ACCENT.darkened(0.2), 4))
	sl.add_theme_stylebox_override("grabber_area_highlight", box(ACCENT, 4))
	h.add_child(sl)
	var v := label(fmt % (val * scale), 22, ACCENT)
	v.custom_minimum_size = Vector2(90, 0)
	h.add_child(v)
	sl.value_changed.connect(func(x: float):
		v.text = fmt % (x * scale)
		cb.call(x))
	return h


static func toggle_row(name: String, on: bool, cb: Callable) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 16)
	var l := label(name, 22, Color(0.9, 0.95, 1.0))
	l.custom_minimum_size = Vector2(250, 0)
	h.add_child(l)
	var b := CheckButton.new()
	b.button_pressed = on
	b.focus_mode = Control.FOCUS_NONE
	b.toggled.connect(func(x: bool):
		G.ui("ui_click")
		cb.call(x))
	h.add_child(b)
	return h


static func choice_row(name: String, options: Array, current: int, cb: Callable) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	var l := label(name, 22, Color(0.9, 0.95, 1.0))
	l.custom_minimum_size = Vector2(250, 0)
	h.add_child(l)
	var btns: Array = []
	for i in options.size():
		var b := Button.new()
		b.text = options[i]
		b.toggle_mode = true
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(110, 48)
		b.add_theme_font_size_override("font_size", 20)
		b.add_theme_stylebox_override("normal", box(Color(0.07, 0.1, 0.16, 0.9), 8, Color(1, 1, 1, 0.14), 1))
		b.add_theme_stylebox_override("hover", box(Color(0.12, 0.2, 0.3, 0.95), 8, ACCENT, 1))
		b.add_theme_stylebox_override("pressed", box(ACCENT.darkened(0.45), 8, ACCENT, 2))
		b.button_pressed = i == current
		btns.append(b)
		h.add_child(b)
	for i in btns.size():
		(btns[i] as Button).pressed.connect(func():
			G.ui("ui_click")
			for j in btns.size():
				(btns[j] as Button).button_pressed = j == i
			cb.call(i))
	return h


static func fade_in(n: Control, delay: float = 0.0, dx: float = -60.0) -> void:
	n.modulate.a = 0.0
	var base := n.position
	n.position = base + Vector2(dx, 0)
	var t := n.create_tween().set_parallel(true)
	t.tween_property(n, "modulate:a", 1.0, 0.45).set_delay(delay)
	t.tween_property(n, "position", base, 0.5).set_delay(delay).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


static func stars(n: int, size: int = 28) -> Label:
	var s := ""
	for i in 3:
		s += "★" if i < n else "☆"
	return label(s, size, GOLD if n > 0 else DIM)
