class_name LoadingScreen
extends CanvasLayer
## Full-screen loading card with tips and an animated progress bar.

const TIPS := [
	"Hold the handbrake into a corner to start a drift. Link slides for combo multipliers.",
	"Nitro empties fast and refills while you drive. Use it on straights.",
	"Press C to cycle camera: chase, far chase and cockpit. Wheel or pinch zooms each view.",
	"Wet roads have less grip. Brake earlier in the rain.",
	"The day lasts 48 minutes: building lights and street lamps turn on by themselves at dusk.",
	"Crashes dent the body for real. Reset the car with R to repair it.",
	"Missions pay credits. Spend them in the garage on new cars.",
]
var bar: ColorRect
var fill: ColorRect
var pct := 0.0
var status: Label


func _ready() -> void:
	layer = 60
	process_mode = Node.PROCESS_MODE_ALWAYS
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.03, 0.055)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var t1 := Ui.logo(140)
	t1.position = Vector2(100, 120)
	add_child(t1)
	var t2 := Ui.label("OPEN WORLD  •  REAL PHYSICS  •  DAY & NIGHT", 26, Ui.DIM)
	t2.position = Vector2(108, 310)
	add_child(t2)
	var tip := Ui.label("TIP  " + TIPS[randi() % TIPS.size()], 24, Ui.DIM)
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.custom_minimum_size = Vector2(900, 0)
	tip.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	add_child(tip)
	tip.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 100)
	tip.position.y -= 70
	status = Ui.label("LOADING WORLD...", 24, Color.WHITE)
	status.position = Vector2(100, 420)
	add_child(status)
	bar = ColorRect.new()
	bar.color = Color(1, 1, 1, 0.1)
	bar.position = Vector2(100, 470)
	bar.size = Vector2(900, 10)
	add_child(bar)
	fill = ColorRect.new()
	fill.color = Ui.ACCENT
	fill.size = Vector2(0, 10)
	bar.add_child(fill)


func set_progress(p: float, text: String = "") -> void:
	pct = p
	fill.size.x = 900.0 * clampf(p, 0.0, 1.0)
	if text != "":
		status.text = text


func finish() -> void:
	var t := create_tween()
	t.tween_property(self, "offset:y", 0.0, 0.01)
	for c in get_children():
		if c is CanvasItem:
			t.parallel().tween_property(c, "modulate:a", 0.0, 0.5)
	t.tween_callback(queue_free)
