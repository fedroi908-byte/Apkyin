class_name EngineSound
extends Node3D
## One car's engine sound: RPM-band loops (on / off throttle) cross-faded by rpm, turbo whistle + blow-off, supercharger, gear whine, intake roar,
## hybrid motor, overrun pops, shift sounds, rev limiter and damage (knock, misfire, dying engine). The player's car is plain stereo on the "Car"
## bus, bots are positional (AudioStreamPlayer3D with Doppler) children of their own car. Sounds: SoundBank / tools/gen_all.py.

static var active := 0                # playing layers (all engines), limited by `cap` (set per quality tier)
static var cap := 28


class Lay extends RefCounted:
	var pl: Variant
	var on := false
	var span := 1.0
	var prio := 1

	func put(vol: float, pitch: float) -> void:
		if vol < 0.004:
			if on:
				pl.stop()
				on = false
				EngineSound.active -= 1
			return
		if not on:
			if prio > 0 and EngineSound.active >= EngineSound.cap:
				return
			pl.play(randf() * span)
			on = true
			EngineSound.active += 1
		pl.volume_db = linear_to_db(vol)
		pl.pitch_scale = clampf(pitch, 0.05, 4.0)

	func kill() -> void:
		if on:
			pl.stop()
			on = false
			EngineSound.active -= 1


var car: Vehicle
var mgr: Node
var prof: Dictionary = {}
var spatial := false
var lite := false
var bus := "Car"
var ok := false
var _dop := false
var _on: Array = []
var _off: Array = []
var _on_rpm := PackedFloat32Array()
var _off_rpm := PackedFloat32Array()
var _x := {}
var _idle := 800.0
var _red := 7000.0
var _pitch := 1.0
var _gain := 1.0
var _ev := false
var _thr := 0.0
var _boost := 0.0
var _alive := 1.0
var _dead := false
var _t := 0.0
var _gear := 1
var _lim_t := 0.0
var _gate := 1.0
var _pop_cd := 0.0
var _lift_t := 9.0
var _bov_cd := 0.0
var _mf := 0.0
var _was_gas := 0.0


func setup(c: Vehicle, p: Dictionary, sp: bool, lt: bool, m: Node, dop: bool) -> void:
	car = c
	prof = p
	spatial = sp
	lite = lt
	mgr = m
	_dop = dop
	bus = "World" if sp else "Car"
	var vc := SoundBank.voice(String(prof.get("v", "i6_bmw")))
	if not bool(vc["ok"]):
		return
	_ev = String(prof.get("v", "")) == "ev"
	_idle = float(prof.get("idle", vc["idle"]))
	_red = float(prof.get("red", vc["red"]))
	_pitch = float(prof.get("pitch", 1.0)) * (randf_range(0.97, 1.03) if sp else 1.0)
	_gain = float(prof.get("gain", 1.0))
	for b in (vc["on"] as Array):
		var L := _mk(b["s"] as AudioStreamWAV, 0)
		if L != null:
			_on.append(L)
			_on_rpm.append(float(b["rpm"]))
	if not lite:
		for b in (vc["off"] as Array):
			var L := _mk(b["s"] as AudioStreamWAV, 0)
			if L != null:
				_off.append(L)
				_off_rpm.append(float(b["rpm"]))
	ok = not _on.is_empty()
	if not lite:
		var t := String(prof.get("turbo", ""))
		if t != "" and float(prof.get("boost", 0.0)) > 0.0:
			_lazy("turbo", t)
		if float(prof.get("sc", 0.0)) > 0.0:
			_lazy("blower", "blower")
		if float(prof.get("gear", 0.0)) > 0.0:
			_lazy("gear", "gear_whine")
		if float(prof.get("intake", 0.0)) > 0.0 and not _ev:
			_lazy("intake", "intake_roar")
		if float(prof.get("motor", 0.0)) > 0.0:
			_lazy("motor", "motor_hyb")


func _mk(s: AudioStreamWAV, prio: int = 1) -> Lay:
	if s == null:
		return null
	var L := Lay.new()
	var pl: Variant
	if spatial:
		var q := AudioStreamPlayer3D.new()
		q.max_distance = 170.0
		q.unit_size = 11.0
		q.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
		q.attenuation_filter_cutoff_hz = 5200.0
		q.panning_strength = 1.0
		q.doppler_tracking = AudioStreamPlayer3D.DOPPLER_TRACKING_PHYSICS_STEP if _dop else AudioStreamPlayer3D.DOPPLER_TRACKING_DISABLED
		pl = q
	else:
		pl = AudioStreamPlayer.new()
	pl.stream = s
	pl.bus = bus
	pl.volume_db = -60.0
	add_child(pl)
	L.pl = pl
	L.prio = prio
	L.span = maxf(s.get_length() - 0.05, 0.1)
	return L


func _lazy(key: String, wav_name: String) -> Lay:
	if _x.has(key):
		return _x[key]
	var L := _mk(SoundBank.wav(wav_name, true), 1)
	_x[key] = L
	return L


func _px(key: String, vol: float, pitch: float) -> void:
	var L: Lay = _x.get(key)
	if L != null:
		L.put(vol, pitch)


## Cross-fades the two bands around rpm R (equal power); every other band is stopped.
func _xf(layers: Array, rpms: PackedFloat32Array, R: float, vol: float) -> void:
	var n := rpms.size()
	if n == 0:
		return
	var j := 0
	while j < n - 1 and R >= rpms[j + 1]:
		j += 1
	var w0 := 1.0
	var w1 := 0.0
	if j < n - 1 and R > rpms[j]:
		var t := log(R / rpms[j]) / log(rpms[j + 1] / rpms[j])
		w0 = cos(t * 1.5708)
		w1 = sin(t * 1.5708)
	for i in n:
		var L: Lay = layers[i]
		if i == j:
			L.put(vol * w0, R / rpms[i])
		elif i == j + 1:
			L.put(vol * w1, R / rpms[i])
		else:
			L.put(0.0, 1.0)


func update(dt: float, mul: float) -> void:
	if not ok or car == null or not is_instance_valid(car):
		return
	_t += dt
	var rn: float = car.rpm
	var gas: float = car.in_gas
	_thr = move_toward(_thr, gas, dt * (8.0 if gas > _thr else 4.5))
	var d: CarDamage = car.dmg
	var dead := d.exploded or d.fuel <= 0.0
	if dead != _dead:
		_dead = dead
		if dead:
			if not spatial and mgr != null:
				mgr.call("shot", SoundBank.pick("pop", 4), -8.0, 0.8)
		else:
			_alive = -1.0
			if not spatial and mgr != null:
				mgr.call("shot", "start", -7.0, 1.0)
	if _dead:
		_alive = maxf(_alive - dt * 1.5, 0.0)
	else:
		_alive = minf(_alive + dt * 0.9, 1.0)
	var alive := maxf(_alive, 0.0)
	var eh := d.engine
	var R := lerpf(_idle, _red, rn) * _pitch * (1.0 + eh * 0.018 * sin(_t * 43.0))
	# rev limiter: the fuel cut makes the sound stutter at ~11 Hz
	var lim := 1.0
	if rn > 0.985 and gas > 0.6 and not _ev:
		_lim_t += dt
		lim = 0.35 if fmod(_lim_t * 11.5, 1.0) < 0.42 else 1.0
		R *= 1.0 - 0.012 * (1.0 - _gate)
	else:
		_lim_t = 0.0
	_gate = move_toward(_gate, lim, dt * 30.0)
	# misfire: random short dropouts of a damaged engine
	var miss := 1.0
	if _mf > 0.0:
		_mf -= dt
		miss = 0.3
	elif eh > 0.35 and randf() < dt * (eh - 0.25) * 4.0:
		_mf = randf_range(0.06, 0.16)
	var lvl := lerpf(0.5, 1.0, pow(rn, 0.55)) * mul * _gain * (1.0 + 0.3 * d.rear()) * alive * _gate * miss
	var off := 0.0 if lite else (1.0 - _thr) * smoothstep(0.05, 0.22, rn)
	_xf(_on, _on_rpm, R, lvl * cos(off * 1.5708) * (0.75 + 0.25 * _thr))
	if not lite and not _off.is_empty():
		_xf(_off, _off_rpm, R, lvl * sin(off * 1.5708) * 0.9)
	if not lite:
		_extras(dt, rn, gas, R, alive * mul * _gain, eh, d)
	_was_gas = gas


func _extras(dt: float, rn: float, gas: float, R: float, v: float, eh: float, d: CarDamage) -> void:
	var kmh: float = car.kmh()
	# turbo whistle, blow-off valve
	if _x.has("turbo"):
		var tg := _thr * smoothstep(0.18, 0.7, rn)
		_boost += (tg - _boost) * clampf(dt * (1.7 if tg > _boost else 4.0), 0.0, 1.0)
		_px("turbo", float(prof["boost"]) * pow(_boost, 1.25) * 0.55 * v, 0.5 + 1.5 * clampf(0.3 * _boost + 0.7 * rn, 0.0, 1.0))
		_bov_cd -= dt
		var bov := String(prof.get("bov", ""))
		if bov != "" and _was_gas > 0.5 and gas < 0.15 and _boost > 0.42 and _bov_cd <= 0.0 and mgr != null:
			_bov_cd = 0.9
			mgr.call("shot", bov, -9.0 + 6.0 * _boost, randf_range(0.95, 1.06))
			_boost *= 0.3
	# supercharger whine follows the engine speed
	var sc := float(prof.get("sc", 0.0))
	if sc > 0.0:
		_px("blower", sc * lerpf(0.3, 1.0, _thr) * smoothstep(0.0, 0.12, rn + 0.06) * 0.5 * v, R / 3000.0)
	var gw := float(prof.get("gear", 0.0))
	if gw > 0.0:
		_px("gear", gw * clampf(kmh / 40.0, 0.0, 1.0) * (0.4 + 0.6 * _thr) * 0.35 * v, 0.4 + kmh / 110.0)
	var ik := float(prof.get("intake", 0.0))
	if ik > 0.0 and not _ev:
		_px("intake", ik * pow(_thr, 1.4) * smoothstep(0.1, 0.5, rn) * 0.5 * v, 0.6 + rn * 1.2)
	var mt := float(prof.get("motor", 0.0))
	if mt > 0.0:
		_px("motor", mt * (0.25 + 0.75 * _thr) * clampf(kmh / 25.0, 0.0, 1.0) * 0.45 * v, 0.5 + kmh / 160.0)
	if eh > 0.3:
		_lazy("knock", "knock")
		_px("knock", smoothstep(0.3, 0.85, eh) * (0.3 + 0.7 * rn) * 0.65 * (0.4 + 0.6 * float(not _dead)), 0.55 + 1.1 * rn)
	elif _x.has("knock"):
		_px("knock", 0.0, 1.0)
	if mgr == null or _ev:
		return
	# overrun pops and lift-off crackle
	_pop_cd -= dt
	if gas > 0.3:
		_lift_t = 0.0
	else:
		_lift_t += dt
	var pp := float(prof.get("pop", 0.2)) * (1.0 + d.rear())
	if gas < 0.08 and rn > 0.38 and _lift_t < 2.4 and _pop_cd <= 0.0 and not _dead:
		_pop_cd = randf_range(0.06, 0.3)
		if randf() < pp * rn * 0.8:
			mgr.call("shot", SoundBank.pick("pop", 4), -11.0 + rn * 5.0, randf_range(0.88, 1.12))
	if _was_gas > 0.5 and gas < 0.1 and rn > 0.5 and randf() < pp * 0.6 and not _dead:
		mgr.call("shot", SoundBank.pick("crackle", 2), -10.0, randf_range(0.92, 1.08))
	# gear shifts
	var g: int = car.gear
	if g != _gear:
		if g > _gear and gas > 0.35:
			mgr.call("shot", "shift1", -12.0, randf_range(0.92, 1.08))
			if randf() < float(prof.get("shiftpop", 0.2)):
				mgr.call("shot", SoundBank.pick("pop", 4), -10.0, randf_range(0.9, 1.1))
			_boost *= 0.7
		elif g < _gear and rn > 0.2:
			mgr.call("shot", "downshift", -13.0, randf_range(0.92, 1.08))
		_gear = g


func _exit_tree() -> void:
	for L in _on:
		(L as Lay).kill()
	for L in _off:
		(L as Lay).kill()
	for k in _x:
		var L: Lay = _x[k]
		if L != null:
			L.kill()
