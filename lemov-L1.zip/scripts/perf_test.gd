extends Node
## Perf harness: user args <quality> <car idx> <seconds> [mode]. Prints draw calls / primitives / script time per 2 s.
var gw: GameWorld
var t := 0.0
var nxt := 3.0
var secs := 12.0
var frames := 0
func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	G.quality = int(a[0]) if a.size() > 0 else 0
	G.selected_car = int(a[1]) if a.size() > 1 else 0
	secs = float(a[2]) if a.size() > 2 else 12.0
	G.start_hour = 11.0
	G.fps_limit_enabled = false
	Q.apply(get_viewport())
	gw = GameWorld.new()
	add_child(gw)
func _physics_process(dt: float) -> void:
	t += dt
	if t > 0.5:
		gw.touch["gas"] = true
func _process(_dt: float) -> void:
	frames += 1
	if t > nxt:
		nxt += 3.0
		var p := gw.player
		print("PERF q=%d t=%d kmh=%d fps=%d proc=%.1fms phys=%.1fms dc=%d prim=%dk obj=%d nodes=%d mem=%dMB vram=%dMB" % [G.quality, int(t), int(p.kmh()), int(Engine.get_frames_per_second()),
			Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0, Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0,
			int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)), int(Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME) / 1000.0),
			int(Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME)), int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)),
			int(Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0), int(Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED) / 1048576.0)])
	if t > secs:
		get_tree().quit()
