class_name TerrainClipmap
extends Node3D
## Geometry clip-map: concentric rings of a fixed grid that follow the camera; heights come
## from the heightmap texture in the vertex shader (no per-vertex work on the CPU).

const LEVELS := 7

var material: ShaderMaterial
var level_nodes: Array[Node3D] = []         # one Node3D per level holding 4 quadrant meshes (frustum culled separately)
var grid := 96                                # cells per side for every level (quality tier)
var cells: Array[float] = []


func _ready() -> void:
	material = ShaderMaterial.new()
	material.shader = load("res://shaders/terrain.gdshader")
	material.set_shader_parameter("heightmap", ImageTexture.create_from_image(W.hm_image))
	material.set_shader_parameter("splat", ImageTexture.create_from_image(W.splat_image))
	material.set_shader_parameter("world_size", W.size)
	material.set_shader_parameter("hn", float(W.n))
	material.set_shader_parameter("hmin", W.hmin)
	material.set_shader_parameter("hrange", W.hmax - W.hmin)
	var T := "res://assets/textures/"
	material.set_shader_parameter("grass_a", load(T + "grass_albedo.png"))
	material.set_shader_parameter("grass_n", load(T + "grass_normal.png"))
	material.set_shader_parameter("rock_a", load(T + "rock_albedo.png"))
	material.set_shader_parameter("rock_n", load(T + "rock_normal.png"))
	material.set_shader_parameter("sand_a", load(T + "sand_albedo.png"))
	material.set_shader_parameter("sand_n", load(T + "sand_normal.png"))
	material.set_shader_parameter("pave_a", load(T + "pavement_albedo.png"))
	material.set_shader_parameter("pave_n", load(T + "pavement_normal.png"))
	grid = int(Q.get_v("terrain_grid"))
	var base: float = Q.get_v("terrain_cell")
	for k in LEVELS:
		var c := base * pow(2.0, k)
		cells.append(c)
		var lv := Node3D.new()
		var mat := material.duplicate() as ShaderMaterial
		mat.set_shader_parameter("cell", c)
		for qd in 4:
			var mi := MeshInstance3D.new()
			mi.mesh = _build_quad(c, k > 0, qd)
			mi.material_override = mat
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			mi.gi_mode = GeometryInstance3D.GI_MODE_DISABLED
			lv.add_child(mi)
		add_child(lv)
		level_nodes.append(lv)


## One quarter of a clip-map level (so the half behind the camera is frustum-culled). Vertices keep level-centred coordinates.
func _build_quad(c: float, hole: bool, qd: int) -> ArrayMesh:
	var half := grid / 2
	var i0 := (qd % 2) * half
	var j0 := (qd / 2) * half
	var nx := half + 1
	var verts := PackedVector3Array()
	var cols := PackedColorArray()
	verts.resize(nx * nx)
	cols.resize(nx * nx)
	var ctr := grid * 0.5
	for j in nx:
		for i in nx:
			verts[j * nx + i] = Vector3((i0 + i - ctr) * c, 0.0, (j0 + j - ctr) * c)
			cols[j * nx + i] = Color(0, 0, 0, 1)
	var idx := PackedInt32Array()
	var h0 := grid / 4
	var h1 := grid - grid / 4
	var skirt_edges: Array = []
	for j in range(j0, j0 + half):
		for i in range(i0, i0 + half):
			if hole and i >= h0 and i < h1 and j >= h0 and j < h1:
				continue
			var a := (j - j0) * nx + (i - i0)
			var b := a + 1
			var d := a + nx
			var e := d + 1
			idx.append_array([a, d, b, b, d, e])
			if i == 0:
				skirt_edges.append([a, d])
			if i == grid - 1:
				skirt_edges.append([b, e])
			if j == 0:
				skirt_edges.append([a, b])
			if j == grid - 1:
				skirt_edges.append([d, e])
			if hole:
				if i == h0 - 1 and j >= h0 and j < h1:
					skirt_edges.append([b, e])
				if i == h1 and j >= h0 and j < h1:
					skirt_edges.append([a, d])
				if j == h0 - 1 and i >= h0 and i < h1:
					skirt_edges.append([d, e])
				if j == h1 and i >= h0 and i < h1:
					skirt_edges.append([a, b])
	var remap := {}
	for ed in skirt_edges:
		for v in ed:
			if not remap.has(v):
				remap[v] = verts.size()
				verts.append(verts[v])
				cols.append(Color(1, 0, 0, 1))
		idx.append_array([ed[0], remap[ed[0]], ed[1], ed[1], remap[ed[0]], remap[ed[1]]])
	var mesh := ArrayMesh.new()
	if idx.is_empty():
		return mesh
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = idx
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.custom_aabb = AABB(Vector3((i0 - ctr) * c - c * 6.0, -150.0, (j0 - ctr) * c - c * 6.0), Vector3(half * c + c * 12.0, 1400.0, half * c + c * 12.0))
	return mesh


func follow(p: Vector3) -> void:
	for k in LEVELS:
		var snap := cells[k] * 2.0
		level_nodes[k].position = Vector3(floor(p.x / snap) * snap, 0.0, floor(p.z / snap) * snap)
