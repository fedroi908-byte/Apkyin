class_name SoundBank
extends RefCounted
## Loads and caches the generated sounds (assets/audio/v2, built by tools/gen_all.py): engine packs (every RPM band of a voice in one WAV),
## loops, one-shots and the per-car sound profiles (data/audio_bank.json). Missing files never raise errors, they only end up in `misses`.

const DIR := "res://assets/audio/v2/"
static var _meta: Dictionary = {}
static var _loaded := false
static var _cache: Dictionary = {}
static var _voices: Dictionary = {}
static var misses: Array = []


static func meta() -> Dictionary:
	if not _loaded:
		_loaded = true
		if FileAccess.file_exists("res://data/audio_bank.json"):
			var f := FileAccess.open("res://data/audio_bank.json", FileAccess.READ)
			if f != null:
				var j: Variant = SafeIO.parse(f.get_as_text())
				if j is Dictionary:
					_meta = j
	return _meta


@warning_ignore("integer_division")
static func frames(s: AudioStreamWAV) -> int:
	var bytes := 2 if s.format == AudioStreamWAV.FORMAT_16_BITS else 1
	return s.data.size() / (bytes * (2 if s.stereo else 1))


## A generated sound by name (assets/audio/v2/<name>.wav). `loop` returns a looping copy.
static func wav(name: String, loop: bool = false) -> AudioStreamWAV:
	return _load_wav(DIR + name + ".wav", name, loop)


## One of the older sounds (assets/audio/<name>.wav: music, ambience, ui, jingles).
static func old(name: String, loop: bool = false) -> AudioStreamWAV:
	return _load_wav("res://assets/audio/%s.wav" % name, "old:" + name, loop)


static func _load_wav(path: String, key: String, loop: bool) -> AudioStreamWAV:
	var k := key + ("|L" if loop else "")
	if _cache.has(k):
		return _cache[k]
	var s: AudioStreamWAV = null
	if ResourceLoader.exists(path):
		var base := load(path) as AudioStreamWAV
		if base != null:
			s = base
			if loop:
				s = base.duplicate() as AudioStreamWAV
				s.loop_mode = AudioStreamWAV.LOOP_FORWARD
				s.loop_begin = 0
				s.loop_end = frames(s)
	if s == null:
		misses.append(key)
	_cache[k] = s
	return s


## Engine voice: {on: [{rpm, s}], off: [{rpm, s}], idle, red, ok}. Bands are 1 s seamless loops cut out of one WAV.
static func voice(name: String) -> Dictionary:
	if _voices.has(name):
		return _voices[name]
	var res := {"on": [], "off": [], "idle": 800.0, "red": 7000.0, "ok": false}
	var m: Dictionary = (meta().get("voices", {}) as Dictionary).get(name, {})
	if not m.is_empty():
		var path := DIR + String(m["file"]) + ".wav"
		var base: AudioStreamWAV = load(path) as AudioStreamWAV if ResourceLoader.exists(path) else null
		if base != null and base.format == AudioStreamWAV.FORMAT_16_BITS:
			var d: PackedByteArray = base.data
			var n0 := int(m["n"])
			var pos := 0                      # byte offset of the next band (bands differ in length: the low rpm ones are 2 s)
			for kind in ["on", "off"]:
				var rl: Array = m[kind]
				var nl: Array = m.get(kind + "_n", [])
				for i in rl.size():
					var n := int(nl[i]) if i < nl.size() else n0
					if pos + n * 2 > d.size():
						break
					var s := AudioStreamWAV.new()
					s.format = AudioStreamWAV.FORMAT_16_BITS
					s.mix_rate = int(m["rate"])
					s.stereo = false
					s.data = d.slice(pos, pos + n * 2)
					s.loop_mode = AudioStreamWAV.LOOP_FORWARD
					s.loop_begin = 0
					s.loop_end = n
					(res[kind] as Array).append({"rpm": float(rl[i]), "s": s})
					pos += n * 2
			res["idle"] = float(m["idle"])
			res["red"] = float(m["red"])
			res["ok"] = not (res["on"] as Array).is_empty()
	if not bool(res["ok"]):
		misses.append("voice:" + name)
	_voices[name] = res
	return res


## Sound profile of a car (voice, rev range, turbo / blower / pops ...). Unknown cars fall back by physics class.
static func profile(car_id: String, phys: String = "") -> Dictionary:
	var m := meta()
	var cars: Dictionary = m.get("cars", {})
	if cars.has(car_id):
		return cars[car_id]
	var fb := String((m.get("phys", {}) as Dictionary).get(phys, m.get("default", "bmw_m4")))
	return cars.get(fb, {})


static func pick(prefix: String, n: int) -> String:
	return "%s%d" % [prefix, 1 + randi() % maxi(n, 1)]
