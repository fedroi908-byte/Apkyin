extends Node
## Dev tool (headless, real time): drives GameAudio with a fake car through idle / rev sweep / shifts / lift / limiter / damage / death / restart and records the master bus.
## usage: audio_sim.tscn -- <car id> <out.wav>
var car: Vehicle
var au: GameAudio
var rec: AudioEffectRecord
var t := 0.0
var cid := "rosso"
var out := "/tmp/claude-0/aud_sim.wav"
var fin := false


func _ready() -> void:
	Engine.max_fps = 60
	var a := OS.get_cmdline_user_args()
	if a.size() > 0:
		cid = a[0]
	if a.size() > 1:
		out = a[1]
	G.mode = "free"
	car = Vehicle.new()
	car.stats = {"id": cid}
	car.freeze = true
	car.process_mode = Node.PROCESS_MODE_DISABLED
	add_child(car)
	GameAudio.ensure_buses()
	au = GameAudio.new()
	add_child(au)
	au.setup(car, null)
	rec = AudioEffectRecord.new()
	AudioServer.add_bus_effect(0, rec)
	rec.set_recording_active(true)
	print("SIM start car=", cid, " misses=", SoundBank.misses)


func _process(dt: float) -> void:
	if fin:
		return
	t += dt
	var rn := 0.0
	var gas := 0.0
	var g := 1
	if t < 2.0:
		rn = 0.0
	elif t < 4.5:
		rn = lerpf(0.05, 0.95, (t - 2.0) / 2.5)
		gas = 1.0
	elif t < 7.0:
		rn = lerpf(0.5, 0.95, (t - 4.5) / 2.5)
		gas = 1.0
		g = 2
	elif t < 9.5:
		rn = lerpf(0.55, 0.97, (t - 7.0) / 2.5)
		gas = 1.0
		g = 3
	elif t < 12.0:
		rn = lerpf(0.97, 0.35, (t - 9.5) / 2.5)
		g = 3
	elif t < 15.0:
		rn = 0.5
		gas = 0.5
		g = 3
	elif t < 16.5:
		rn = 1.0
		gas = 1.0
		g = 3
	elif t < 18.0:
		rn = 0.7
		gas = 0.8
		g = 3
		car.dmg.engine = 0.7
	elif t < 20.0:
		rn = 0.6
		gas = 0.6
		g = 3
		car.dmg.fuel = 0.0
	else:
		if car.dmg.fuel <= 0.0:
			car.dmg.repair()
		rn = 0.2 + 0.5 * clampf((t - 22.0) / 2.0, 0.0, 1.0)
		gas = 0.0 if t < 22.0 else 0.7
	car.rpm = rn
	car.in_gas = gas
	car.gear = g
	car.speed = 3.0 + rn * 35.0 * (0.0 if t < 2.0 else 1.0)
	if t > 26.0:
		fin = true
		rec.set_recording_active(false)
		var w := rec.get_recording()
		if w != null:
			w.save_to_wav(out)
		print("SIM done saved=", out, " active_layers=", EngineSound.active, " misses=", SoundBank.misses)
		get_tree().quit()
