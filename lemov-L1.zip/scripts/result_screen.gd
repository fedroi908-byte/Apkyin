class_name ResultScreen
extends CanvasLayer
## Mission result card with animated stars.

signal retry
signal free_roam
signal exit_menu

var _ad_done := false


func show_result(res: Dictionary) -> void:
	layer = 30
	process_mode = Node.PROCESS_MODE_ALWAYS
	var m: Dictionary = res["mission"]
	var ok: bool = res["success"]
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.6)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var p := Ui.panel(Color(0.03, 0.05, 0.09, 0.95), 24)
	p.custom_minimum_size = Vector2(760, 520)
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(cc)
	cc.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	p.add_child(v)
	var title := "MISSION COMPLETE" if ok else "MISSION FAILED"
	var npl := int(res.get("n", 0))
	var rows: Array = res.get("rows", [])
	if npl > 0:
		var ps := int(res["pos"])
		title = ("VICTORY!" if ps == 1 else "PODIUM  P%d / %d" % [ps, npl]) if ok else "FINISHED  P%d / %d" % [ps, npl]
		p.custom_minimum_size = Vector2(760, 600 + 30 * rows.size())
	var h := Ui.label(title, 54, Ui.GOOD if ok else Color(1, 0.3, 0.25), true)
	h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(h)
	var n := Ui.label(String(m["name"]), 30, Ui.DIM)
	n.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(n)
	var sr := HBoxContainer.new()
	sr.alignment = BoxContainer.ALIGNMENT_CENTER
	sr.add_theme_constant_override("separation", 18)
	v.add_child(sr)
	for i in 3:
		var s := Ui.label("★", 96, Ui.GOLD if i < int(res["stars"]) else Color(1, 1, 1, 0.15))
		s.pivot_offset = Vector2(48, 48)
		s.scale = Vector2.ZERO
		sr.add_child(s)
		var tw := create_tween()
		tw.tween_interval(0.35 + 0.3 * i)
		tw.tween_property(s, "scale", Vector2.ONE * (1.0 if i < int(res["stars"]) else 0.8), 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		if i < int(res["stars"]):
			tw.tween_callback(func(): G.ui("checkpoint", -6.0))
	var val: float = res["value"]
	var line := ""
	match String(m["type"]):
		"drift":
			line = "Score %d" % int(val)
		_:
			line = "Time %d:%04.1f" % [int(val / 60.0), fmod(val, 60.0)]
	line += "    Top speed %d km/h" % int(res["top"])
	var l := Ui.label(line, 26, Color.WHITE)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(l)
	var rw := Ui.label("+ $ %d" % int(res["reward"]), 40, Ui.GOLD, true)
	rw.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(rw)
	if int(res.get("bonus", 0)) > 0:
		var bl := Ui.label("Bonus +$%d   Takedowns %d   Drift %d" % [int(res["bonus"]), int(res.get("takedowns", 0)), int(res.get("drift_pts", 0))], 22, Ui.DIM)
		bl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(bl)
	if rows.size() > 0:
		var tb := VBoxContainer.new()
		tb.add_theme_constant_override("separation", 2)
		v.add_child(tb)
		for r in rows:
			var hb := HBoxContainer.new()
			hb.alignment = BoxContainer.ALIGNMENT_CENTER
			hb.add_theme_constant_override("separation", 16)
			var col: Color = Ui.GOLD if bool(r["you"]) else Color(0.85, 0.9, 1.0)
			var a := Ui.label("%d" % int(r["pos"]), 22, col)
			a.custom_minimum_size = Vector2(34, 0)
			var b := Ui.label(String(r["name"]), 22, col)
			b.custom_minimum_size = Vector2(190, 0)
			var tm := float(r["time"])
			var ts := "%d:%04.1f" % [int(tm / 60.0), fmod(tm, 60.0)] if int(r["pos"]) == 1 else "+%.1fs" % float(r["gap"])
			if bool(r["est"]):
				ts = "~" + ts
			var c := Ui.label(ts, 22, col)
			c.custom_minimum_size = Vector2(130, 0)
			c.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
			hb.add_child(a)
			hb.add_child(b)
			hb.add_child(c)
			tb.add_child(hb)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	v.add_child(row)
	for it in [["RETRY", func(): _go(retry), Ui.HOT], ["FREE ROAM", func(): _go(free_roam), Ui.ACCENT], ["MENU", func(): _go(exit_menu), Ui.DIM]]:
		var b := Ui.button(it[0], it[1], it[2], 22, Vector2(220, 60))
		b.alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.process_mode = Node.PROCESS_MODE_ALWAYS
		row.add_child(b)
	p.modulate.a = 0.0
	p.create_tween().tween_property(p, "modulate:a", 1.0, 0.3)


## Shows the server's interstitial ad (if one is due) once, between the result card and the next action.
func _go(sig: Signal) -> void:
	if not _ad_done:
		_ad_done = true
		var ad: Dictionary = R.ad_pick("race_end")
		if not ad.is_empty():
			var sc := AdCard.Screen.new()
			add_child(sc)
			sc.finished.connect(func(_r: bool): sig.emit())
			sc.show_ad(ad, "race_end")
			return
	sig.emit()
