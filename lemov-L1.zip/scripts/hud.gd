class_name Hud
extends CanvasLayer
## In-game HUD: speedometer with RPM arc, nitro bar, clock, touch controls, top buttons.

signal menu_pressed
signal camera_pressed
signal reset_pressed
signal radio_pressed

var touch: Dictionary = {}
var touch_layer: TouchLayer
var root: Control
var gauge: Control
var speed := 0.0
var rpm := 0.0
var gear := 1
var nitro := 1.0
var clock_text := "12:00"
var fps_label: Label
var toast_label: Label
var _toast_tw: Tween
var clock_label: Label
var boosting := false
var street_label: Label
var _font: Font
var dmg_ctl: Control
var _dmg: CarDamage
var _dmg_ver := -1
var _ins := Vector4.ZERO


func _ready() -> void:
	layer = 10
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	_font = ThemeDB.fallback_font
	gauge = Control.new()
	gauge.set_anchors_preset(Control.PRESET_FULL_RECT)
	gauge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gauge.draw.connect(_draw_gauge)
	root.add_child(gauge)
	dmg_ctl = Control.new()
	dmg_ctl.set_anchors_preset(Control.PRESET_FULL_RECT)
	dmg_ctl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dmg_ctl.draw.connect(_draw_dmg)
	root.add_child(dmg_ctl)
	clock_label = _label("12:00", 30, Vector2(0, 14), true)
	clock_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	clock_label.position = Vector2(-60, 12)
	fps_label = _label("", 18, Vector2(14, 12), false)
	var ins := Ui.safe_insets(get_viewport())
	_ins = Vector4(ins.x, ins.y, ins.z, ins.w)
	fps_label.position = Vector2(14.0 + ins.x, 12.0 + ins.y)
	_btn("II", Vector2(-84 - ins.z, 14 + ins.y), Control.PRESET_TOP_RIGHT, Vector2(66, 66), func(): menu_pressed.emit())
	_btn("CAM", Vector2(-160 - ins.z, 14 + ins.y), Control.PRESET_TOP_RIGHT, Vector2(66, 66), func(): camera_pressed.emit())
	_btn("R", Vector2(-236 - ins.z, 14 + ins.y), Control.PRESET_TOP_RIGHT, Vector2(66, 66), func(): reset_pressed.emit())
	_btn("FM", Vector2(-312 - ins.z, 14 + ins.y), Control.PRESET_TOP_RIGHT, Vector2(66, 66), func(): radio_pressed.emit())
	toast_label = _label("", 24, Vector2(0, 58), true)
	toast_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	toast_label.custom_minimum_size = Vector2(320, 0)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.position = Vector2(-160, 58)
	toast_label.modulate.a = 0.0
	# multi-touch controls (raw touch events; always created, harmless with a keyboard)
	touch_layer = TouchLayer.new()
	touch_layer.state = touch
	touch_layer.swap_sides = G.left_handed
	root.add_child(touch_layer)


func _label(t: String, size: int, pos: Vector2, bold: bool) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color(1, 1, 1, 0.95))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	l.add_theme_constant_override("outline_size", 6)
	l.position = pos
	root.add_child(l)
	return l


func _style(c: Color, r: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(r)
	s.border_color = Color(1, 1, 1, 0.35)
	s.set_border_width_all(2)
	return s


func _btn(t: String, pos: Vector2, preset: int, size: Vector2, cb: Callable) -> Button:
	var b := Button.new()
	b.text = t
	b.set_anchors_preset(preset)
	b.size = size
	b.position = pos
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", _style(Color(0.05, 0.08, 0.14, 0.55), 14))
	b.add_theme_stylebox_override("pressed", _style(Color(0.1, 0.5, 0.9, 0.75), 14))
	b.add_theme_stylebox_override("hover", _style(Color(0.1, 0.2, 0.3, 0.65), 14))
	b.add_theme_font_size_override("font_size", 20)
	b.pressed.connect(cb)
	root.add_child(b)
	return b


func update_state(v: Vehicle, a: Atmosphere, _t: float) -> void:
	speed = v.kmh()
	rpm = v.rpm
	gear = v.gear
	nitro = v.nitro
	boosting = v.in_nitro and v.nitro > 0.02 and v.in_gas > 0.1
	var h := int(a.time_of_day)
	var m := int((a.time_of_day - h) * 60.0)
	clock_label.text = "%02d:%02d" % [h, m]
	gauge.queue_redraw()
	_dmg = v.dmg
	if _dmg.version != _dmg_ver:
		_dmg_ver = _dmg.version
		dmg_ctl.queue_redraw()


func toast(t: String) -> void:
	toast_label.text = t
	toast_label.modulate.a = 1.0
	if _toast_tw and _toast_tw.is_valid():
		_toast_tw.kill()
	_toast_tw = create_tween()
	_toast_tw.tween_interval(1.8)
	_toast_tw.tween_property(toast_label, "modulate:a", 0.0, 0.5)


func set_fps(f: float) -> void:
	fps_label.text = "%d FPS" % int(f)


func _draw_gauge() -> void:
	var vp := gauge.get_viewport_rect().size
	var c := Vector2(vp.x * 0.5, vp.y - 110.0)
	var r := 92.0
	# arc background + rpm
	gauge.draw_arc(c, r, deg_to_rad(150), deg_to_rad(390), 48, Color(0, 0, 0, 0.45), 16.0, true)
	var a1 := deg_to_rad(150.0 + 240.0 * clampf(rpm, 0.0, 1.0))
	var col := Color(0.2, 0.8, 1.0).lerp(Color(1, 0.2, 0.15), smoothstep(0.75, 1.0, rpm))
	gauge.draw_arc(c, r, deg_to_rad(150), a1, 48, col, 10.0, true)
	gauge.draw_arc(c, r - 18.0, deg_to_rad(150), deg_to_rad(390), 48, Color(1, 1, 1, 0.15), 2.0, true)
	var s := str(int(speed))
	var fs := 64
	var sz := _font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	gauge.draw_string_outline(_font, c + Vector2(-sz.x * 0.5, 14.0), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 6, Color(0, 0, 0, 0.8))
	gauge.draw_string(_font, c + Vector2(-sz.x * 0.5, 14.0), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color.WHITE)
	gauge.draw_string(_font, c + Vector2(-24, 40), "KM/H", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 1, 1, 0.8))
	gauge.draw_string(_font, c + Vector2(-8, -48), str(gear), HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color(1, 0.85, 0.2))
	# nitro bar
	var bw := 220.0
	var bx := c.x - bw * 0.5
	var by := c.y + 58.0
	gauge.draw_rect(Rect2(bx, by, bw, 10), Color(0, 0, 0, 0.5))
	var nc := Color(0.3, 0.6, 1.0) if not boosting else Color(0.7, 0.9, 1.0)
	gauge.draw_rect(Rect2(bx, by, bw * nitro, 10), nc)
	gauge.draw_rect(Rect2(bx, by, bw, 10), Color(1, 1, 1, 0.4), false, 1.5)


func _dmg_col(v: float) -> Color:
	return Color(0.3, 0.85, 0.45, 0.8).lerp(Color(1.0, 0.22, 0.1, 0.92), clampf(v * 1.5, 0.0, 1.0))


## Small top-down car under the FPS label: every body zone, wheel, engine and radiator coloured by its damage. Hidden while the car is undamaged.
func _draw_dmg() -> void:
	if _dmg == null or not _dmg.any():
		return
	var o := Vector2(30.0 + _ins.x, 64.0 + _ins.y)
	var z := _dmg.zone
	var c := dmg_ctl
	c.draw_rect(Rect2(o + Vector2(-14, -6), Vector2(60, 96)), Color(0, 0, 0, 0.38))
	c.draw_rect(Rect2(o + Vector2(0, 0), Vector2(10, 16)), _dmg_col(z[0]))
	c.draw_rect(Rect2(o + Vector2(11, 0), Vector2(10, 16)), _dmg_col(z[1]))
	c.draw_rect(Rect2(o + Vector2(22, 0), Vector2(10, 16)), _dmg_col(z[2]))
	c.draw_rect(Rect2(o + Vector2(0, 17), Vector2(8, 38)), _dmg_col(z[3]))
	c.draw_rect(Rect2(o + Vector2(9, 17), Vector2(14, 38)), _dmg_col(z[8]))
	c.draw_rect(Rect2(o + Vector2(24, 17), Vector2(8, 38)), _dmg_col(z[4]))
	c.draw_rect(Rect2(o + Vector2(0, 56), Vector2(10, 16)), _dmg_col(z[5]))
	c.draw_rect(Rect2(o + Vector2(11, 56), Vector2(10, 16)), _dmg_col(z[6]))
	c.draw_rect(Rect2(o + Vector2(22, 56), Vector2(10, 16)), _dmg_col(z[7]))
	for i in _dmg.wheel_pos.size():
		var wp: Vector3 = _dmg.wheel_pos[i]
		var r := Rect2(o + Vector2(-9.0 if wp.x > 0.0 else 34.0, 2.0 if wp.z > 0.0 else 54.0), Vector2(7, 15))
		if bool(_dmg.detached[i]):
			c.draw_rect(r, Color(0.1, 0.1, 0.1, 0.5))
			c.draw_line(r.position, r.end, Color(1, 0.2, 0.1), 2.0)
			c.draw_line(r.position + Vector2(r.size.x, 0.0), r.position + Vector2(0.0, r.size.y), Color(1, 0.2, 0.1), 2.0)
		else:
			var bad := maxf(_dmg.susp[i], _dmg.tyre[i])
			c.draw_rect(r, Color(0.6, 0.6, 0.62, 0.85) if bad < 0.05 else _dmg_col(bad))
	c.draw_rect(Rect2(o + Vector2(0, 76), Vector2(32.0 * (1.0 - _dmg.engine), 3)), Color(1.0, 0.75, 0.2, 0.9))
	c.draw_rect(Rect2(o + Vector2(0, 81), Vector2(32.0 * (1.0 - _dmg.radiator), 3)), Color(0.4, 0.8, 1.0, 0.9))
