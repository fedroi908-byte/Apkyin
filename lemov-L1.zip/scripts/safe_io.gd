class_name SafeIO
extends RefCounted
## Crash-safe file helpers: JSON parsing that never prints errors (a torn or empty file just gives null) and atomic writes
## (temp file + rename, the previous version is kept as .bak and used when the main file is unreadable).


static func parse(text: String) -> Variant:
	if text.strip_edges().is_empty():
		return null
	var j := JSON.new()
	if j.parse(text) != OK:
		return null
	return j.data


## Reads a JSON file; falls back to its .bak copy. Returns null when neither is usable.
static func read_json(path: String) -> Variant:
	for p in [path, path + ".bak"]:
		if FileAccess.file_exists(p):
			var v: Variant = parse(FileAccess.get_file_as_string(p))
			if v != null:
				return v
	return null


static func write_json(path: String, data: Variant) -> bool:
	return write_text(path, JSON.stringify(data))


static func write_text(path: String, text: String) -> bool:
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(text)
	f.flush()
	f.close()
	if FileAccess.file_exists(path):
		if parse(FileAccess.get_file_as_string(path)) != null:
			DirAccess.copy_absolute(path, path + ".bak")
		DirAccess.remove_absolute(path)
	return DirAccess.rename_absolute(tmp, path) == OK
