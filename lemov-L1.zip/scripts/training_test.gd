extends Node
## Headless training-hall test: args = <phase 0..4> [car index]. Drives a scripted car through one station and prints results.
var gw: GameWorld
var t := 0.0
var phase := 0
var nxt := 1.0
var braked := false


func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	phase = int(a[0]) if a.size() > 0 else 0
	G.start_hour = 11.0
	G.mode = "training"
	if a.size() > 1:
		G.selected_car = int(a[1])
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)
	await get_tree().process_frame
	gw.hall.go_station(phase)
	print("TH start phase ", phase, " car ", G.car()["id"], " pos ", gw.player.global_position.snapped(Vector3(0.1, 0.1, 0.1)))


func _hold_lane(z: float) -> void:
	var p := gw.player
	var target := PI * 0.5 + clampf((p.global_position.z - z) * 0.03, -0.2, 0.2)
	p.in_steer = clampf((p.yaw - target) * 2.5, -1.0, 1.0)


func _physics_process(dt: float) -> void:
	if gw == null or gw.hall == null:
		return
	t += dt
	var p := gw.player
	var h := gw.hall
	p.in_brake = 0.0
	p.in_gas = 0.0
	p.in_steer = 0.0
	p.in_handbrake = false
	p.in_nitro = false
	var done := false
	match phase:
		0:
			if t > 1.0:
				p.in_gas = 1.0
			_hold_lane(h.LANE_R)
			done = h.d_state == 3 or t > 45.0
		1:
			if t > 0.5:
				p.in_gas = 1.0 if p.kmh() < 90.0 else 0.4
			_hold_lane(h.LANE_L)
			done = h.s_state == 2 or t > 30.0
		2:
			_hold_lane(h.LANE_C)
			if h.b_state == 0 and not braked:
				p.in_gas = 1.0 if t > 0.5 else 0.0
			if h.b_state == 1:
				braked = true
				p.in_brake = 1.0
			elif braked:
				p.in_brake = 1.0
			done = h.b_state == 2 or t > 50.0
		3:
			if t > 0.5:
				p.in_gas = 1.0 if p.kmh() < 120.0 else 0.5
			_hold_lane(h.LANE_R)
			done = h.j_state == 2 or t > 30.0
		4:
			if t > 0.5:
				p.in_gas = 1.0 if p.kmh() < 70.0 else 0.6
			var c := Vector2(p.global_position.x - h.DR_C.x, p.global_position.z - h.DR_C.y)
			if c.length() < 40.0:
				p.in_steer = 1.0
				p.in_handbrake = int(t * 2.0) % 3 == 0
			else:
				_hold_lane(h.DR_C.y)
			done = h.f_state == 2 or t > 40.0
	if t > nxt:
		nxt += 1.0
		print("T ", int(t), " kmh ", int(p.kmh()), " pos ", p.global_position.snapped(Vector3(0.1, 0.1, 0.1)), " yaw ", snappedf(p.yaw, 0.01), " air ", p.airborne, " drift ", p.drifting, " d", h.d_state, " s", h.s_state, " b", h.b_state, " j", h.j_state, " f", h.f_state)
	if done:
		print("RESULT drag ", h.d100, " ", h.d200, " ", h.d402, " ", h.v402, " ", h.d1000, " ", h.v1000, " | slalom ", h.s_total, " hits ", h._count_hits(1), " | brake ", h.b_d, " g ", h.b_g, " v ", h.b_v * 3.6, " | jump ", h.j_dist, " t ", h.j_t, " top ", h.j_top - h.j_from.y, " v ", h.j_v, " | drift ", h.f_last, " score ", h.f_score)
		get_tree().quit()
