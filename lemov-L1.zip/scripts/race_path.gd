class_name RacePath
extends RefCounted
## Driving line for AI racers. The race route is resampled (Catmull-Rom, flat x/z) into points ~9 m apart with a heading, a "right-hand"
## vector and a curvature per point; a worker thread then relaxes a racing line inside the road width (cuts corners, uses the full width,
## smooth curvature). Racers follow centre line + racing-line offset + their own deviation.

const STEP := 9.0

var pts := PackedVector3Array()
var sd := PackedVector3Array()          # unit vector to the driver's right
var cum := PackedFloat32Array()
var hd := PackedFloat32Array()          # heading atan2(x, z) of the segment starting at the point
var kappa := PackedFloat32Array()       # curvature of the centre line, 1/m
var off := PackedFloat32Array()         # racing-line offset from the centre line (+ right)
var lkappa := PackedFloat32Array()      # curvature of the racing line
var lds := PackedFloat32Array()         # length of the racing-line segment starting at the point
var seg := PackedFloat32Array()         # length of the centre-line segment starting at the point (0 for the last point of an open route)
var _pd2 := 0.0                         # squared distance found by the last project()
var length := 0.0
var loop := false
var n := 0
var half := 6.0                         # half road width
var lim := 3.0                          # largest |offset| of the racing line
var lim_out := 4.4                      # largest |offset| a racer may ask for (overtaking)
var version := 0                        # bumped whenever the racing line changes
var _task := -1
var _res := PackedFloat32Array()


static func from_route(route: Array, is_loop: bool, half_w: float) -> RacePath:
	var rp := RacePath.new()
	rp.loop = is_loop
	rp.half = half_w
	rp.lim = maxf(half_w - 2.7, 0.0)
	rp.lim_out = maxf(half_w - 1.7, 0.0)
	rp._build(route)
	return rp


static func _dseg(q: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	var l2 := ab.length_squared()
	var t := clampf((q - a).dot(ab) / maxf(l2, 0.0001), 0.0, 1.0)
	return q.distance_to(a + ab * t)


## Removes out-and-back spurs: the route runs into a dead end and comes back along the very same line (waypoint on a side road).
static func despur(pts: Array) -> Array:
	var p: Array = []
	for q in pts:
		p.append(Vector2(float(q[0]), float(q[1])))
	var total := 0.0
	for i in range(1, p.size()):
		total += p[i].distance_to(p[i - 1])
	var guard := 0
	var i := 1
	while i < p.size() - 1 and guard < 40:
		var a: Vector2 = p[i] - p[i - 1]
		var b: Vector2 = p[i + 1] - p[i]
		if a.length() > 0.5 and b.length() > 0.5 and absf(a.angle_to(b)) > 2.4:
			var jl := i - 1
			var last_k := -1
			var hits := 0
			var k := i + 1
			while k < p.size():
				var bd := 1e9
				var bj := -1
				for j in range(jl, maxi(jl - 4, -1), -1):
					var d := _dseg(p[k], p[j], p[j + 1])
					if d < bd:
						bd = d
						bj = j
				if bd < 2.5 and bj >= 0:
					jl = bj
					last_k = k
					hits += 1
					k += 1
				else:
					break
			if hits >= 3 and last_k + 1 < p.size():
				var cut := 0.0
				for m in range(jl + 1, last_k + 1):
					cut += p[m].distance_to(p[m - 1])
				if cut < total * 0.5:
					p = p.slice(0, jl + 1) + p.slice(last_k)
					guard += 1
					i = maxi(jl, 1)
					continue
		i += 1
	var res: Array = []
	for q in p:
		res.append([q.x, q.y])
	return res


## Rounds hairpin vertices of a route (corner cutting only where the bend is sharper than thr, so street circuits stay untouched).
static func round_corners(pts: Array, thr: float = 1.9, thr2: float = 0.9) -> Array:
	var p: Array = []
	for q in pts:
		p.append(Vector2(float(q[0]), float(q[1])))
	var hot: Array = []
	hot.resize(p.size())
	hot.fill(false)
	for _pass in 4:
		var out: Array = [p[0]]
		var hout: Array = [false]
		var changed := false
		for i in range(1, p.size() - 1):
			var a: Vector2 = p[i] - p[i - 1]
			var b: Vector2 = p[i + 1] - p[i]
			var lim: float = thr2 if hot[i] else thr
			if a.length() > 2.5 and b.length() > 2.5 and absf(a.angle_to(b)) > lim:
				out.append(p[i] - a * 0.3)
				out.append(p[i] + b * 0.3)
				hout.append(true)
				hout.append(true)
				changed = true
			else:
				out.append(p[i])
				hout.append(hot[i])
		out.append(p[p.size() - 1])
		hout.append(false)
		p = out
		hot = hout
		if not changed:
			break
	var res: Array = []
	for q in p:
		res.append([snappedf(q.x, 0.1), snappedf(q.y, 0.1)])
	return res


static func clean(pts: Array) -> Array:
	return round_corners(despur(pts))


func wi(i: int) -> int:
	return posmod(i, n) if loop else clampi(i, 0, n - 1)


func _build(route: Array) -> void:
	var c: Array = []
	for q in route:
		c.append(Vector2(float(q[0]), float(q[1])))
	if loop and c.size() > 3 and (c[0] as Vector2).distance_to(c[c.size() - 1]) < 80.0:
		c.remove_at(c.size() - 1)
	var m := c.size()
	var segs := m if loop else m - 1
	for i in segs:
		var p1: Vector2 = c[i]
		var p2: Vector2 = c[(i + 1) % m]
		var p0: Vector2 = c[(i - 1 + m) % m] if (loop or i > 0) else p1 - (p2 - p1)
		var p3: Vector2 = c[(i + 2) % m] if (loop or i + 2 < m) else p2 + (p2 - p1)
		var steps := maxi(1, int(ceil(p1.distance_to(p2) / STEP)))
		for k in steps:
			var t := float(k) / float(steps)
			var t2 := t * t
			var t3 := t2 * t
			var q := 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)
			pts.append(Vector3(q.x, 0.0, q.y))
	if not loop:
		pts.append(Vector3((c[m - 1] as Vector2).x, 0.0, (c[m - 1] as Vector2).y))
	n = pts.size()
	cum.resize(n)
	hd.resize(n)
	sd.resize(n)
	off.resize(n)
	var acc := 0.0
	for i in n:
		cum[i] = acc
		var j := (i + 1) % n if loop else mini(i + 1, n - 1)
		if j == i:
			hd[i] = hd[i - 1] if i > 0 else 0.0
		else:
			var d := pts[j] - pts[i]
			hd[i] = atan2(d.x, d.z)
		sd[i] = Vector3(-cos(hd[i]), 0.0, sin(hd[i]))      # forward = (sin h, 0, cos h); right = (-cos h, 0, sin h)
		off[i] = 0.0
		if i < n - 1 or loop:
			acc += pts[i].distance_to(pts[(i + 1) % n])
	length = acc
	seg.resize(n)
	for i in n:
		seg[i] = pts[i].distance_to(pts[(i + 1) % n]) if (loop or i < n - 1) else 0.0
	kappa = _curvature(pts)
	lkappa = kappa.duplicate()
	lds.resize(n)
	for i in n:
		lds[i] = pts[i].distance_to(pts[wi(i + 1)]) if (loop or i < n - 1) else 0.0


func _curvature(p: PackedVector3Array) -> PackedFloat32Array:
	var h := PackedFloat32Array()
	h.resize(n)
	var cu := PackedFloat32Array()
	cu.resize(n)
	var acc := 0.0
	for i in n:
		cu[i] = acc
		var j := wi(i + 1)
		var d := p[j] - p[i]
		h[i] = atan2(d.x, d.z) if j != i else (h[i - 1] if i > 0 else 0.0)
		if i < n - 1 or loop:
			acc += p[i].distance_to(p[(i + 1) % n])
	var tot := acc
	var raw := PackedFloat32Array()
	raw.resize(n)
	for i in n:
		var a := wi(i - 2)
		var b := wi(i + 2)
		var ds := fposmod(cu[b] - cu[a], tot) if loop else absf(cu[b] - cu[a])
		raw[i] = absf(angle_difference(h[a], h[b])) / maxf(ds, 1.0)
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		var k := 0.0
		for o in range(-2, 3):
			k = maxf(k, raw[wi(i + o)])
		out[i] = k
	return out


# ---- racing line (worker thread) ---------------------------------------------------------------------------------------------

func start_optimize(iterations: int = 70) -> void:
	if lim < 0.6 or n < 8 or _task >= 0:
		return
	_task = WorkerThreadPool.add_task(_job.bind(iterations), false, "racing line")


## Call every frame / physics tick until it returns true once (the new line is live and `version` was bumped).
func poll() -> bool:
	if _task < 0 or not WorkerThreadPool.is_task_completed(_task):
		return false
	WorkerThreadPool.wait_for_task_completion(_task)
	_task = -1
	off = _res
	var lp := PackedVector3Array()
	lp.resize(n)
	for i in n:
		lp[i] = pts[i] + sd[i] * off[i]
	lkappa = _curvature(lp)
	for i in n:
		lds[i] = lp[i].distance_to(lp[wi(i + 1)]) if (loop or i < n - 1) else 0.0
	version += 1
	return true


func busy() -> bool:
	return _task >= 0


func _job(iters: int) -> void:
	var o := PackedFloat32Array()
	o.resize(n)
	var omega := 1.6
	for _it in iters:
		for i in n:
			if not loop and (i == 0 or i == n - 1):
				continue
			var a := wi(i - 1)
			var b := wi(i + 1)
			var pa := pts[a] + sd[a] * o[a]
			var pb := pts[b] + sd[b] * o[b]
			var want := ((pa + pb) * 0.5 - pts[i]).dot(sd[i])
			o[i] = clampf(o[i] + omega * (want - o[i]), -lim, lim)
	for _s in 8:                                         # smooth out kinks
		var prev := o.duplicate()
		for i in n:
			if not loop and (i == 0 or i == n - 1):
				continue
			o[i] = 0.25 * prev[wi(i - 1)] + 0.5 * prev[i] + 0.25 * prev[wi(i + 1)]
	# keep the line drivable: where its curvature exceeds what a car can follow, push it to the outside of the bend (bigger radius)
	var klim := 0.125
	var lp := PackedVector3Array()
	lp.resize(n)
	for _r in 30:
		for i in n:
			lp[i] = pts[i] + sd[i] * o[i]
		var bad := false
		var add := PackedFloat32Array()
		add.resize(n)
		for i in n:
			var a := wi(i - 1)
			var b := wi(i + 1)
			var d1 := lp[i] - lp[a]
			var d2 := lp[b] - lp[i]
			var ds := maxf((d1.length() + d2.length()) * 0.5, 1.0)
			var kk := angle_difference(atan2(d1.x, d1.z), atan2(d2.x, d2.z)) / ds      # + : turning left
			if absf(kk) > klim and (loop or (i > 0 and i < n - 1)):
				bad = true
				add[i] = 0.4 if kk > 0.0 else -0.4                                   # left turn -> outside is the right (+)
		if not bad:
			break
		for i in n:
			if add[i] != 0.0:
				for j in range(-2, 3):
					var m := wi(i + j)
					o[m] = clampf(o[m] + add[i] * (1.0 - 0.3 * absf(j)), -lim, lim)
	_res = o


# ---- queries ------------------------------------------------------------------------------------------------------------------

func dir_at(i: int) -> Vector3:
	var h := hd[wi(i)]
	return Vector3(sin(h), 0.0, cos(h))


## Point at index i on the racing line shifted by `dev` metres (+ right), never beyond the allowed width.
func lane_point(i: int, dev: float) -> Vector3:
	var k := wi(i)
	var o := clampf(off[k] + dev, -lim_out, lim_out)
	return pts[k] + sd[k] * o


func lateral_of(p: Vector3, i: int) -> float:
	var k := wi(i)
	return (p - pts[k]).dot(sd[k])


func closest(p: Vector3, hint: int, back: int, ahead: int) -> int:
	var best := wi(hint)
	var bd := 1e30
	for k in range(-back, ahead + 1):
		var i := wi(hint + k)
		var dx := pts[i].x - p.x
		var dz := pts[i].z - p.z
		var d := dx * dx + dz * dz
		if d < bd:
			bd = d
			best = i
	return best


func closest_global(p: Vector3) -> int:
	var best := 0
	var bd := 1e30
	for i in n:
		var dx := pts[i].x - p.x
		var dz := pts[i].z - p.z
		var d := dx * dx + dz * dz
		if d < bd:
			bd = d
			best = i
	return best


func dist2d(p: Vector3, i: int) -> float:
	return Vector2(pts[i].x - p.x, pts[i].z - p.z).length()


# ---- continuous tracking (foot of the perpendicular instead of the nearest control point) --------------------------------------

## Projects p onto the centre line near segment `hint`. Returns Vector3(segment index, fraction 0..1 along it, signed lateral offset, + right).
func project(p: Vector3, hint: int, back: int, ahead: int, vel: Vector3 = Vector3.ZERO) -> Vector3:
	var bk := wi(hint)
	var bt := 0.0
	var bd := 1e30
	var vl := Vector2(vel.x, vel.z).length()
	var vx := vel.x / vl if vl > 3.0 else 0.0
	var vz := vel.z / vl if vl > 3.0 else 0.0
	for o in range(-back, ahead + 1):
		var i := wi(hint + o)
		var j := wi(i + 1)
		if j == i:
			continue
		var ax := pts[i].x
		var az := pts[i].z
		var dx := pts[j].x - ax
		var dz := pts[j].z - az
		var t := clampf(((p.x - ax) * dx + (p.z - az) * dz) / maxf(dx * dx + dz * dz, 0.01), 0.0, 1.0)
		var qx := ax + dx * t - p.x
		var qz := az + dz * t - p.z
		var d := qx * qx + qz * qz
		var cost := d + 2.5 * float(o * o)                  # prefer the segment right after the previous one (the other leg of a hairpin is close in space, far in index)
		if vl > 3.0 and (dx * vx + dz * vz) < -0.2 * sqrt(dx * dx + dz * dz):
			cost += 150.0                                    # and one that points the way we are moving
		if cost < bd:
			bd = cost
			bk = i
			bt = t
			_pd2 = d
	var j2 := wi(bk + 1)
	var q := pts[bk].lerp(pts[j2], bt)
	var nrm := sd[bk].lerp(sd[j2], bt).normalized()
	return Vector3(float(bk), bt, (p - q).dot(nrm))


## Position `dist` metres further along the centre line from (k, t): Vector2(segment index, fraction).
func advance(k: int, t: float, dist: float) -> Vector2:
	var i := k
	var rem := dist + t * seg[k]
	for _g in 40:
		var l := seg[i]
		if l < 0.01:
			return Vector2(float(i), 0.0)
		if rem <= l:
			return Vector2(float(i), rem / l)
		rem -= l
		i = wi(i + 1)
	return Vector2(float(i), 0.0)


## Point on the racing line (shifted by `dev`, + right) at the position kt = Vector2(segment index, fraction).
func lane_at(kt: Vector2, dev: float) -> Vector3:
	var k := int(kt.x)
	return lane_point(k, dev).lerp(lane_point(wi(k + 1), dev), kt.y)


func lerp_at(arr: PackedFloat32Array, kt: Vector2) -> float:
	var k := int(kt.x)
	return lerpf(arr[k], arr[wi(k + 1)], kt.y)


## Follows one car along the route: segment, fraction, arc length, signed lateral offset and lap counter.
class Tracker extends RefCounted:
	var path: RacePath
	var k := 0
	var t := 0.0
	var lat := 0.0
	var lap := 0
	var s := 0.0

	func _init(p: RacePath, start_idx: int, start_lap: int) -> void:
		path = p
		k = p.wi(start_idx)
		lap = start_lap
		s = p.cum[k]

	func reset(idx: int) -> void:
		k = path.wi(idx)
		t = 0.0
		s = path.cum[k]

	func update(p: Vector3, vel: Vector3 = Vector3.ZERO) -> void:
		var r := path.project(p, k, 3, 10, vel)                  # narrow window: at a hairpin the other leg of the road is closer than the next point
		if path._pd2 > 2500.0:                               # lost (teleport / far off the road): search everywhere
			r = path.project(p, 0, 0, path.n - 1)
		var nk := int(r.x)
		if path.loop:
			if k > path.n * 3 / 4 and nk < path.n / 4:
				lap += 1
			elif k < path.n / 4 and nk > path.n * 3 / 4:
				lap -= 1
		k = nk
		t = r.y
		lat = r.z
		s = path.cum[k] + t * path.seg[k]

	func near() -> int:
		return k if t < 0.5 else path.wi(k + 1)

	func progress() -> float:
		return float(lap) * path.length + s
