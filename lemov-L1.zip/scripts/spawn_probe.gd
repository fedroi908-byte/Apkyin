extends Node
## Dev tool: prints the roads around the free-mode spawn point.
var gw: GameWorld
var frames := 0


func _ready() -> void:
	G.mode = "free"
	G.quality = 0
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)


func _process(_dt: float) -> void:
	frames += 1
	if frames == 20:
		var sp := gw.start_pos
		print("SPAWN pos=", sp, " yaw_deg=", rad_to_deg(gw.start_yaw), " player=", gw.player.global_position, " fwd=", gw.player.global_transform.basis.z)
		print("SPAWN terrain_h=", W.terrain_height(sp.x, sp.z), " ground_h=", W.ground_height(sp.x, sp.z), " road_blend=", W.road_blend(sp.x, sp.z))
		var n := 0
		for r in W.roads:
			var pts: PackedVector3Array = r["pts"]
			var bd := 1e9
			var bi := -1
			for i in pts.size():
				var d := Vector2(pts[i].x - sp.x, pts[i].z - sp.z).length()
				if d < bd:
					bd = d
					bi = i
			if bd < 45.0:
				var a := pts[maxi(bi - 1, 0)]
				var b := pts[mini(bi + 1, pts.size() - 1)]
				var ang := rad_to_deg(atan2(b.x - a.x, b.z - a.z))
				var keys := []
				for k in r.keys():
					if k != "pts":
						keys.append(str(k) + "=" + str(r[k]))
				print("ROAD d=", snappedf(bd, 0.1), " ang=", snappedf(ang, 0.1), " n=", pts.size(), " ", keys)
				n += 1
		print("SPAWN roads_near=", n)
		get_tree().quit()
