extends Node
## Frame-time spike finder (headless): teleports the car along a line at 40 m/s and reports slow frames. args: <quality> <dx> <dz> <secs>
var gw: GameWorld
var t := 0.0
var secs := 60.0
var dir := Vector3(1, 0, 0)
var last := 0
var n := 0
var tot := 0.0
var spikes: Array = []
var rb := 0
var bb := 0
func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	G.quality = int(a[0]) if a.size() > 0 else 0
	dir = Vector3(float(a[1]) if a.size() > 1 else 1.0, 0.0, float(a[2]) if a.size() > 2 else 0.0).normalized()
	secs = float(a[3]) if a.size() > 3 else 60.0
	G.start_hour = 11.0
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)
	if a.size() > 4 and a[4] == "nocol":
		gw.blds.collide = false
func _physics_process(dt: float) -> void:
	t += dt
	if t > 2.0:
		var p := gw.player
		p.global_position += dir * 40.0 * dt
		p.linear_velocity = dir * 40.0
		p.global_position.y = W.ground_height(p.global_position.x, p.global_position.z) + 300.0
func _process(_d: float) -> void:
	var now := Time.get_ticks_usec()
	if last > 0 and t > 2.0:
		var ms := float(now - last) / 1000.0
		n += 1
		tot += ms
		var r: int = gw.roads.built.size()
		var b: int = gw.blds.live.size()
		if ms > 14.0:
			spikes.append([snappedf(ms, 0.1), snappedf(t, 0.1), "road+" if r != rb else "", "bld+" if b != bb else ""])
		rb = r
		bb = b
	last = now
	if t > secs:
		spikes.sort_custom(func(x, y): return x[0] > y[0])
		print("SPIKE q=", G.quality, " frames ", n, " avg ", snappedf(tot / maxf(n, 1.0), 0.01), "ms spikes>14ms: ", spikes.size(), " pos ", gw.player.global_position.snapped(Vector3.ONE))
		for i in mini(spikes.size(), 10):
			print("SPIKE top ", spikes[i])
		get_tree().quit()
