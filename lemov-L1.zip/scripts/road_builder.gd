class_name RoadBuilder
extends Node3D
## Streams road, sidewalk, junction and bridge meshes in 600 m cells around the camera.

const CELL := 600.0
const STYLE := {"dirt": 0, "street": 1, "avenue": 2, "main": 3, "highway": 3, "runway": 4, "track": 5, "pass": 6}
const LIFT := {"dirt": 0.0, "street": 0.0, "avenue": 0.04, "main": 0.05, "highway": 0.07, "runway": 0.0, "track": 0.0, "pass": 0.05}

var road_mat: ShaderMaterial
var side_mat: StandardMaterial3D
var bridge_mat: StandardMaterial3D
var cum_s: Array = []                  # per road: cumulative metres
var cell_runs := {}                    # cell id -> Array of [road, a, b]
var cell_junctions := {}               # cell id -> Array of [x, z, ang, signal]
var built := {}                        # cell id -> Node3D
var radius_cells := 4
var road_end := 3200.0
var side_end := 900.0
var queue: Array = []
var per_frame := 2
const SEG_CELL := 32.0


func _cell_id(cx: int, cz: int) -> int:
	return cx * 1000 + cz


func _cell_of(x: float, z: float) -> Vector2i:
	return Vector2i(int(floor((x + W.half) / CELL)), int(floor((z + W.half) / CELL)))


func _ready() -> void:
	radius_cells = int(Q.get_v("road_cells"))
	road_end = Q.get_v("road_dist")
	side_end = Q.get_v("side_dist")
	road_mat = ShaderMaterial.new()
	road_mat.shader = load("res://shaders/road.gdshader")
	var T := "res://assets/textures/"
	road_mat.set_shader_parameter("asph_a", load(T + "asphalt_albedo.png"))
	road_mat.set_shader_parameter("asph_n", load(T + "asphalt_normal.png"))
	road_mat.set_shader_parameter("asph_r", load(T + "asphalt_rough.png"))
	road_mat.set_shader_parameter("sand_a", load(T + "sand_albedo.png"))
	side_mat = StandardMaterial3D.new()
	side_mat.albedo_texture = load(T + "concrete_albedo.png")
	side_mat.normal_enabled = true
	side_mat.normal_texture = load(T + "concrete_normal.png")
	side_mat.uv1_triplanar = true
	side_mat.uv1_world_triplanar = true
	side_mat.uv1_scale = Vector3(0.22, 0.22, 0.22)
	side_mat.roughness = 0.92
	side_mat.albedo_color = Color(0.82, 0.82, 0.80)
	bridge_mat = side_mat.duplicate()
	bridge_mat.albedo_color = Color(0.7, 0.7, 0.72)
	_prepare()


## Thread-local index of the road segments around one 600 m cell (built inside the worker job): flat arrays + a 32 m grid, every segment
## registered over its own carriageway width + 1 m.
class SegIdx:
	var g := {}                          # Vector2i -> PackedInt32Array of slots
	var ri := PackedInt32Array()
	var ax := PackedFloat32Array()
	var az := PackedFloat32Array()
	var ay := PackedFloat32Array()
	var by := PackedFloat32Array()
	var abx := PackedFloat32Array()
	var abz := PackedFloat32Array()
	var ln := PackedFloat32Array()
	var hw := PackedFloat32Array()       # half carriageway width - 0.2
	var seg := PackedInt32Array()


func _local_index(id: int) -> SegIdx:
	var s := SegIdx.new()
	var cx := id / 1000
	var cz := id % 1000
	var tmp := {}
	var bx0 := float(cx) * CELL - W.half - 80.0
	var bx1 := float(cx + 1) * CELL - W.half + 80.0
	var bz0 := float(cz) * CELL - W.half - 80.0
	var bz1 := float(cz + 1) * CELL - W.half + 80.0
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			var nid := _cell_id(cx + dx, cz + dz)
			if not cell_runs.has(nid):
				continue
			for run in cell_runs[nid]:
				var rj: int = run[0]
				var r: Dictionary = W.roads[rj]
				if r["cls"] == "runway":
					continue
				var pts: PackedVector3Array = r["pts"]
				var br: PackedByteArray = r["bridge"]
				var half := float(r["width"]) * 0.5 - 0.2
				var pad := half + 1.2
				for i in range(run[1], run[2] + 1):
					if br[i] != 0:
						continue
					var a := pts[i]
					var b := pts[i + 1]
					if maxf(a.x, b.x) < bx0 or minf(a.x, b.x) > bx1 or maxf(a.z, b.z) < bz0 or minf(a.z, b.z) > bz1:
						continue                                # far outside this cell
					var abx := b.x - a.x
					var abz := b.z - a.z
					var ln := sqrt(abx * abx + abz * abz)
					if ln < 0.01:
						continue
					var slot := s.ri.size()
					s.ri.append(rj)
					s.ax.append(a.x)
					s.az.append(a.z)
					s.ay.append(a.y)
					s.by.append(b.y)
					s.abx.append(abx)
					s.abz.append(abz)
					s.ln.append(ln)
					s.hw.append(half)
					s.seg.append(i)
					var x0 := int(floor((minf(a.x, b.x) - pad) / SEG_CELL))
					var x1 := int(floor((maxf(a.x, b.x) + pad) / SEG_CELL))
					var z0 := int(floor((minf(a.z, b.z) - pad) / SEG_CELL))
					var z1 := int(floor((maxf(a.z, b.z) + pad) / SEG_CELL))
					for gx in range(x0, x1 + 1):
						for gz in range(z0, z1 + 1):
							var key := Vector2i(gx, gz)
							if tmp.has(key):
								tmp[key].append(slot)
							else:
								tmp[key] = [slot]
	for key in tmp.keys():
		s.g[key] = PackedInt32Array(tmp[key])
	return s


## True when (x, z) lies inside the carriageway of another road that crosses direction `dir` (parallel / other-level roads are ignored).
func _in_other_road(s: SegIdx, x: float, z: float, y: float, dir: Vector3, ri: int) -> bool:
	var key := Vector2i(int(floor(x / SEG_CELL)), int(floor(z / SEG_CELL)))
	if not s.g.has(key):
		return false
	var lst: PackedInt32Array = s.g[key]
	var rid := s.ri
	var ax := s.ax
	var az := s.az
	var ay := s.ay
	var by := s.by
	var abxs := s.abx
	var abzs := s.abz
	var lns := s.ln
	var hws := s.hw
	for k in lst:
		if rid[k] == ri:
			continue
		var ln := lns[k]
		var abx := abxs[k]
		var abz := abzs[k]
		if absf(dir.x * abz - dir.z * abx) < 0.35 * ln:
			continue                                        # (nearly) parallel: merging / overlapping roads keep their sidewalks
		if absf(ay[k] - y) > 3.0 and absf(by[k] - y) > 3.0:
			continue                                        # different level (overpass)
		var t := clampf(((x - ax[k]) * abx + (z - az[k]) * abz) / (ln * ln), 0.0, 1.0)
		var dx := x - (ax[k] + abx * t)
		var dz := z - (az[k] + abz * t)
		var h := hws[k]
		if dx * dx + dz * dz < h * h:
			return true
	return false


## True when the box [x0, x1] x [z0, z1] touches the (padded) box of another crossing road segment - decides where a sidewalk needs fine sampling.
func _other_road_near(s: SegIdx, x0: float, z0: float, x1: float, z1: float, y: float, dir: Vector3, ri: int) -> bool:
	var rid := s.ri
	for cx in range(int(floor(x0 / SEG_CELL)), int(floor(x1 / SEG_CELL)) + 1):
		for cz in range(int(floor(z0 / SEG_CELL)), int(floor(z1 / SEG_CELL)) + 1):
			var key := Vector2i(cx, cz)
			if not s.g.has(key):
				continue
			var lst: PackedInt32Array = s.g[key]
			for k in lst:
				if rid[k] == ri:
					continue
				var abx := s.abx[k]
				var abz := s.abz[k]
				if absf(dir.x * abz - dir.z * abx) < 0.35 * s.ln[k]:
					continue
				if absf(s.ay[k] - y) > 3.0 and absf(s.by[k] - y) > 3.0:
					continue
				var pad := s.hw[k] + 1.2
				var ex := s.ax[k] + abx
				var ez := s.az[k] + abz
				if minf(s.ax[k], ex) - pad > x1 or maxf(s.ax[k], ex) + pad < x0 or minf(s.az[k], ez) - pad > z1 or maxf(s.az[k], ez) + pad < z0:
					continue
				return true
	return false


## Sidewalk (curb) strips of one road run. They stop exactly at every other road's carriageway (junctions, T-junctions, found by
## bisection) and get end caps, so a crossing road is never covered by a strip.
func _build_sidewalks(side: MeshUtil, ri: int, a: int, b: int, sx: SegIdx) -> void:
	var r: Dictionary = W.roads[ri]
	var pts: PackedVector3Array = r["pts"]
	var br: PackedByteArray = r["bridge"]
	var hw := float(r["width"]) * 0.5
	var lift: float = LIFT.get(String(r["cls"]), 0.0)
	var s_arr: PackedFloat32Array = cum_s[ri]
	var sw := 1.7
	var hh := 0.16
	var prev := [-1, -1]                  # first vertex of the previous 4-vertex block per side (0 left, 1 right)
	var prev_ti := [Vector3.ZERO, Vector3.ZERO]
	var prev_to := [Vector3.ZERO, Vector3.ZERO]
	var prev_t := [Vector3.ZERO, Vector3.ZERO]
	for i in range(a, b + 2):
		var p := pts[i]
		var t0 := _tangent_at(pts, i)
		var q := p
		var t1 := t0
		var seg_len := 0.0
		var near := false
		if i <= b:
			q = pts[i + 1]
			t1 = _tangent_at(pts, i + 1)
			seg_len = Vector2(q.x - p.x, q.z - p.z).length()
			if br[i] == 0 and seg_len > 0.5:
				var m := maxi(int(ceil(seg_len / 16.0)), 1)
				var reach := hw + sw + 1.0
				for j in m:
					var c0 := p.lerp(q, float(j) / float(m))
					var c1 := p.lerp(q, float(j + 1) / float(m))
					if _other_road_near(sx, minf(c0.x, c1.x) - reach, minf(c0.z, c1.z) - reach, maxf(c0.x, c1.x) + reach, maxf(c0.z, c1.z) + reach, p.y, t0, ri):
						near = true
						break
		for sd in 2:
			var samples: Array = [[0.0, true]]
			var e0 := _sw_edges(p, q, t0, t1, 0.0, sd, hw, sw, lift)
			var ok0 := br[i] == 0 and _sw_valid(sx, e0, ri)
			samples[0][1] = ok0
			if near:
				var n := clampi(int(ceil(seg_len / 4.0)), 2, 24)
				var pf := 0.0
				var pok := ok0
				for k in range(1, n):
					var f := float(k) / float(n)
					var okk := _sw_valid(sx, _sw_edges(p, q, t0, t1, f, sd, hw, sw, lift), ri)
					if okk != pok:
						var lo := pf
						var hi := f
						for it in 5:
							var mf := (lo + hi) * 0.5
							if _sw_valid(sx, _sw_edges(p, q, t0, t1, mf, sd, hw, sw, lift), ri) == pok:
								lo = mf
							else:
								hi = mf
						samples.append([lo, pok])
						samples.append([hi, okk])
					pf = f
					pok = okk
			for sm in samples:
				var f: float = sm[0]
				var e := _sw_edges(p, q, t0, t1, f, sd, hw, sw, lift)
				var s := lerpf(s_arr[i], s_arr[mini(i + 1, pts.size() - 1)], f)
				if not sm[1]:
					if prev[sd] >= 0:
						_sidewalk_cap(side, prev_ti[sd], prev_to[sd], hh, prev_t[sd], s)
					prev[sd] = -1
					continue
				var e_in: Vector3 = e[0]
				var e_out: Vector3 = e[1]
				var t: Vector3 = e[2]
				var outv: Vector3 = e[3]
				var ti := Vector3(e_in.x, e_in.y + hh, e_in.z)
				var tout := Vector3(e_out.x, e_in.y + hh, e_out.z)
				var vi := side.add_vertex(ti, Vector3.UP, Vector2(0, s), Color.WHITE)
				side.add_vertex(tout, Vector3.UP, Vector2(1, s), Color.WHITE)
				side.add_vertex(ti, -outv, Vector2(0, s), Color.WHITE)
				side.add_vertex(e_in, -outv, Vector2(1, s), Color.WHITE)
				if prev[sd] >= 0:
					var pv: int = prev[sd]
					side.quad_auto(pv, pv + 1, vi + 1, vi, Vector3.UP)
					side.quad_auto(pv + 2, pv + 3, vi + 3, vi + 2, -outv)
				else:
					_sidewalk_cap(side, ti, tout, hh, -t, s)
				prev[sd] = vi
				prev_ti[sd] = ti
				prev_to[sd] = tout
				prev_t[sd] = t
	for sd in 2:
		if prev[sd] >= 0:
			_sidewalk_cap(side, prev_ti[sd], prev_to[sd], hh, prev_t[sd], 0.0)


## Inner / outer edge points of one sidewalk side at fraction f of the segment p -> q: [inner, outer, tangent, outward].
func _sw_edges(p: Vector3, q: Vector3, t0: Vector3, t1: Vector3, f: float, sd: int, hw: float, sw: float, lift: float) -> Array:
	var pos := p.lerp(q, f)
	var t := t0.lerp(t1, f)
	t = t.normalized() if t.length() > 0.001 else t0
	var outv := Vector3(t.z, 0, -t.x) if sd == 0 else Vector3(-t.z, 0, t.x)
	var base := Vector3(pos.x, pos.y + lift, pos.z)
	return [base + outv * hw, base + outv * (hw + sw), t, outv]


func _sw_valid(sx: SegIdx, e: Array, ri: int) -> bool:
	var a: Vector3 = e[0]
	var b: Vector3 = e[1]
	var t: Vector3 = e[2]
	return not _in_other_road(sx, a.x, a.z, a.y, t, ri) and not _in_other_road(sx, b.x, b.z, b.y, t, ri)


## Vertical end face of a sidewalk strip (top edge inner -> outer), facing `n`.
func _sidewalk_cap(side: MeshUtil, ti: Vector3, tout: Vector3, h: float, n: Vector3, s: float) -> void:
	var c0 := side.add_vertex(ti, n, Vector2(0, s), Color.WHITE)
	var c1 := side.add_vertex(tout, n, Vector2(1, s), Color.WHITE)
	var c2 := side.add_vertex(tout - Vector3(0, h, 0), n, Vector2(1, s), Color.WHITE)
	var c3 := side.add_vertex(ti - Vector3(0, h, 0), n, Vector2(0, s), Color.WHITE)
	side.quad_auto(c0, c1, c2, c3, n)


func _prepare() -> void:
	cum_s.clear()
	cell_runs.clear()
	for ri in W.roads.size():
		var r: Dictionary = W.roads[ri]
		var pts: PackedVector3Array = r["pts"]
		var s := PackedFloat32Array()
		s.resize(pts.size())
		var acc := 0.0
		for i in pts.size():
			if i > 0:
				acc += Vector2(pts[i].x - pts[i - 1].x, pts[i].z - pts[i - 1].z).length()
			s[i] = acc
		cum_s.append(s)
		var run_a := 0
		var cur := Vector2i(-99, -99)
		for i in range(pts.size() - 1):
			var mx := (pts[i].x + pts[i + 1].x) * 0.5
			var mz := (pts[i].z + pts[i + 1].z) * 0.5
			var c := _cell_of(mx, mz)
			if c != cur:
				if cur.x != -99:
					_add_run(cur, ri, run_a, i - 1)
				cur = c
				run_a = i
		if cur.x != -99:
			_add_run(cur, ri, run_a, pts.size() - 2)
	var inter := W.intersections
	for k in range(0, inter.size(), 4):
		var c := _cell_of(inter[k], inter[k + 1])
		var id := _cell_id(c.x, c.y)
		if not cell_junctions.has(id):
			cell_junctions[id] = []
		cell_junctions[id].append([inter[k], inter[k + 1], inter[k + 2], inter[k + 3], k / 4])


func _add_run(c: Vector2i, ri: int, a: int, b: int) -> void:
	var id := _cell_id(c.x, c.y)
	if not cell_runs.has(id):
		cell_runs[id] = []
	cell_runs[id].append([ri, a, b])


func update_focus(p: Vector3) -> void:
	_poll_jobs()
	var c := _cell_of(p.x, p.z)
	var rc := radius_cells
	var want := {}
	for dx in range(-rc, rc + 1):
		for dz in range(-rc, rc + 1):
			var cc := Vector2i(c.x + dx, c.y + dz)
			if cc.x < 0 or cc.y < 0:
				continue
			var id := _cell_id(cc.x, cc.y)
			want[id] = true
			if not built.has(id) and (cell_runs.has(id) or cell_junctions.has(id)) and not queue.has(id) and not _jobs.has(id):
				queue.append(id)
	_want = want
	# unload far cells
	for id in built.keys():
		if not want.has(id):
			built[id].queue_free()
			built.erase(id)
	queue.sort_custom(func(a, b): return _dist_cell(a, p) < _dist_cell(b, p))
	var n := 0
	while queue.size() > 0 and n < per_frame and _jobs.size() < 3:
		var id: int = queue.pop_front()
		if want.has(id):
			_start_job(id)
			n += 1


func build_all_near(p: Vector3, rc: int) -> void:
	var c := _cell_of(p.x, p.z)
	for dx in range(-rc, rc + 1):
		for dz in range(-rc, rc + 1):
			var id := _cell_id(c.x + dx, c.y + dz)
			if not built.has(id) and (cell_runs.has(id) or cell_junctions.has(id)):
				_build_cell(id)


func _dist_cell(id: int, p: Vector3) -> float:
	var cx := id / 1000
	var cz := id % 1000
	return Vector2((cx + 0.5) * CELL - W.half - p.x, (cz + 0.5) * CELL - W.half - p.z).length()


# ---------------------------------------------------------------- mesh building
## Road cells are generated on worker threads (pure data); node/mesh creation stays on the main thread.
var _jobs := {}                         # cell id -> [task id, result array]
var _want := {}


func _exit_tree() -> void:
	for id in _jobs.keys():
		WorkerThreadPool.wait_for_task_completion(_jobs[id][0])
	_jobs.clear()


func _gen_cell(id: int, out: Array) -> void:
	var road := MeshUtil.new()
	road.with_tangents = true
	road.with_uv2 = true
	var side := MeshUtil.new()
	var bridge := MeshUtil.new()
	if cell_runs.has(id):
		var sx := _local_index(id)
		for run in cell_runs[id]:
			_build_run(road, side, bridge, run[0], run[1], run[2], sx)
	if cell_junctions.has(id):
		_build_junctions(road, id)
	out.append(road)
	out.append(side)
	out.append(bridge)


func _start_job(id: int) -> void:
	var out: Array = []
	_jobs[id] = [WorkerThreadPool.add_task(_gen_cell.bind(id, out), false, "road cell"), out]


func _poll_jobs() -> void:
	for id in _jobs.keys():
		var j: Array = _jobs[id]
		if WorkerThreadPool.is_task_completed(j[0]):
			WorkerThreadPool.wait_for_task_completion(j[0])
			_jobs.erase(id)
			if _want.has(id):
				_finish_cell(id, j[1])
			return                      # one mesh upload per frame


## Synchronous build (spawn / teleport).
func _build_cell(id: int) -> void:
	if _jobs.has(id):
		WorkerThreadPool.wait_for_task_completion(_jobs[id][0])
		_jobs.erase(id)
	var out: Array = []
	_gen_cell(id, out)
	_finish_cell(id, out)


func _finish_cell(id: int, out: Array) -> void:
	var road: MeshUtil = out[0]
	var side: MeshUtil = out[1]
	var bridge: MeshUtil = out[2]
	if built.has(id):
		built[id].queue_free()
	var node := Node3D.new()
	node.name = "road_%d" % id
	if road.vertex_count() > 0:
		var mi := MeshInstance3D.new()
		mi.mesh = road.build(road_mat)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.visibility_range_end = road_end
		node.add_child(mi)
	if side.vertex_count() > 0:
		var ms := MeshInstance3D.new()
		ms.mesh = side.build(side_mat)
		ms.visibility_range_end = side_end
		node.add_child(ms)
	if bridge.vertex_count() > 0:
		var mb := MeshInstance3D.new()
		mb.mesh = bridge.build(bridge_mat)
		mb.visibility_range_end = minf(1800.0, road_end)
		node.add_child(mb)
		_bridge_colliders(node, bridge)
	add_child(node)
	built[id] = node


func _tangent_at(pts: PackedVector3Array, i: int) -> Vector3:
	var a := pts[maxi(i - 1, 0)]
	var b := pts[mini(i + 1, pts.size() - 1)]
	var t := Vector3(b.x - a.x, 0, b.z - a.z)
	if t.length() < 0.001:
		return Vector3.FORWARD
	return t.normalized()


func _build_run(road: MeshUtil, side: MeshUtil, bridge: MeshUtil, ri: int, a: int, b: int, sx: SegIdx) -> void:
	var r: Dictionary = W.roads[ri]
	var pts: PackedVector3Array = r["pts"]
	var br: PackedByteArray = r["bridge"]
	var cls: String = r["cls"]
	var name: String = r["name"]
	var style: int = STYLE.get(cls, 1)
	if name.begins_with("Taxi"):
		style = 7
	if (cls == "main" or cls == "highway") and float(r["width"]) < 12.0 and not name.begins_with("Taxi"):
		style = 3
	var hw := float(r["width"]) * 0.5
	var lift: float = LIFT.get(cls, 0.0)
	var s_arr: PackedFloat32Array = cum_s[ri]
	var total: float = s_arr[s_arr.size() - 1]
	var rnd := fposmod(float(ri) * 0.6180339, 1.0)
	var vcol := Color(style / 10.0, float(r["width"]) / 64.0, rnd, 1.0)
	var is_city := cls == "street" or cls == "avenue"
	var first := -1
	var prev_l := -1
	var prev_r := -1
	for i in range(a, b + 2):
		var p := pts[i]
		var t := _tangent_at(pts, i)
		var nrm := Vector3(-t.z, 0, t.x)
		var y := p.y + lift
		var l := Vector3(p.x, y, p.z) - nrm * hw
		var rr := Vector3(p.x, y, p.z) + nrm * hw
		var s := s_arr[i]
		var vl := road.add_vertex(l, Vector3.UP, Vector2(0.0, s), vcol, Vector2(s, total - s))
		var vr := road.add_vertex(rr, Vector3.UP, Vector2(1.0, s), vcol, Vector2(s, total - s))
		if prev_l >= 0:
			road.quad_auto(prev_l, prev_r, vr, vl, Vector3.UP)
		prev_l = vl
		prev_r = vr
	if is_city:
		_build_sidewalks(side, ri, a, b, sx)
	# bridges
	var in_bridge := false
	var last_pillar := -9999.0
	for i in range(a, b + 1):
		if br[i] == 0:
			continue
		var p := pts[i]
		var q := pts[i + 1]
		var t := _tangent_at(pts, i)
		var nrm := Vector3(-t.z, 0, t.x)
		var y0 := p.y + lift
		var y1 := q.y + lift
		var tq := _tangent_at(pts, i + 1)
		var nq := Vector3(-tq.z, 0, tq.x)
		# deck sides and underside
		for sgn_v in [-1.0, 1.0]:
			var sgn: float = sgn_v
			var e0 := Vector3(p.x, y0, p.z) + nrm * hw * sgn
			var e1 := Vector3(q.x, y1, q.z) + nq * hw * sgn
			var on: Vector3 = nrm * sgn
			var v0 := bridge.add_vertex(e0, on, Vector2(0, 0), Color.WHITE)
			var v1 := bridge.add_vertex(e1, on, Vector2(1, 0), Color.WHITE)
			var v2 := bridge.add_vertex(e0 - Vector3(0, 1.5, 0), on, Vector2(0, 1), Color.WHITE)
			var v3 := bridge.add_vertex(e1 - Vector3(0, 1.5, 0), on, Vector2(1, 1), Color.WHITE)
			bridge.quad_auto(v0, v1, v3, v2, on)
			# parapet (top face + inner face)
			var h := 1.0
			var inner := -on
			var w0 := e0 + Vector3(0, h, 0)
			var w1 := e1 + Vector3(0, h, 0)
			var k0 := bridge.add_vertex(w0, Vector3.UP, Vector2(0, 0), Color.WHITE)
			var k1 := bridge.add_vertex(w1, Vector3.UP, Vector2(1, 0), Color.WHITE)
			var k2 := bridge.add_vertex(w0 + inner * 0.35, Vector3.UP, Vector2(0, 1), Color.WHITE)
			var k3 := bridge.add_vertex(w1 + inner * 0.35, Vector3.UP, Vector2(1, 1), Color.WHITE)
			bridge.quad_auto(k0, k1, k3, k2, Vector3.UP)
			var f0 := bridge.add_vertex(w0 + inner * 0.35, inner, Vector2(0, 0), Color.WHITE)
			var f1 := bridge.add_vertex(w1 + inner * 0.35, inner, Vector2(1, 0), Color.WHITE)
			var f2 := bridge.add_vertex(e0 + inner * 0.35, inner, Vector2(0, 1), Color.WHITE)
			var f3 := bridge.add_vertex(e1 + inner * 0.35, inner, Vector2(1, 1), Color.WHITE)
			bridge.quad_auto(f0, f1, f3, f2, inner)
		# underside
		var u0 := Vector3(p.x, y0 - 1.5, p.z) - nrm * hw
		var u1 := Vector3(p.x, y0 - 1.5, p.z) + nrm * hw
		var u2 := Vector3(q.x, y1 - 1.5, q.z) - nq * hw
		var u3 := Vector3(q.x, y1 - 1.5, q.z) + nq * hw
		var b0 := bridge.add_vertex(u0, Vector3.DOWN, Vector2(0, 0), Color.WHITE)
		var b1 := bridge.add_vertex(u1, Vector3.DOWN, Vector2(1, 0), Color.WHITE)
		var b2 := bridge.add_vertex(u2, Vector3.DOWN, Vector2(0, 1), Color.WHITE)
		var b3 := bridge.add_vertex(u3, Vector3.DOWN, Vector2(1, 1), Color.WHITE)
		bridge.quad_auto(b0, b1, b3, b2, Vector3.DOWN)
		# pillars every ~28 m
		if s_arr[i] - last_pillar > 28.0:
			last_pillar = s_arr[i]
			var ground := W.terrain_height(p.x, p.z) - 3.0
			var top := y0 - 1.5
			if top - ground > 1.0:
				var ang := atan2(t.x, t.z)
				bridge.box(Vector3(p.x, (top + ground) * 0.5, p.z), Vector3(hw * 1.1, top - ground, 1.8), ang + PI * 0.5, Color.WHITE, 0.3, false, false)


func _bridge_colliders(node: Node3D, bridge: MeshUtil) -> void:
	# bridge decks are driven on through W.ground_height(); only the parapets need collision.
	pass


func _build_junctions(road: MeshUtil, id: int) -> void:
	var runs: Array = cell_runs.get(id, [])
	for j in cell_junctions[id]:
		var x: float = j[0]
		var z: float = j[1]
		var ang: float = j[2]
		var big: bool = j[3] > 0.5
		# find nearest road sample height in this cell
		var best_y := W.terrain_height(x, z) + 0.2
		var bd := 1e9
		for run in runs:
			var pts: PackedVector3Array = W.roads[run[0]]["pts"]
			for i in range(run[1], run[2] + 2, 2):
				var d := (pts[i].x - x) * (pts[i].x - x) + (pts[i].z - z) * (pts[i].z - z)
				if d < bd:
					bd = d
					best_y = pts[i].y
		if bd > 400.0:
			continue
		var half := (8.5 if big else 5.5) + 3.0
		var y := best_y + 0.08
		var cs := cos(ang)
		var sn := sin(ang)
		var vcol := Color(0.8, half * 2.0 / 64.0, 0.5, 1.0)
		var vs := []
		for k in 4:
			var ux := -1.0 if (k == 0 or k == 2) else 1.0
			var uz := -1.0 if (k == 0 or k == 1) else 1.0
			var lx := ux * half
			var lz := uz * half
			var wx := x + lx * cs - lz * sn
			var wz := z + lx * sn + lz * cs
			vs.append(road.add_vertex(Vector3(wx, y, wz), Vector3.UP, Vector2((ux + 1.0) * 0.5, (uz + 1.0) * 0.5), vcol, Vector2(0, 0)))
		road.quad_auto(vs[0], vs[1], vs[3], vs[2], Vector3.UP)
