class_name CarDamage
extends RefCounted
## Zone / part damage model of one car: body zones, flaps (bonnet, boot, doors), engine, radiator, per-wheel strut + tyre, glass, lamps,
## fuel leak, engine temperature, fire and charring. Pure data and rules - the Vehicle turns it into visuals and driving effects.
## Local car space: x = left, y = up, z = forward.
## Zones: 0 FL  1 FC  2 FR  3 SL  4 SR  5 RL  6 RC  7 RR  8 ROOF  9 UNDER

var L := 4.5
var Wd := 1.9
var H := 1.3
var zone := PackedFloat32Array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
var engine := 0.0
var radiator := 0.0
var susp := PackedFloat32Array([0.0, 0.0, 0.0, 0.0])          # per wheel: bent strut / blown shock
var tyre := PackedFloat32Array([0.0, 0.0, 0.0, 0.0])          # per wheel: puncture / bent rim
var detached := [false, false, false, false]
var glass := 0.0                                              # windscreen / windows crack level
var lamp_f := 0.0
var lamp_r := 0.0
var hood := 0.0                                               # flaps: 0 shut .. 1 flung open
var trunk := 0.0
var door_l := 0.0
var door_r := 0.0
var fuel_leak := 0.0                                          # 0..1 tank / line damage
var fuel := 1.0                                               # tank level
var temp := 0.3                                               # engine temperature: 0.3 cold .. 0.5 normal .. 1 seized
var burn := 0.0                                               # charring 0..1
var fire := false
var fire_t := 0.0
var exploded := false
var wheel_pos: Array = []                                     # wheel hub positions (local) for hit tests
var gain := 1.0                                               # server tunable (damage_mult)
var hits := 0
var version := 0                                              # bumps on every change (visual refresh)
var _burn_v := 0.0
var _vt := 0.0


func configure(len_m: float, wid_m: float, h_m: float, wheels: Array, g: float = 1.0) -> void:
	L = len_m
	Wd = wid_m
	H = h_m
	wheel_pos = wheels
	gain = g


func _centers() -> Array:
	var y := 0.55 * H
	return [Vector3(0.28 * Wd, y, 0.36 * L), Vector3(0.0, y, 0.40 * L), Vector3(-0.28 * Wd, y, 0.36 * L),
		Vector3(0.45 * Wd, y, 0.0), Vector3(-0.45 * Wd, y, 0.0),
		Vector3(0.28 * Wd, y, -0.36 * L), Vector3(0.0, y, -0.40 * L), Vector3(-0.28 * Wd, y, -0.36 * L),
		Vector3(0.0, 1.0 * H, 0.0), Vector3(0.0, 0.05, 0.0)]


## Impact at local point p with normalised energy e (~0.35 = 40 km/h wall, ~1 = 75 km/h, 2.4 = 120 km/h: total front wreck).
func hit(p: Vector3, e_in: float) -> void:
	var e := e_in * gain
	if e <= 0.004:
		return
	hits += 1
	version += 1
	var cs := _centers()
	var sig2 := (0.27 * L) * (0.27 * L)
	var w: Array = []
	for i in 10:
		w.append(exp(-p.distance_squared_to(cs[i] as Vector3) / sig2))
	for i in 10:
		zone[i] = minf(zone[i] + e * float(w[i]) * 0.85, 1.0)
	var wf := maxf(float(w[0]), maxf(float(w[1]), float(w[2])))
	var wr := maxf(float(w[5]), maxf(float(w[6]), float(w[7])))
	var ws := maxf(float(w[3]), float(w[4]))
	if p.z > 0.12 * L:
		engine = minf(engine + e * 0.5 * float(w[1]) + e * 0.2 * wf, 1.0)
		radiator = minf(radiator + e * 0.75 * float(w[1]) + e * 0.15 * wf, 1.0)
		lamp_f = minf(lamp_f + e * 1.5 * wf, 1.0)
		if e > 0.55:
			glass = minf(glass + (e - 0.5) * 0.55 * wf, 1.0)
	if p.z < -0.12 * L:
		lamp_r = minf(lamp_r + e * 1.5 * wr, 1.0)
		if e > 0.55:
			glass = minf(glass + (e - 0.5) * 0.5 * wr, 1.0)
	if ws > 0.2:
		glass = minf(glass + e * 0.5 * ws, 1.0)
	glass = minf(glass + e * 0.7 * float(w[8]), 1.0)
	if p.y < 0.28:
		engine = minf(engine + e * 0.3 * float(w[9]), 1.0)
	# flaps
	if p.z > 0.15 * L and e > 0.9:
		hood = minf(hood + (e - 0.85) * 0.45 * wf, 1.0)
	if p.z < -0.18 * L and e > 1.1:
		trunk = minf(trunk + (e - 1.0) * 0.4 * wr, 1.0)
	if absf(p.z) < 0.28 * L and e > 0.7:
		if p.x > 0.25 * Wd:
			door_l = minf(door_l + (e - 0.6) * 0.5 * float(w[3]), 1.0)
		elif p.x < -0.25 * Wd:
			door_r = minf(door_r + (e - 0.6) * 0.5 * float(w[4]), 1.0)
	if e > 0.6 and (p.z < -0.05 * L or p.y < 0.3):
		fuel_leak = minf(fuel_leak + e * 0.3 * maxf(wr, float(w[9])), 1.0)
	for i in wheel_pos.size():
		var d2 := p.distance_squared_to(wheel_pos[i] as Vector3)
		var wi := exp(-d2 / 1.1)
		susp[i] = minf(susp[i] + e * 0.95 * wi, 1.0)
		tyre[i] = minf(tyre[i] + e * 0.6 * wi, 1.0)
		if susp[i] >= 1.0 and e > 0.7:
			detached[i] = true


## Light wear while scraping a wall: only paint / panel damage, no mechanical parts.
func scrape(p: Vector3, amount: float) -> void:
	if amount <= 0.0005:
		return
	version += 1
	var cs := _centers()
	var sig2 := (0.3 * L) * (0.3 * L)
	for i in 8:
		zone[i] = minf(zone[i] + amount * gain * exp(-p.distance_squared_to(cs[i] as Vector3) / sig2) * 0.5, 1.0)


## Per-frame mechanics: engine temperature, fuel leak, fire. Returns 1 when a fire starts, 2 when the car explodes, else 0.
func step(dt: float, spd: float, load: float, spark: bool) -> int:
	if hits == 0 and not fire:
		return 0
	var ev := 0
	var cool := (1.0 - radiator) * (0.035 + spd * 0.0016)
	var heat := 0.012 + 0.03 * load
	temp = clampf(temp + (heat - cool * (temp - 0.2) * 1.4) * dt * 0.8, 0.2, 1.05)
	if temp >= 1.0 and engine < 1.0:
		engine = minf(engine + dt * 0.08, 1.0)                 # an overheated engine seizes
	if fuel_leak > 0.05 and fuel > 0.0:
		fuel = maxf(fuel - fuel_leak * dt * 0.012, 0.0)
	if not fire and not exploded and burn < 1.0:
		var risk := 0.0
		if fuel_leak > 0.3 and fuel > 0.05 and spark:
			risk = 1.5 * fuel_leak
		if engine > 0.9 and temp > 0.97:
			risk = maxf(risk, 0.25)
		if risk > 0.0 and randf() < risk * dt:
			fire = true
			fire_t = 0.0
			ev = 1
			version += 1
	if fire:
		fire_t += dt
		burn = minf(burn + dt / 35.0, 1.0)
		engine = minf(engine + dt * 0.03, 1.0)
		fuel = maxf(fuel - dt * 0.01, 0.0)
		if fire_t > 12.0 and fuel > 0.2 and not exploded and randf() < dt * 0.25:
			exploded = true
			ev = 2
			version += 1
		if fire_t > 40.0 or (fuel <= 0.0 and fire_t > 8.0):
			fire = false                                       # burnt out
			version += 1
	_vt += dt
	if absf(burn - _burn_v) > 0.03 or (_vt > 0.5 and (fire or temp > 0.85)):
		_burn_v = burn
		_vt = 0.0
		version += 1
	return ev


func extinguish() -> void:
	if fire:
		fire = false
		version += 1


func repair() -> void:
	for i in 10:
		zone[i] = 0.0
	for i in 4:
		susp[i] = 0.0
		tyre[i] = 0.0
		detached[i] = false
	engine = 0.0
	radiator = 0.0
	glass = 0.0
	lamp_f = 0.0
	lamp_r = 0.0
	hood = 0.0
	trunk = 0.0
	door_l = 0.0
	door_r = 0.0
	fuel_leak = 0.0
	fuel = 1.0
	temp = 0.3
	burn = 0.0
	_burn_v = 0.0
	fire = false
	fire_t = 0.0
	exploded = false
	hits = 0
	version += 1


## Overall condition 0 (new) .. 1 (wrecked).
func overall() -> float:
	var m := 0.0
	var mx := 0.0
	for i in 9:
		m += zone[i]
		mx = maxf(mx, zone[i])
	m /= 9.0
	var sm := (susp[0] + susp[1] + susp[2] + susp[3]) * 0.25
	var core := clampf(0.4 * m + 0.25 * mx + 0.2 * engine + 0.1 * sm + 0.05 * glass, 0.0, 1.0)
	return maxf(core, burn * 0.9)


func front() -> float:
	return maxf(zone[0], maxf(zone[1], zone[2]))


func rear() -> float:
	return maxf(zone[5], maxf(zone[6], zone[7]))


func power_mult() -> float:
	if exploded or fuel <= 0.0:
		return 0.0
	var p := 1.0 - 0.62 * engine - 0.25 * radiator
	p *= 1.0 - 0.6 * smoothstep(0.85, 1.0, temp)             # overheating
	return clampf(p, 0.12, 1.0)


func brake_mult() -> float:
	return clampf(1.0 - 0.3 * maxf(susp[0], susp[1]) - 0.15 * front(), 0.5, 1.0)


func drag_mult() -> float:
	return 1.0 + 0.25 * (zone[0] + zone[1] + zone[2] + zone[3] + zone[4] + zone[5] + zone[6] + zone[7]) / 8.0 + 0.3 * hood


## Steering pull (rad): a bent / punctured side drags the car toward it.
func steer_pull() -> float:
	var s := 0.0
	for i in wheel_pos.size():
		var p: Vector3 = wheel_pos[i]
		var f := 1.0 if p.z > 0.0 else 0.45
		var bad := 0.9 if detached[i] else (susp[i] * 0.5 + tyre[i] * 0.5)
		s += signf(p.x) * bad * f
	return s * 0.07                                    # positive = toward the damaged +x side (steer + = right, so the caller subtracts)


## Bent tie-rods limit the steering lock.
func steer_limit() -> float:
	return clampf(1.0 - 0.45 * maxf(susp[0], susp[1]), 0.5, 1.0)


func grip_mult(i: int) -> float:
	if detached[i]:
		return 0.25
	return clampf(1.0 - 0.5 * tyre[i] - 0.12 * susp[i], 0.3, 1.0)


func spring_mult(i: int) -> float:
	return 1.0 - 0.4 * susp[i]


func damper_mult(i: int) -> float:
	return 1.0 - 0.7 * susp[i]


## Values packed for the car shaders: zd0 FL FC FR SL | zd1 SR RL RC RR | zd2 ROOF UNDER BURN 0 | zd3 hood boot doorL doorR.
func pack0() -> Vector4:
	return Vector4(zone[0], zone[1], zone[2], zone[3])


func pack1() -> Vector4:
	return Vector4(zone[4], zone[5], zone[6], zone[7])


func pack2() -> Vector4:
	return Vector4(zone[8], zone[9], burn, 0.0)


func pack3() -> Vector4:
	return Vector4(hood, trunk, door_l, door_r)


func any() -> bool:
	return hits > 0 or burn > 0.0 or fire
