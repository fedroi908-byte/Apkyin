extends SceneTree
## golden-vector self-test for remote.gd (signature, vault, hmac, buckets, WHEN, L10N).
## usage: godot --headless --path . --script res://scripts/vector_test.gd -- /path/to/vectors.json
var fails := 0
var total := 0


func _chk(ok: bool, what: String) -> void:
	total += 1
	if not ok:
		fails += 1
		print("FAIL ", what)


func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	var path := String(a[0]) if a.size() > 0 else "/home/claude/apex-server/vectors/vectors.json"
	var v: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	var RS: GDScript = load("res://scripts/remote.gd")
	var r: Node = RS.new()
	var salt: PackedByteArray = String(v["salt_hex"]).hex_decode()
	_chk(salt == String(RS.SALT_HEX).hex_decode(), "salt matches the vector")
	# --- RSA manifest signature
	var key: CryptoKey = r.make_key(String(v["rsa"]["pub_spki_b64"]))
	_chk(key != null, "make_key")
	_chk(r.verify_sig(String(v["manifest"]["text"]).to_utf8_buffer(), String(v["manifest"]["sig_b64"]), key), "manifest signature valid")
	_chk(not r.verify_sig(String(v["manifest_tampered"]["text"]).to_utf8_buffer(), String(v["manifest_tampered"]["sig_b64"]), key), "tampered manifest rejected")
	_chk(not r.verify_sig("x".to_utf8_buffer(), "AAAA", key), "short signature rejected")
	_chk(not r.verify_sig("x".to_utf8_buffer(), String(v["manifest"]["sig_b64"]), null), "null key rejected")
	# --- vault
	var vi := 0
	for e in v["vault"]:
		var spki: PackedByteArray = Marshalls.base64_to_raw(String(e["spki_b64"]))
		var want: Dictionary = JSON.parse_string(String(e["plain"]))
		var got: Dictionary = r.vault_open(String(e["blob_b64"]), spki, salt)
		_chk(JSON.stringify(got, "", true) == JSON.stringify(want, "", true), "vault %d decrypts" % vi)
		var blob: PackedByteArray = Marshalls.base64_to_raw(String(e["blob_b64"]))
		var bad := blob.duplicate()
		bad[14] = int(bad[14]) ^ 1
		_chk(r.vault_open(Marshalls.raw_to_base64(bad), spki, salt).is_empty(), "vault %d tamper rejected" % vi)
		var bad2 := blob.duplicate()
		bad2[bad2.size() - 1] = int(bad2[bad2.size() - 1]) ^ 1
		_chk(r.vault_open(Marshalls.raw_to_base64(bad2), spki, salt).is_empty(), "vault %d tag tamper rejected" % vi)
		_chk(r.vault_open(String(e["blob_b64"]), spki, "other".to_utf8_buffer()).is_empty(), "vault %d wrong salt rejected" % vi)
		vi += 1
	_chk(r.vault_open("", PackedByteArray(), salt).is_empty(), "empty vault")
	_chk(r.vault_open("AAAA", PackedByteArray(), salt).is_empty(), "short vault")
	# --- telemetry HMAC
	var hi := 0
	for e in v["hmac"]:
		_chk(r.hmac_hex(String(e["key"]), String(e["body"]).to_utf8_buffer()) == String(e["hex"]), "hmac %d" % hi)
		hi += 1
	# --- buckets
	for e in v["buckets"]:
		_chk(r.bucket_of(String(e["iid"])) == int(e["bucket"]), "bucket " + String(e["iid"]))
	# --- WHEN targeting
	var wi := 0
	for e in v["when"]:
		var ctx: Dictionary = e["ctx"]
		_chk(RS.when_match(e["when"], ctx) == bool(e["expect"]), "when %d %s" % [wi, JSON.stringify(e["when"])])
		wi += 1
	# --- L10N
	var li := 0
	for e in v["l10n"]:
		_chk(RS.l10n(e["v"], String(e["lang"])) == String(e["out"]), "l10n %d" % li)
		li += 1
	r.free()
	print("VECTOR_TEST total=", total, " fails=", fails)
	quit(1 if fails > 0 else 0)
