class_name Tx
extends RefCounted
## Fixed texts of the online features in uz / ru / en (texts that come from the server are already translated).

const S := {
	"you": {"en": "YOU", "uz": "SIZ", "ru": "ВЫ"},
	"lap": {"en": "LAP", "uz": "AYLANA", "ru": "КРУГ"},
	"laps": {"en": "LAPS", "uz": "AYLANA", "ru": "КРУГОВ"},
	"rivals": {"en": "RIVALS", "uz": "RAQIBLAR", "ru": "СОПЕРНИКИ"},
	"grid": {"en": "GRID", "uz": "START", "ru": "СТАРТ"},
	"wrong_way": {"en": "WRONG WAY!", "uz": "TESKARI YO'NALISH!", "ru": "НЕ ТУДА!"},
	"results": {"en": "RESULTS", "uz": "NATIJALAR", "ru": "РЕЗУЛЬТАТЫ"},
	"position": {"en": "POSITION", "uz": "O'RIN", "ru": "МЕСТО"},
	"maint_t": {"en": "UNDER MAINTENANCE", "uz": "TEXNIK ISHLAR", "ru": "ТЕХНИЧЕСКИЕ РАБОТЫ"},
	"maint_b": {"en": "We are improving the game. Please come back in a few minutes.", "uz": "O'yin yaxshilanmoqda. Bir necha daqiqadan keyin qayta urinib ko'ring.", "ru": "Мы улучшаем игру. Загляните через несколько минут."},
	"upd_t": {"en": "UPDATE REQUIRED", "uz": "YANGILANISH KERAK", "ru": "ТРЕБУЕТСЯ ОБНОВЛЕНИЕ"},
	"upd_b": {"en": "Please install the latest version to keep playing.", "uz": "O'ynashni davom ettirish uchun so'nggi versiyani o'rnating.", "ru": "Установите последнюю версию, чтобы продолжить игру."},
	"upd_btn": {"en": "DOWNLOAD UPDATE", "uz": "YANGILANISHNI YUKLASH", "ru": "СКАЧАТЬ ОБНОВЛЕНИЕ"},
	"lock_t": {"en": "ACCESS RESTRICTED", "uz": "KIRISH CHEKLANGAN", "ru": "ДОСТУП ОГРАНИЧЕН"},
	"lock_b": {"en": "This installation is temporarily blocked.", "uz": "Bu o'rnatish vaqtincha bloklangan.", "ru": "Эта установка временно заблокирована."},
	"retry": {"en": "TRY AGAIN", "uz": "QAYTA URINISH", "ru": "ПОВТОРИТЬ"},
	"retry_in": {"en": "Checking again in %d s", "uz": "%d soniyadan keyin qayta tekshiriladi", "ru": "Повторная проверка через %d с"},
	"quit": {"en": "QUIT", "uz": "CHIQISH", "ru": "ВЫХОД"},
	"ok": {"en": "OK", "uz": "OK", "ru": "ОК"},
	"new_ver": {"en": "NEW VERSION %s", "uz": "YANGI VERSIYA %s", "ru": "НОВАЯ ВЕРСИЯ %s"},
	"update": {"en": "UPDATE", "uz": "YANGILASH", "ru": "ОБНОВИТЬ"},
	"dl": {"en": "DOWNLOADING  %d%%", "uz": "YUKLANMOQDA  %d%%", "ru": "ЗАГРУЗКА  %d%%"},
	"news": {"en": "NEWS", "uz": "YANGILIKLAR", "ru": "НОВОСТИ"},
	"new_tag": {"en": "NEW", "uz": "YANGI", "ru": "НОВОЕ"},
	"back": {"en": "BACK", "uz": "ORQAGA", "ru": "НАЗАД"},
	"no_news": {"en": "No news yet.", "uz": "Hozircha yangilik yo'q.", "ru": "Новостей пока нет."},
	"see_car": {"en": "VIEW %s", "uz": "%s NI KO'RISH", "ru": "СМОТРЕТЬ %s"},
	"ad": {"en": "AD", "uz": "REKLAMA", "ru": "РЕКЛАМА"},
	"skip_in": {"en": "Skip in %d", "uz": "%d soniyadan keyin yopish mumkin", "ru": "Пропустить через %d"},
	"close": {"en": "CLOSE  ✕", "uz": "YOPISH  ✕", "ru": "ЗАКРЫТЬ  ✕"},
	"reward_in": {"en": "Reward in %d s", "uz": "Mukofot %d soniyadan keyin", "ru": "Награда через %d с"},
	"claim": {"en": "CLAIM  +%d $", "uz": "OLISH  +%d $", "ru": "ПОЛУЧИТЬ  +%d $"},
	"watch": {"en": "WATCH AD  +%d $", "uz": "REKLAMA KO'RISH  +%d $", "ru": "СМОТРЕТЬ РЕКЛАМУ  +%d $"},
	"promo": {"en": "NEW: %s", "uz": "YANGI: %s", "ru": "НОВИНКА: %s"},
	"online": {"en": "ONLINE", "uz": "ONLAYN", "ru": "ОНЛАЙН"},
	"stats": {"en": "ANONYMOUS STATISTICS", "uz": "ANONIM STATISTIKA", "ru": "АНОНИМНАЯ СТАТИСТИКА"},
	"mobile_dl": {"en": "DOWNLOAD ON MOBILE DATA", "uz": "MOBIL INTERNETDA YUKLASH", "ru": "ЗАГРУЗКА ЧЕРЕЗ МОБИЛЬНУЮ СЕТЬ"},
	"lang": {"en": "LANGUAGE", "uz": "TIL", "ru": "ЯЗЫК"},
	"check": {"en": "CHECK FOR UPDATES", "uz": "YANGILANISHNI TEKSHIRISH", "ru": "ПРОВЕРИТЬ ОБНОВЛЕНИЯ"},
	"st_on": {"en": "Server: online", "uz": "Server: ulangan", "ru": "Сервер: на связи"},
	"st_off": {"en": "Server: offline (saved content is used)", "uz": "Server: ulanmagan (saqlangan ma'lumot ishlatiladi)", "ru": "Сервер: нет связи (используется сохранённое)"},
	"st_dl": {"en": "Downloads left: %d", "uz": "Yuklanishi kerak: %d", "ru": "Осталось загрузок: %d"},
	"desc_online": {"en": "Statistics contain no names or personal data: only the game version, device class, performance and progress counters. Big downloads (cars, maps) wait for Wi-Fi unless mobile data is allowed.", "uz": "Statistikada ism yoki shaxsiy ma'lumot yo'q: faqat o'yin versiyasi, qurilma sinfi, tezlik va yutuq hisoblagichlari. Katta yuklamalar (mashina, xarita) mobil internet ruxsat berilmaguncha Wi-Fi'ni kutadi.", "ru": "В статистике нет имён и личных данных: только версия игры, класс устройства, производительность и счётчики прогресса. Большие загрузки (машины, карты) ждут Wi-Fi, если не разрешена мобильная сеть."},
	"tel_t": {"en": "ANONYMOUS STATISTICS", "uz": "ANONIM STATISTIKA", "ru": "АНОНИМНАЯ СТАТИСТИКА"},
	"tel_b": {"en": "To improve quality the game sends anonymous usage statistics (no names, no personal data). You can turn this off any time in Settings > Online.", "uz": "Sifatni yaxshilash uchun o'yin anonim statistika yuboradi (ism va shaxsiy ma'lumotlarsiz). Uni istalgan payt Sozlamalar > Onlayn bo'limida o'chirishingiz mumkin.", "ru": "Для улучшения качества игра отправляет анонимную статистику (без имён и личных данных). Её можно отключить в любое время: Настройки > Онлайн."},
}


static func t(k: String) -> String:
	var d: Dictionary = S.get(k, {})
	return String(d.get(G.lang, d.get("en", k)))
