class_name GameAudio
extends Node
## Sound director of the game world: audio buses + effects (interior / exterior filter, tunnel reverb, hearing-loss muffle, safety limiter), music,
## the player's engine (EngineSound), tyres / wind / suspension, energy based crash / glass / scrape sounds, damage sounds (steam, fire, flat tyre,
## explosion), weather and ambience, positional engines of nearby bots (Doppler) and a voice budget per quality tier.
## All sounds are generated offline: tools/gen_all.py -> assets/audio/v2 + data/audio_bank.json (see SoundBank).

var car: Vehicle
var atmo: Atmosphere
var p := {}
var music: AudioStreamPlayer
var music2: AudioStreamPlayer
var track := ""
var _g1 := 1.0
var _g2 := 0.0
const TRACKS := ["music_drive", "music_chip", "music_euro", "music_electro", "music_night"]
const RACE_TRACKS := ["music_chip", "music_euro", "music_electro", "music_drive"]
const TRACK_NAMES := {"music_drive": "SYNTHWAVE", "music_chip": "8-BIT SPRINT", "music_euro": "EUROBEAT", "music_electro": "ELECTRO", "music_night": "NIGHT DRIVE"}
const CAPS := [14, 20, 28, 40]                 # simultaneously playing engine / loop layers per quality level
const MAX_SHOTS := [10, 14, 20, 28]
const BOT_N := [2, 3, 5, 7]
const BOT_RANGE := [70.0, 100.0, 130.0, 160.0]
const LOOP_BUS := {"skid_asph": "Tyre", "skid_dirt": "Tyre", "roll_asph": "Tyre", "roll_wet": "Tyre", "roll_dirt": "Tyre", "wind": "Tyre", "wind_whistle": "Tyre",
	"buffet": "Tyre", "scrape": "Tyre", "flat": "Tyre", "rattle": "Tyre", "old:rain": "Env", "rain_roof": "Env", "old:ambience_city": "Env",
	"old:ambience_nature": "Env", "amb_birds": "Env", "amb_crickets": "Env", "amb_tunnel": "Env"}
const LOOP_GAIN := {"skid_asph": 0.6, "skid_dirt": 0.55, "roll_asph": 0.55, "roll_wet": 0.45, "roll_dirt": 0.55, "wind": 0.6, "wind_whistle": 0.25,
	"buffet": 0.4, "scrape": 0.8, "flat": 0.6, "rattle": 0.4, "steam": 0.45, "fire": 0.7, "nitro_loop": 0.55, "old:rain": 0.55, "rain_roof": 0.5,
	"old:ambience_city": 0.5, "old:ambience_nature": 0.5, "amb_birds": 0.45, "amb_crickets": 0.4, "amb_tunnel": 0.5, "tinnitus": 0.25}

var _tier := 2
var _t := 0.0
var _prof: Dictionary = {}
var _eng: EngineSound
var _bots := {}
var _hooked := {}
var _bot_t := 0.0
var _loops := {}
var _warm: Array = []                 # sounds still to be loaded in the background (a few per frame) so nothing hitches when first needed
var _shots := 0
var _pend: Array = []
var _mv := -1.0
var _sv := -1.0
var _b_world := -1
var _b_car := -1
var _b_tyre := -1
var _b_music := -1
var _rv: AudioEffectReverb
var _mf: AudioEffectLowPassFilter
var _c_lo: AudioEffectLowShelfFilter
var _c_hi: AudioEffectHighShelfFilter
var _c_lp: AudioEffectLowPassFilter
var _t_lp: AudioEffectLowPassFilter
var _e_lp: AudioEffectLowPassFilter
var _rv_on := false
var _mf_on := false
var _int := 0.0
var _enc := 0.0
var _enc_t := 0.0
var _urban := 0.5
var _urban_t := 0.5
var _probe_t := 0.0
var _road_s := 1.0
var _duck := 0.0
var _muffle := 0.0
var _tin := 0.0
var _crash_t := -9.0
var _horn_t := 0.0
var _bump_cd := 0.0
var _comp_p := [0.0, 0.0, 0.0, 0.0]
var _air_t := 0.0
var _was_boost := false
var _was_exp := false
var _was_fire := false
var _was_hb := false
var _flash_prev := 0.0
var _storm_t := 20.0
var _skid_s := 0.0


static func ensure_buses() -> void:
	if AudioServer.get_bus_index("World") >= 0:
		return
	var defs := [["World", "Master"], ["Car", "World"], ["Tyre", "World"], ["Env", "World"], ["Fx", "World"], ["Music", "Master"], ["Ui", "Master"]]
	for dd in defs:
		AudioServer.add_bus()
		var i := AudioServer.bus_count - 1
		AudioServer.set_bus_name(i, String(dd[0]))
		AudioServer.set_bus_send(i, String(dd[1]))
	var lim := AudioEffectHardLimiter.new()
	lim.ceiling_db = -0.6
	AudioServer.add_bus_effect(0, lim)
	var w := AudioServer.get_bus_index("World")
	var rv := AudioEffectReverb.new()
	rv.room_size = 0.8
	rv.damping = 0.5
	rv.spread = 1.0
	rv.hipass = 0.0
	rv.dry = 1.0
	rv.wet = 0.0
	rv.predelay_msec = 22.0
	AudioServer.add_bus_effect(w, rv)
	var mf := AudioEffectLowPassFilter.new()
	mf.cutoff_hz = 20500.0
	AudioServer.add_bus_effect(w, mf)
	AudioServer.set_bus_effect_enabled(w, 0, false)
	AudioServer.set_bus_effect_enabled(w, 1, false)
	var c := AudioServer.get_bus_index("Car")
	var lo := AudioEffectLowShelfFilter.new()
	lo.cutoff_hz = 180.0
	var hi := AudioEffectHighShelfFilter.new()
	hi.cutoff_hz = 3200.0
	var lpc := AudioEffectLowPassFilter.new()
	lpc.cutoff_hz = 20000.0
	AudioServer.add_bus_effect(c, lo)
	AudioServer.add_bus_effect(c, hi)
	AudioServer.add_bus_effect(c, lpc)
	var lpt := AudioEffectLowPassFilter.new()
	lpt.cutoff_hz = 20000.0
	AudioServer.add_bus_effect(AudioServer.get_bus_index("Tyre"), lpt)
	var lpe := AudioEffectLowPassFilter.new()
	lpe.cutoff_hz = 20000.0
	AudioServer.add_bus_effect(AudioServer.get_bus_index("Env"), lpe)


func _setup_fx() -> void:
	_b_world = AudioServer.get_bus_index("World")
	_b_car = AudioServer.get_bus_index("Car")
	_b_tyre = AudioServer.get_bus_index("Tyre")
	_b_music = AudioServer.get_bus_index("Music")
	_rv = AudioServer.get_bus_effect(_b_world, 0) as AudioEffectReverb
	_mf = AudioServer.get_bus_effect(_b_world, 1) as AudioEffectLowPassFilter
	_c_lo = AudioServer.get_bus_effect(_b_car, 0) as AudioEffectLowShelfFilter
	_c_hi = AudioServer.get_bus_effect(_b_car, 1) as AudioEffectHighShelfFilter
	_c_lp = AudioServer.get_bus_effect(_b_car, 2) as AudioEffectLowPassFilter
	_t_lp = AudioServer.get_bus_effect(_b_tyre, 0) as AudioEffectLowPassFilter
	_e_lp = AudioServer.get_bus_effect(AudioServer.get_bus_index("Env"), 0) as AudioEffectLowPassFilter
	for b in ["World", "Music", "Ui"]:
		AudioServer.set_bus_mute(AudioServer.get_bus_index(b), false)
	AudioServer.set_bus_mute(0, false)


func setup(c: Vehicle, a: Atmosphere) -> void:
	car = c
	atmo = a
	_tier = clampi(Q.level(), 0, 3)
	ensure_buses()
	_setup_fx()
	EngineSound.active = 0
	EngineSound.cap = int(CAPS[_tier])
	_prof = SoundBank.profile(String(car.stats.get("id", "")), CarBuilder.phys_of(car.body_kind))
	if _c_lo != null:
		_c_lo.gain = db_to_linear(float(_prof.get("bass", 0.0)))
		_c_hi.gain = db_to_linear(float(_prof.get("treble", 0.0)))
	_eng = EngineSound.new()
	add_child(_eng)
	_eng.setup(car, _prof, false, false, self, false)
	car.hit_info.connect(_on_hit_player)
	var gw := get_parent()
	if gw != null and "cam" in gw and gw.get("cam") is Camera3D and _tier >= 2:
		(gw.get("cam") as Camera3D).doppler_tracking = Camera3D.DOPPLER_TRACKING_IDLE_STEP
	track = "music_drive" if G.mode == "mission" else "music_night"
	music = _mk_music(track)
	_g1 = 0.0
	_sync_vol()
	_warm = _warm_list()


# ------------------------------------------------------------------ music (older sounds, "Music" bus)
func _mk_music(name: String) -> AudioStreamPlayer:
	var pl := AudioStreamPlayer.new()
	pl.stream = SoundBank.old(name, true)
	pl.volume_db = -60.0
	pl.bus = "Music"
	add_child(pl)
	if pl.stream:
		pl.play()
	return pl


func track_name() -> String:
	return String(TRACK_NAMES.get(track, track))


## Cross-fades to another music track.
func play_track(name: String) -> void:
	if name == track or not TRACKS.has(name):
		return
	if music2:
		music2.queue_free()
	music2 = music
	_g2 = _g1
	track = name
	music = _mk_music(name)
	_g1 = 0.0


func radio_next() -> void:
	play_track(TRACKS[(maxi(TRACKS.find(track), 0) + 1) % TRACKS.size()])


func race_track(key: String) -> void:
	play_track(RACE_TRACKS[absi(key.hash()) % RACE_TRACKS.size()])


func _music_tick(dt: float) -> void:
	var duck := 1.0 - 0.65 * _duck
	_g1 = move_toward(_g1, 1.0, dt / 1.4)
	if music:
		music.volume_db = linear_to_db(maxf(_g1 * duck, 0.0001))
	if music2:
		_g2 = move_toward(_g2, 0.0, dt / 1.4)
		music2.volume_db = linear_to_db(maxf(_g2 * duck, 0.0001))
		if _g2 <= 0.001:
			music2.queue_free()
			music2 = null


func _sync_vol() -> void:
	if is_equal_approx(_mv, G.music_volume) and is_equal_approx(_sv, G.sfx_volume):
		return
	_mv = G.music_volume
	_sv = G.sfx_volume
	if _b_music >= 0:
		AudioServer.set_bus_volume_db(_b_music, linear_to_db(maxf(_mv, 0.001)) - 9.0)
	if _b_world >= 0:
		AudioServer.set_bus_volume_db(_b_world, linear_to_db(maxf(_sv, 0.001)) + linear_to_db(maxf(float(R.cfg("audio.gain", 1.0)), 0.05)))


# ------------------------------------------------------------------ one-shots
## A generated one-shot on the stereo "Fx" bus (budgeted).
func shot(name: String, db: float = 0.0, pitch: float = 1.0, bus_name: String = "Fx") -> void:
	if _shots >= int(MAX_SHOTS[_tier]):
		return
	var s := SoundBank.wav(name)
	if s == null:
		return
	var pl := AudioStreamPlayer.new()
	pl.stream = s
	pl.volume_db = db
	pl.pitch_scale = pitch
	pl.bus = bus_name
	add_child(pl)
	pl.finished.connect(_shot_done.bind(pl))
	pl.play()
	_shots += 1


## A positional one-shot in the world (bots' crashes, far thunder ...).
func shot3d(name: String, pos: Vector3, db: float = 0.0, pitch: float = 1.0) -> void:
	if _shots >= int(MAX_SHOTS[_tier]):
		return
	var s := SoundBank.wav(name)
	if s == null:
		return
	var pl := AudioStreamPlayer3D.new()
	pl.stream = s
	pl.volume_db = db
	pl.pitch_scale = pitch
	pl.bus = "Fx"
	pl.max_distance = 220.0
	pl.unit_size = 16.0
	pl.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
	pl.attenuation_filter_cutoff_hz = 6000.0
	add_child(pl)
	pl.global_position = pos
	pl.finished.connect(_shot_done.bind(pl))
	pl.play()
	_shots += 1


func _shot_done(pl: Node) -> void:
	_shots -= 1
	if is_instance_valid(pl):
		pl.queue_free()


## Older callers: menu / mission jingles and the classic effects (nitro, shift, bump, crash).
func one_shot(name: String, vol_db: float = 0.0, pitch: float = 1.0) -> void:
	var s := SoundBank.old(name)
	if s == null:
		s = SoundBank.wav(name)
	if s == null:
		return
	var pl := AudioStreamPlayer.new()
	pl.stream = s
	pl.volume_db = vol_db
	pl.pitch_scale = pitch
	pl.bus = "Fx"
	add_child(pl)
	pl.finished.connect(pl.queue_free)
	pl.play()


func horn(on: bool) -> void:
	if on and _horn_t <= 0.0:
		_horn_t = 0.6
		shot(String(_prof.get("horn", "horn_a")), -5.0, randf_range(0.99, 1.01))


# ------------------------------------------------------------------ crashes and damage
## Heavy impact: ducks the music, muffles everything and rings in the ears.
func hurt(k: float) -> void:
	_duck = maxf(_duck, 0.4 + 0.6 * k)
	if k > 0.45:
		_muffle = maxf(_muffle, k)
		_tin = maxf(_tin, (k - 0.35) * 1.5)


## Every collision of the player's car (closing speed dv in m/s).
func crash(dv: float) -> void:
	if car == null:
		return
	if car.dmg.exploded and dv >= 29.9:
		return                                        # the blast has its own sound
	if _t - _crash_t < 0.06:
		return
	_crash_t = _t
	var k := clampf(dv, 0.0, 40.0)
	var db := clampf(-13.0 + k * 0.5, -13.0, 1.0)
	if k < 3.5:
		shot(SoundBank.pick("bump", 3), db + 3.0, randf_range(0.9, 1.1))
	elif k < 8.5:
		shot(SoundBank.pick("crash_s", 2), db, randf_range(0.94, 1.06))
	elif k < 15.0:
		shot(SoundBank.pick("crash_m", 2), db, randf_range(0.94, 1.06))
	elif k < 25.0:
		shot(SoundBank.pick("crash_h", 2), db, randf_range(0.95, 1.05))
	else:
		shot("crash_xl", db, randf_range(0.96, 1.04))
	if k > 14.0:
		hurt(clampf((k - 12.0) / 22.0, 0.0, 1.0))


func _on_hit_player(e: float, wp: Vector3, flags: int) -> void:
	_hit_sounds(e, wp, flags, false)


func _on_hit_bot(e: float, wp: Vector3, flags: int) -> void:
	if e > 0.3:
		_hit_sounds(e, wp, flags, true)


func _on_bot_crash(dv: float, v: Vehicle) -> void:
	if dv < 4.0 or not is_instance_valid(v):
		return
	var nm := "crash_s%d" % (1 + randi() % 2) if dv < 10.0 else ("crash_m%d" % (1 + randi() % 2) if dv < 18.0 else "crash_h%d" % (1 + randi() % 2))
	shot3d(nm, v.global_position, clampf(-12.0 + dv * 0.4, -12.0, -2.0), randf_range(0.94, 1.06))


## Details of a damage hit: glass, lamps, bumpers, a wheel that comes off, flying parts.
func _hit_sounds(e: float, wp: Vector3, flags: int, bot: bool) -> void:
	var db := clampf(-12.0 + e * 7.0, -12.0, -3.0)
	if flags & 1:
		_hs(SoundBank.pick("glass", 2), db + 2.0, wp, bot)
	if flags & 2:
		_hs("plastic1", db, wp, bot)
	if flags & 4:
		_hs("wheel_off", db + 4.0, wp, bot)
	if flags & 8:
		_hs(SoundBank.pick("metal_hit", 2), db - 2.0, wp, bot)
	if e > 0.35:
		_hs("debris1", db - 3.0, wp, bot)


func _hs(name: String, db: float, wp: Vector3, bot: bool) -> void:
	if bot:
		shot3d(name, wp, db, randf_range(0.94, 1.06))
	else:
		shot(name, db, randf_range(0.94, 1.06))


# ------------------------------------------------------------------ loops
func _new_loop(n: String) -> EngineSound.Lay:
	var s: AudioStreamWAV = SoundBank.old(n.substr(4), true) if n.begins_with("old:") else SoundBank.wav(n, true)
	if s == null:
		return null
	var L := EngineSound.Lay.new()
	var pl := AudioStreamPlayer.new()
	pl.stream = s
	pl.bus = String(LOOP_BUS.get(n, "Fx"))
	pl.volume_db = -60.0
	add_child(pl)
	L.pl = pl
	L.prio = 2
	L.span = maxf(s.get_length() - 0.05, 0.1)
	return L


func _lp(n: String, v: float, pitch: float = 1.0) -> void:
	if not _loops.has(n):
		if v < 0.005:
			return
		_loops[n] = _new_loop(n)
	var L: EngineSound.Lay = _loops[n]
	if L != null:
		L.put(v * float(LOOP_GAIN.get(n, 0.5)), pitch)


# ------------------------------------------------------------------ frame
## Loads the generated effects a few per frame right after the start (cached in SoundBank); skipped while frames are slow.
func _warm_tick(dt: float) -> void:
	if _warm.is_empty() or _t < 0.4 or dt > 0.04:
		return
	for i in 2:
		if _warm.is_empty():
			return
		var n := String(_warm.pop_front())
		SoundBank.wav(n)
		if LOOP_BUS.has(n) or LOOP_GAIN.has(n):
			SoundBank.wav(n, true)


func _warm_list() -> Array:
	var l: Array = []
	var pr := _prof
	for k in ["turbo", "horn"]:
		var n := String(pr.get(k, ""))
		if n != "":
			l.append(n)
	for n in ["skid_asph", "roll_asph", "wind", "pop1", "pop2", "shift1", "bump1", "bump2", "land1", "crash_s1", "crash_m1", "glass1", "metal_hit1"]:
		l.append(n)
	for n in (SoundBank.meta().get("fx", []) as Array):
		if not l.has(n):
			l.append(n)
	return l


func _process(dt: float) -> void:
	_music_tick(dt)
	_sync_vol()
	_horn_t = maxf(_horn_t - dt, 0.0)
	if car == null or not is_instance_valid(car):
		return
	_t += dt
	_warm_tick(dt)
	_view_tick(dt)
	if _eng != null:
		_eng.update(dt, float(R.cfg("audio.engine_gain", 1.0)))
	_road_tick(dt)
	_event_tick(dt)
	_env_tick(dt)
	_bots_tick(dt)
	_pend_tick(dt)
	_fx_tick(dt)


## Interior / exterior: the cockpit view muffles the engine and the outside world and makes wind / tyres louder.
func _view_tick(dt: float) -> void:
	var gw := get_parent()
	var inside := gw != null and "cam_mode" in gw and int(gw.get("cam_mode")) == 2
	_int = move_toward(_int, 1.0 if inside else 0.0, dt * 4.0)
	if _c_lp != null:
		_c_lp.cutoff_hz = lerpf(20000.0, 3300.0, _int)
		_t_lp.cutoff_hz = lerpf(20000.0, 5200.0, _int)
		_e_lp.cutoff_hz = lerpf(20000.0, 2600.0, _int)
	if _b_car >= 0:
		AudioServer.set_bus_volume_db(_b_car, lerpf(0.0, -3.5, _int) + 2.0 * _enc)
		AudioServer.set_bus_volume_db(_b_tyre, lerpf(0.0, 2.5, _int))


func _road_tick(dt: float) -> void:
	var kmh := car.kmh()
	var spd := clampf(kmh / 220.0, 0.0, 1.0)
	var air := car.airborne
	var pos := car.global_position
	var rm := clampf(W.road_blend(pos.x, pos.z), 0.0, 1.0)
	_road_s = move_toward(_road_s, 1.0 if rm > 0.55 else 0.0, dt * 6.0)
	var wet := clampf(Vehicle.wetness, 0.0, 1.0)
	var gnd := 0.0 if air else 1.0
	var sp8 := pow(spd, 0.85)
	_lp("roll_asph", sp8 * _road_s * gnd * (1.0 - 0.55 * wet), 0.6 + spd * 1.1)
	_lp("roll_wet", wet * pow(spd, 0.7) * _road_s * gnd, 0.7 + spd * 0.8)
	_lp("roll_dirt", pow(spd, 0.7) * (1.0 - _road_s) * gnd, 0.6 + spd * 0.9)
	_lp("wind", spd * spd, 0.75 + spd * 0.6)
	_lp("wind_whistle", smoothstep(0.5, 1.0, spd) * (1.0 - 0.4 * _int), 0.9 + 0.3 * spd)
	_lp("buffet", smoothstep(0.55, 1.0, spd) * (0.3 + 0.7 * _int), 0.9 + 0.3 * spd)
	# tyre squeal / scrub
	var sk := 0.0
	if car.drifting and not air:
		sk = clampf(car.slip * 2.0 + 0.2, 0.0, 1.0)
	if car.in_brake > 0.5 and car.speed > 20.0 and not air:
		sk = maxf(sk, 0.3)
	_skid_s = move_toward(_skid_s, sk, dt * (9.0 if sk > _skid_s else 5.0))
	var sq := smoothstep(0.1, 0.9, _skid_s)
	_lp("skid_asph", sq * _road_s, lerpf(0.85, 1.3, clampf(car.slip, 0.0, 1.0)))
	_lp("skid_dirt", sq * (1.0 - _road_s), lerpf(0.85, 1.2, clampf(car.slip, 0.0, 1.0)))
	# metal on metal / metal on asphalt
	_lp("scrape", car.scrape_amt, (0.65 + kmh / 140.0) * (0.8 if car.scrape_kind == 1 else 1.0))
	var d := car.dmg
	if _tier >= 1:
		var mxt := 0.0
		for i in 4:
			mxt = maxf(mxt, 1.0 if bool(d.detached[i]) else clampf(float(d.tyre[i]) * 1.6, 0.0, 1.0))
		_lp("flat", mxt * smoothstep(1.0, 12.0, absf(car.speed)) * gnd, clampf(absf(car.speed) / 17.0, 0.2, 3.0))
		_lp("steam", smoothstep(0.25, 0.9, d.radiator) * (0.45 + 0.55 * smoothstep(0.4, 0.9, d.temp)), 1.0)
		_lp("fire", 1.0 if d.fire else d.burn * 0.35, 1.0)
		_lp("rattle", smoothstep(0.35, 0.9, car.damage) * clampf(kmh / 50.0, 0.0, 1.0), 1.0)


func _event_tick(dt: float) -> void:
	var d := car.dmg
	if d.exploded and not _was_exp:
		_was_exp = true
		shot("explosion", 0.0, randf_range(0.95, 1.05))
		hurt(1.0)
	elif not d.exploded:
		_was_exp = false
	if d.fire and not _was_fire:
		shot("ignite", -4.0)
	_was_fire = d.fire
	# landing after a jump
	if car.airborne:
		_air_t += dt
	else:
		if _air_t > 0.28:
			shot("land2" if _air_t > 0.8 else "land1", -11.0 + minf(_air_t, 1.6) * 5.0, randf_range(0.92, 1.08))
		_air_t = 0.0
	# nitro
	var boost := car.in_nitro and car.nitro > 0.02 and car.in_gas > 0.1
	if boost and not _was_boost:
		one_shot("nitro", -4.0)
	elif _was_boost and not boost:
		shot("bov_soft", -10.0, 1.3)
	_was_boost = boost
	_lp("nitro_loop", 1.0 if boost else 0.0, 1.0)
	# handbrake ratchet
	if car.in_handbrake and not _was_hb and absf(car.speed) > 2.0:
		shot("hb", -8.0)
	_was_hb = car.in_handbrake
	# suspension thumps from fast compression
	_bump_cd -= dt
	var mx := 0.0
	for i in 4:
		var c: float = car._comp[i]
		mx = maxf(mx, (c - float(_comp_p[i])) / maxf(dt, 0.001))
		_comp_p[i] = c
	if mx > 1.3 and car.speed > 4.0 and not car.airborne and _bump_cd <= 0.0:
		_bump_cd = 0.14
		shot(SoundBank.pick("bump", 3), clampf(-17.0 + mx * 3.0, -17.0, -4.0), randf_range(0.85, 1.15))


## Tunnel / canyon detection with a few rays, day / night / weather ambience, thunder.
func _env_tick(dt: float) -> void:
	_probe_t -= dt
	if _probe_t <= 0.0:
		_probe_t = 0.2
		if _tier >= 2:
			_probe()
	_enc = move_toward(_enc, _enc_t, dt * 1.2)
	_urban = move_toward(_urban, _urban_t, dt * 0.5)
	if _rv != null and _tier >= 2:
		var on := _enc > 0.03
		if on != _rv_on:
			_rv_on = on
			AudioServer.set_bus_effect_enabled(_b_world, 0, on)
		if on:
			_rv.wet = 0.05 + 0.33 * _enc
			_rv.room_size = 0.5 + 0.45 * _enc
	var kmh := car.kmh()
	var spd := clampf(kmh / 220.0, 0.0, 1.0)
	var rain_v: float = atmo.rain if atmo else 0.0
	var day: float = clampf(atmo.elevation * 4.0, 0.0, 1.0) if atmo else 1.0
	var calm := 1.0 - spd * 0.7
	_lp("old:ambience_city", _urban * calm, 1.0)
	_lp("old:ambience_nature", (1.0 - _urban) * calm * (1.0 - 0.6 * rain_v), 1.0)
	if _tier >= 1:
		_lp("amb_birds", day * (1.0 - _urban) * calm * (1.0 - rain_v), 1.0)
		_lp("amb_crickets", (1.0 - day) * (1.0 - _urban) * calm, 1.0)
		_lp("amb_tunnel", smoothstep(0.55, 1.0, _enc) * 0.8, 1.0)
	_lp("old:rain", rain_v * (1.0 - 0.45 * _int), 1.0)
	_lp("rain_roof", rain_v * _int * 0.9, 1.0)
	if atmo != null:
		if atmo.lightning_t > 0.0 and _flash_prev <= 0.0:
			var dl := randf_range(0.4, 4.5)
			_pend.append([dl, "thunder_n" if dl < 1.6 else "thunder_f", -2.0 - dl * 1.2, randf_range(0.92, 1.08)])
		_flash_prev = atmo.lightning_t
		if atmo.weather > 0.6:
			_storm_t -= dt
			if _storm_t <= 0.0:
				_storm_t = randf_range(18.0, 55.0)
				_pend.append([randf_range(0.2, 2.0), "thunder_f", -8.0, randf_range(0.85, 1.0)])


func _probe() -> void:
	var sp := car.get_world_3d().direct_space_state
	var o := car.global_position + Vector3(0.0, 1.3, 0.0)
	var b := car.global_transform.basis
	var dirs := [Vector3.UP * 12.0, b.x * 16.0, -b.x * 16.0, (b.z + b.x * 0.6).normalized() * 28.0, (b.z - b.x * 0.6).normalized() * 28.0]
	var f := []
	for v in dirs:
		var q := PhysicsRayQueryParameters3D.create(o, o + (v as Vector3), 1, [car.get_rid()])
		var h := sp.intersect_ray(q)
		f.append(0.0 if h.is_empty() else 1.0 - o.distance_to(h["position"]) / (v as Vector3).length())
	var ceil_c := clampf(float(f[0]) * 1.4, 0.0, 1.0)
	var side_c := float(f[1]) * float(f[2])
	_enc_t = clampf(ceil_c * (0.35 + 0.65 * sqrt(side_c)) + 0.45 * side_c, 0.0, 1.0)
	_urban_t = clampf((float(f[1]) + float(f[2])) * 0.6 + (float(f[3]) + float(f[4])) * 0.35 + ceil_c * 0.3, 0.0, 1.0) * 0.85 + 0.1


func _pend_tick(dt: float) -> void:
	var i := _pend.size() - 1
	while i >= 0:
		var e: Array = _pend[i]
		e[0] = float(e[0]) - dt
		if float(e[0]) <= 0.0:
			shot(String(e[1]), float(e[2]), float(e[3]), "Env")
			_pend.remove_at(i)
		i -= 1


func _fx_tick(dt: float) -> void:
	_duck = move_toward(_duck, 0.0, dt / 2.2)
	_muffle = move_toward(_muffle, 0.0, dt / 1.7)
	_tin = move_toward(_tin, 0.0, dt / 3.4)
	_lp("tinnitus", _tin, 1.0)
	if _mf != null:
		var on := _muffle > 0.01
		if on != _mf_on:
			_mf_on = on
			AudioServer.set_bus_effect_enabled(_b_world, 1, on)
		if on:
			_mf.cutoff_hz = lerpf(20500.0, 900.0, pow(clampf(_muffle, 0.0, 1.0), 0.7))


# ------------------------------------------------------------------ bots: positional engines
func _bots_tick(dt: float) -> void:
	_bot_t -= dt
	if _bot_t <= 0.0:
		_bot_t = 0.3
		_bots_refresh()
	for id in _bots.keys():
		var e: EngineSound = _bots[id]
		if is_instance_valid(e):
			e.update(dt, 1.0)


func _bots_refresh() -> void:
	var cand: Array = []
	var me := car.global_position
	var rng_m := float(BOT_RANGE[_tier])
	for n in get_tree().get_nodes_in_group("audio_cars"):
		var v := n as Vehicle
		if v == null or v == car or not is_instance_valid(v):
			continue
		var dd := me.distance_to(v.global_position)
		if dd < rng_m:
			cand.append([dd, v])
	cand.sort_custom(func(a, b): return float(a[0]) < float(b[0]))
	var keep := {}
	for i in mini(cand.size(), int(BOT_N[_tier])):
		var v: Vehicle = cand[i][1]
		keep[v.get_instance_id()] = v
	for id in _bots.keys():
		if not keep.has(id):
			var e: EngineSound = _bots[id]
			if is_instance_valid(e):
				e.queue_free()
			_bots.erase(id)
	for id in keep.keys():
		if not _bots.has(id):
			_add_bot(keep[id] as Vehicle)


func _add_bot(v: Vehicle) -> void:
	var pr := SoundBank.profile(String(v.stats.get("id", "")), CarBuilder.phys_of(v.body_kind))
	if pr.is_empty():
		return
	var e := EngineSound.new()
	v.add_child(e)
	e.setup(v, pr, true, true, self, _tier >= 2)
	_bots[v.get_instance_id()] = e
	if not _hooked.has(v.get_instance_id()):
		_hooked[v.get_instance_id()] = true
		v.hit_info.connect(_on_hit_bot)
		v.crashed.connect(_on_bot_crash.bind(v))


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		AudioServer.set_bus_mute(0, true)
	elif what == NOTIFICATION_APPLICATION_FOCUS_IN or what == NOTIFICATION_APPLICATION_RESUMED:
		AudioServer.set_bus_mute(0, false)
