extends Node
## Dev tool: timing of the road segment index + sidewalk build for a cell around the free-mode spawn.
func _ready() -> void:
	G.mode = "free"
	G.quality = 2
	var gw := GameWorld.new()
	gw.autopilot = true
	add_child(gw)
	await get_tree().create_timer(1.0).timeout
	var rb: RoadBuilder = gw.roads
	var c := rb._cell_of(gw.start_pos.x, gw.start_pos.z)
	var id := rb._cell_id(c.x, c.y)
	var t0 := Time.get_ticks_usec()
	var sx = rb._local_index(id)
	print("SEG local index ms=", (Time.get_ticks_usec() - t0) / 1000.0, " cells=", sx.g.size(), " segs=", sx.ri.size())
	var out: Array = []
	var t1 := Time.get_ticks_usec()
	rb._gen_cell(id, out)
	print("SEG cell gen ms=", (Time.get_ticks_usec() - t1) / 1000.0, " road_v=", (out[0] as MeshUtil).vertex_count(), " side_v=", (out[1] as MeshUtil).vertex_count())
	get_tree().quit()
