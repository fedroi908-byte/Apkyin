extends SceneTree
## Launcher for the Node-based perf scripts under --script: user args "<script name> <args...>" -> adds that script as a node.
## The script itself reads OS.get_cmdline_user_args() starting at index 1 is NOT possible, so it gets the args shifted: see _shift().
func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	var s: GDScript = load("res://scripts/%s.gd" % a[0])
	root.add_child(s.new())
