class_name AdCard
extends Control
## Small promo banner for the menu / garage (server controlled through R.ad_pick). Rotates, counts impressions, can be hidden.

var place := "menu"
var _ad: Dictionary = {}
var _show_t := 0.0
var _rot_t := 0.0
var _counted := false
var _bg: Panel
var _img: TextureRect
var _title: Label
var _body: Label
var _cta: Label
var _tag: Label
var _hit: Button
var _x: Button


func _init(p: String = "menu") -> void:
	place = p
	custom_minimum_size = Vector2(640, 150)
	size = Vector2(640, 150)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS
	_bg = Panel.new()
	_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_bg)
	_hit = Button.new()
	_hit.flat = true
	_hit.focus_mode = Control.FOCUS_NONE
	_hit.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_hit.pressed.connect(_open)
	add_child(_hit)
	_img = TextureRect.new()
	_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_img.position = Vector2(12, 12)
	_img.size = Vector2(200, 126)
	_img.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_img)
	_tag = Ui.label(Tx.t("ad"), 14, Color(1, 1, 1, 0.55))
	_tag.position = Vector2(14, 8)
	_tag.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_tag)
	_title = Ui.label("", 28, Color.WHITE, true)
	_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_title.clip_text = true
	add_child(_title)
	_body = Ui.label("", 19, Color(1, 1, 1, 0.8))
	_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_body.max_lines_visible = 2
	_body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_body)
	_cta = Ui.label("", 20, Ui.HOT, true)
	_cta.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_cta)
	_x = Button.new()
	_x.text = "✕"
	_x.flat = true
	_x.focus_mode = Control.FOCUS_NONE
	_x.add_theme_font_size_override("font_size", 22)
	_x.custom_minimum_size = Vector2(56, 56)
	_x.size = Vector2(56, 56)
	_x.position = Vector2(640 - 58, 2)
	_x.pressed.connect(_hide_for_session)
	add_child(_x)
	R.ads_changed.connect(_on_ads_changed)
	R.manifest_applied.connect(_on_ads_changed)
	_pick("")


func _layout() -> void:
	var has_img := _ad.get("tex") != null
	_img.visible = has_img
	var x0 := 226.0 if has_img else 20.0
	var w := size.x - x0 - 60.0
	_title.position = Vector2(x0, 14)
	_title.size = Vector2(w, 36)
	_body.position = Vector2(x0, 52)
	_body.size = Vector2(w, 52)
	_cta.position = Vector2(x0, 108)


func _pick(avoid: String) -> void:
	_ad = R.ad_pick(place, avoid)
	_show_t = 0.0
	_rot_t = 0.0
	_counted = false
	if _ad.is_empty():
		visible = false
		return
	visible = true
	var sb := Ui.box(Color(_ad["bg"]), 16, Color(_ad["accent"]), 2)
	_bg.add_theme_stylebox_override("panel", sb)
	_img.texture = _ad["tex"]
	_title.text = String(_ad["title"])
	_title.add_theme_color_override("font_color", Color(_ad["fg"]))
	_body.text = String(_ad["body"])
	_body.add_theme_color_override("font_color", Color(_ad["fg"], 0.82))
	_cta.text = String(_ad["cta"]) + ("  ▶" if String(_ad["cta"]) != "" else "")
	_cta.add_theme_color_override("font_color", Color(_ad["accent"]))
	_layout()
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.3)


func _on_ads_changed() -> void:
	if R.banners_hidden():
		visible = false
		_ad = {}
	elif _ad.is_empty():
		_pick("")


func _process(dt: float) -> void:
	if _ad.is_empty() or not is_visible_in_tree():
		return
	_show_t += dt
	if not _counted and _show_t >= 1.0:
		_counted = true
		R.ad_shown(_ad, place)
	_rot_t += dt
	if _rot_t >= float(R.ad_cfg("menu_rotate_s", 8)) and _counted:
		_pick(String(_ad.get("id", "")))


func _open() -> void:
	if _ad.is_empty():
		return
	G.ui("ui_click")
	R.ad_click(_ad, place)


func _hide_for_session() -> void:
	G.ui("ui_back")
	if not _ad.is_empty():
		R.ad_close(_ad, place)
	R.hide_banners()


## Full-screen ad: interstitial after a race / splash, or a "watch to get coins" card with a countdown.
class Screen extends CanvasLayer:
	signal finished(rewarded: bool)

	var _ad: Dictionary = {}
	var _place := ""
	var _t := 0.0
	var _skip := 3.0
	var _dur := 5.0
	var _rewarded := false
	var _done := false
	var _count: Label
	var _close: Button
	var _claim: Button

	func show_ad(ad: Dictionary, place: String) -> void:
		_ad = ad
		_place = place
		_rewarded = place == "rewarded"
		_skip = float(clampi(int(ad.get("skip", 3)), 0, 15))
		_dur = float(clampi(int(ad.get("dur", 5)), 0, 30))
		layer = 95
		process_mode = Node.PROCESS_MODE_ALWAYS
		var bg := ColorRect.new()
		bg.color = Color(ad["bg"])
		bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		bg.mouse_filter = Control.MOUSE_FILTER_STOP
		add_child(bg)
		var cc := CenterContainer.new()
		cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		bg.add_child(cc)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 18)
		v.alignment = BoxContainer.ALIGNMENT_CENTER
		cc.add_child(v)
		var tag := Ui.label(Tx.t("ad"), 18, Color(Color(ad["fg"]), 0.6))
		tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(tag)
		if ad.get("tex") != null:
			var im := TextureRect.new()
			im.texture = ad["tex"]
			im.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			im.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			im.custom_minimum_size = Vector2(900, 400)
			v.add_child(im)
		var t := Ui.label(String(ad["title"]), 56, Color(ad["fg"]), true)
		t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		t.custom_minimum_size = Vector2(900, 0)
		v.add_child(t)
		if String(ad["body"]) != "":
			var b := Ui.label(String(ad["body"]), 28, Color(Color(ad["fg"]), 0.85))
			b.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			b.custom_minimum_size = Vector2(900, 0)
			v.add_child(b)
		if String(ad["cta"]) != "" and String(ad["url"]) != "":
			var cta := Ui.button(String(ad["cta"]), _on_cta, Color(ad["accent"]), 30, Vector2(520, 76))
			cta.alignment = HORIZONTAL_ALIGNMENT_CENTER
			var row := HBoxContainer.new()
			row.alignment = BoxContainer.ALIGNMENT_CENTER
			row.add_child(cta)
			v.add_child(row)
		_claim = Ui.button(Tx.t("claim") % int(ad.get("reward", 0)), _on_claim, Ui.GOLD, 30, Vector2(520, 76))
		_claim.alignment = HORIZONTAL_ALIGNMENT_CENTER
		_claim.visible = false
		var crow := HBoxContainer.new()
		crow.alignment = BoxContainer.ALIGNMENT_CENTER
		crow.add_child(_claim)
		v.add_child(crow)
		_count = Ui.label("", 22, Color(Color(ad["fg"]), 0.8), true)
		_count.set_anchors_preset(Control.PRESET_TOP_RIGHT)
		bg.add_child(_count)
		_count.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 28)
		_close = Ui.button(Tx.t("close"), func(): _finish(false), Color(0.9, 0.9, 0.9), 22, Vector2(220, 56))
		_close.alignment = HORIZONTAL_ALIGNMENT_CENTER
		_close.visible = false
		bg.add_child(_close)
		_close.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 24)
		R.ad_shown(ad, place)
		bg.modulate.a = 0.0
		bg.create_tween().tween_property(bg, "modulate:a", 1.0, 0.25)
		_process(0.0)

	func _process(dt: float) -> void:
		if _done:
			return
		_t += dt
		var left_skip := ceilf(_skip - _t)
		var left_rew := ceilf(_dur - _t)
		if _rewarded:
			if left_rew > 0.0:
				_count.text = Tx.t("reward_in") % int(left_rew)
			else:
				_count.text = ""
				_claim.visible = true
			_close.visible = left_skip <= 0.0 and left_rew > 0.0
		else:
			if left_skip > 0.0:
				_count.text = Tx.t("skip_in") % int(left_skip)
			else:
				_count.text = ""
			_close.visible = left_skip <= 0.0

	func _on_cta() -> void:
		R.ad_click(_ad, _place)
		if String(_ad.get("url", "")).begins_with("lemov://"):
			_finish(false)

	func _on_claim() -> void:
		if _done:
			return
		R.ad_reward_done(_ad)
		G.ui("win", -6.0)
		_finish(true)

	func _finish(rewarded: bool) -> void:
		if _done:
			return
		_done = true
		R.ad_close(_ad, _place)
		finished.emit(rewarded)
		queue_free()
