class_name MissionRunner
extends Node
## Runs one mission inside the open world: placement, cinematic intro, countdown (perfect start), checkpoints/score, timer, HUD, result.
## Road races run against AI opponents (RaceDirector): standings tower, laps, takedowns, slipstream, drift -> nitro.

signal finished(result: Dictionary)

const INTRO_T := 3.4

var gw: GameWorld
var m: Dictionary
var state := "countdown"            # intro, countdown, running, done
var t := 0.0                        # running time
var cd := 3.0
var cps: Array = []                 # Vector3 checkpoints
var cp_i := 0
var score := 0.0
var combo := 1.0
var combo_t := 0.0
var top_kmh := 0.0
var layer: CanvasLayer
var title_l: Label
var info_l: Label
var time_l: Label
var big_l: Label
var arrow: Control
var arrow_ang := 0.0
var dist_to := 0.0
var markers: Array = []
var director: RaceDirector
var tower: VBoxContainer
var banner_l: Label
var sub_l: Label
var drift_l: Label
var intro_l: Label
var bars: Array = []
var drift_pts := 0.0                # drift points collected in a race (they charge the nitro and add a small bonus)
var _rows: Array = []
var _last_cd := 4
var _intro_t := 0.0
var _gas_press_cd := -1.0
var _tower_t := 0.0
var _drift_combo := 1.0
var _drift_hold := 0.0
var _drift_show := 0.0
var _bonus := 0
var _banner_tw: Tween


func setup(world: GameWorld, mission: Dictionary) -> void:
	gw = world
	m = mission
	_place()
	_build_ui()
	_build_markers()
	gw.input_locked = true
	if director != null:
		_start_intro()
	else:
		state = "countdown"
		cd = 3.0


func _place() -> void:
	var pos := gw.start_pos
	var yaw := gw.start_yaw
	if m["type"] == "race":
		var pts: Array = m["pts"]
		var one := _resample(pts, 130.0)
		var laps := maxi(int(m.get("laps", 1)), 1) if bool(m.get("loop", false)) else 1
		cps = []
		for _l in laps:
			cps.append_array(one)
		pos = Vector3(pts[0][0], 0.0, pts[0][1])
		yaw = atan2(one[1].x - pos.x, one[1].z - pos.z) if one.size() > 1 else 0.0
		if RaceDirector.bot_count() > 0:
			director = RaceDirector.new()
			add_child(director)
			director.setup(gw, m)
			director.event.connect(_on_event)
			var s := director.slot_transform(director.player_slot_index())
			pos = s["pos"]
			yaw = s["yaw"]
	elif m["type"] == "speed" and m["start"] == "coast":
		var r: Dictionary = W.races[0]
		var pts2: Array = r["pts"]
		pos = Vector3(pts2[0][0], 0.0, pts2[0][1])
		yaw = atan2(pts2[4][0] - pts2[0][0], pts2[4][1] - pts2[0][1])
	elif m["type"] == "courier":
		cps = _courier_points(int(m["count"]), gw.start_pos)
	pos.y = W.ground_height(pos.x, pos.z, pos.y + 4.0) + 0.4
	gw.player.reset_to(pos, yaw)
	gw.cam_yaw = yaw
	gw.cam_pos = pos
	gw.hud.visible = true


func _resample(pts: Array, step: float) -> Array:
	var out: Array = []
	var acc := 0.0
	var prev := Vector3(pts[0][0], 0, pts[0][1])
	for i in range(1, pts.size()):
		var p := Vector3(pts[i][0], 0, pts[i][1])
		acc += prev.distance_to(p)
		prev = p
		if acc >= step:
			acc = 0.0
			out.append(p)
	var last := Vector3(pts[pts.size() - 1][0], 0, pts[pts.size() - 1][1])
	if out.is_empty() or (out[out.size() - 1] as Vector3).distance_to(last) > 30.0:
		out.append(last)
	else:
		out[out.size() - 1] = last
	for i in out.size():
		var q: Vector3 = out[i]
		q.y = W.ground_height(q.x, q.z, 60.0)
		out[i] = q
	return out


func _courier_points(n: int, around: Vector3) -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var out: Array = []
	var cur := around
	var cnt := W.intersections.size() / 4
	var tries := 0
	while out.size() < n and tries < 4000 and cnt > 0:
		tries += 1
		var k := rng.randi() % cnt
		var p := Vector3(W.intersections[k * 4], 0, W.intersections[k * 4 + 1])
		var d := cur.distance_to(p)
		if d > 260.0 and d < 700.0:
			p.y = W.ground_height(p.x, p.z, 60.0)
			out.append(p)
			cur = p
	return out


# ---- UI ------------------------------------------------------------------------------------------------------------------

func _build_ui() -> void:
	layer = CanvasLayer.new()
	layer.layer = 12
	add_child(layer)
	var ins := Ui.safe_insets(get_viewport())
	var pn := Ui.panel(Color(0.03, 0.05, 0.09, 0.78), 14)
	pn.position = Vector2(18 + ins.x, 90 + ins.y)
	layer.add_child(pn)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	pn.add_child(v)
	title_l = Ui.label(String(m["name"]), 26, Missions.TYPE_COLORS[m["type"]], true)
	v.add_child(title_l)
	info_l = Ui.label("", 20, Color.WHITE)
	v.add_child(info_l)
	time_l = Ui.label("0:00.0", 38, Color.WHITE, true)
	v.add_child(time_l)
	big_l = Ui.label("", 160, Color.WHITE, true)
	big_l.set_anchors_preset(Control.PRESET_CENTER)
	big_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_l.size = Vector2(600, 200)
	big_l.position = Vector2(-300, -260)
	big_l.add_theme_constant_override("outline_size", 14)
	layer.add_child(big_l)
	big_l.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	big_l.position.y -= 150
	arrow = Control.new()
	arrow.set_anchors_preset(Control.PRESET_CENTER_TOP)
	arrow.position = Vector2(0, 150)
	arrow.draw.connect(_draw_arrow)
	arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(arrow)
	banner_l = _center_label(46, 118)
	sub_l = _center_label(26, 178)
	drift_l = _center_label(34, 214)
	if director != null:
		_build_tower(ins)
		_build_bars()


func _center_label(size: int, y: float) -> Label:
	var l := Ui.label("", size, Color.WHITE, true)
	l.add_theme_constant_override("outline_size", 8)
	l.set_anchors_preset(Control.PRESET_CENTER_TOP)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.custom_minimum_size = Vector2(700, 0)
	l.anchor_left = 0.5
	l.anchor_right = 0.5
	l.offset_left = -350
	l.offset_right = 350
	l.offset_top = y
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.modulate.a = 0.0
	layer.add_child(l)
	return l


func _build_tower(ins: Vector4) -> void:
	tower = VBoxContainer.new()
	tower.add_theme_constant_override("separation", 1)
	tower.anchor_left = 1.0
	tower.anchor_right = 1.0
	tower.offset_left = -262 - ins.z
	tower.offset_right = -14 - ins.z
	tower.offset_top = 96 + ins.y
	tower.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(tower)
	for i in mini(director.racers.size(), 9):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		var bg := Ui.box(Color(0.03, 0.05, 0.09, 0.62), 5)
		bg.content_margin_top = 2
		bg.content_margin_bottom = 2
		bg.content_margin_left = 8
		bg.content_margin_right = 8
		var pc := PanelContainer.new()
		pc.add_theme_stylebox_override("panel", bg)
		pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var inner := HBoxContainer.new()
		inner.add_theme_constant_override("separation", 8)
		var a := Ui.label("%d" % (i + 1), 19, Ui.DIM, true)
		a.custom_minimum_size = Vector2(22, 0)
		var b := Ui.label("", 19, Color.WHITE, true)
		b.custom_minimum_size = Vector2(118, 0)
		var c := Ui.label("", 17, Ui.DIM, true)
		c.custom_minimum_size = Vector2(70, 0)
		c.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		inner.add_child(a)
		inner.add_child(b)
		inner.add_child(c)
		pc.add_child(inner)
		tower.add_child(pc)
		_rows.append(pc)


func _build_bars() -> void:
	for i in 2:
		var bar := ColorRect.new()
		bar.color = Color(0, 0, 0, 1)
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bar.anchor_left = 0.0
		bar.anchor_right = 1.0
		if i == 0:
			bar.anchor_top = 0.0
			bar.anchor_bottom = 0.0
			bar.offset_bottom = 0.0
		else:
			bar.anchor_top = 1.0
			bar.anchor_bottom = 1.0
			bar.offset_top = 0.0
		layer.add_child(bar)
		bars.append(bar)
	intro_l = Ui.label("", 30, Color.WHITE, true)
	intro_l.add_theme_constant_override("outline_size", 8)
	intro_l.position = Vector2(60, 0)
	intro_l.anchor_top = 0.74
	intro_l.anchor_bottom = 0.74
	intro_l.modulate.a = 0.0
	layer.add_child(intro_l)


func _build_markers() -> void:
	for i in 2:
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 11.0
		cm.bottom_radius = 11.0
		cm.height = 90.0
		cm.radial_segments = 24
		cm.rings = 1
		mi.mesh = cm
		var mat := StandardMaterial3D.new()
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		mat.albedo_color = Color(0.1, 0.8, 1.0, 0.28) if i == 0 else Color(1.0, 0.7, 0.2, 0.12)
		mi.material_override = mat
		mi.visible = false
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		gw.add_child(mi)
		markers.append(mi)


func _exit_tree() -> void:
	for mk in markers:
		if is_instance_valid(mk):
			mk.queue_free()


func _banner(text: String, col: Color, secs: float = 1.6, which: int = 0) -> void:
	var l: Label = [banner_l, sub_l, drift_l][which]
	l.text = text
	l.add_theme_color_override("font_color", col)
	l.pivot_offset = l.size * 0.5
	l.scale = Vector2.ONE * 1.35
	l.modulate.a = 1.0
	if which == 0 and _banner_tw:
		_banner_tw.kill()
	var tw := create_tween()
	tw.tween_property(l, "scale", Vector2.ONE, 0.18)
	tw.tween_interval(secs)
	tw.tween_property(l, "modulate:a", 0.0, 0.5)
	if which == 0:
		_banner_tw = tw


func _on_event(kind: String, text: String) -> void:
	match kind:
		"takedown":
			_bonus += 60
			G.ui("takedown", -2.0)
			_banner("TAKEDOWN  %s" % text, Color(1.0, 0.48, 0.10), 1.8)
		"lap":
			G.ui("lap", -4.0)
			_banner("%s %s" % [Tx.t("lap"), text], Ui.ACCENT, 1.4, 1)
		"pos_up":
			G.ui("pos_up", -7.0)
			_banner(text, Ui.GOOD, 1.0, 1)
		"pos_down":
			G.ui("pos_down", -7.0)
			_banner(text, Color(1.0, 0.35, 0.3), 1.0, 1)
		"wrong_way":
			_banner(Tx.t("wrong_way"), Color(1.0, 0.25, 0.2), 2.0)


# ---- cinematic intro ------------------------------------------------------------------------------------------------------

func _start_intro() -> void:
	state = "intro"
	_intro_t = 0.0
	gw.cine = true
	gw.audio.race_track(String(m["id"]))
	var n := director.racers.size()
	intro_l.text = "%s\n%s %d   %s %d   %s %d/%d" % [String(m["name"]), Tx.t("laps"), director.laps, Tx.t("rivals"), n - 1, Tx.t("grid"), director.player_slot_index() + 1, n]
	var tw := create_tween().set_parallel(true)
	var vh := get_viewport().get_visible_rect().size.y
	tw.tween_property(bars[0], "offset_bottom", vh * 0.09, 0.5)
	tw.tween_property(bars[1], "offset_top", -vh * 0.09, 0.5)
	tw.tween_property(intro_l, "modulate:a", 1.0, 0.7).set_delay(0.5)
	title_l.get_parent().get_parent().visible = false
	tower.visible = false


func _intro(dt: float) -> void:
	_intro_t += dt
	var u := clampf(_intro_t / INTRO_T, 0.0, 1.0)
	var s := u * u * (3.0 - 2.0 * u)
	var pl := gw.player
	var f := pl.flat_forward()
	var r := Vector3(-f.z, 0.0, f.x)
	var g0 := pl.global_position
	var a := g0 + f * 50.0 + r * 18.0 + Vector3(0, 27.0, 0)
	var b := g0 + f * 10.0 - r * 8.5 + Vector3(0, 3.2, 0)
	var c := g0 - f * 6.2 + Vector3(0, 2.1, 0)
	var p := a * (1.0 - s) * (1.0 - s) + b * 2.0 * (1.0 - s) * s + c * s * s
	p.y = maxf(p.y, W.terrain_height(p.x, p.z) + 0.9)
	var look := (g0 - f * 3.0 + Vector3(0, 0.7, 0)).lerp(g0 + f * 4.0 + Vector3(0, 1.1, 0), s)
	gw.cam.global_position = p
	gw.cam.look_at(look, Vector3.UP)
	gw.cam.fov = lerpf(52.0, 70.0, s)
	gw.cam_pos = p
	gw.fov_cur = gw.cam.fov
	if _intro_t >= INTRO_T:
		_end_intro()


func _end_intro() -> void:
	if state != "intro":
		return
	state = "countdown"
	cd = 3.0
	gw.cine = false
	gw.cam_yaw = gw.player.yaw
	var tw := create_tween().set_parallel(true)
	tw.tween_property(bars[0], "offset_bottom", 0.0, 0.4)
	tw.tween_property(bars[1], "offset_top", 0.0, 0.4)
	tw.tween_property(intro_l, "modulate:a", 0.0, 0.3)
	title_l.get_parent().get_parent().visible = true
	tower.visible = true
	_tower_update()


func _input(e: InputEvent) -> void:
	if state != "intro":
		return
	if (e is InputEventScreenTouch and e.pressed) or (e is InputEventMouseButton and e.pressed) or (e is InputEventKey and e.pressed):
		_end_intro()


# ---- per frame -----------------------------------------------------------------------------------------------------------------

func _target() -> Vector3:
	if m["type"] in ["race", "courier"] and cp_i < cps.size():
		return cps[cp_i]
	return Vector3.ZERO


func _gas_pressed() -> bool:
	return Input.is_action_pressed("accelerate") or bool(gw.touch["gas"])


func _process(dt: float) -> void:
	if state == "done":
		return
	var p := gw.player
	var kmh := p.kmh()
	top_kmh = maxf(top_kmh, kmh)
	if state == "intro":
		_intro(dt)
		return
	if state == "countdown":
		cd -= dt
		var gas := _gas_pressed()
		if gas and _gas_press_cd < 0.0:
			_gas_press_cd = cd
		elif not gas:
			_gas_press_cd = -1.0
		var n := int(ceil(cd))
		if n != _last_cd:
			_last_cd = n
			if n > 0:
				big_l.text = str(n)
				G.ui("countdown", -4.0)
			else:
				big_l.text = "GO!"
				G.ui("go", -2.0)
		big_l.pivot_offset = big_l.size * 0.5
		big_l.scale = Vector2.ONE * (1.0 + fmod(cd, 1.0) * 0.4)
		if cd <= 0.0:
			state = "running"
			gw.input_locked = false
			if director:
				director.go = true
				_start_check()
			var tw := create_tween()
			tw.tween_property(big_l, "modulate:a", 0.0, 0.8)
		_update_markers()
		if director:
			_tower_tick(dt)
		return
	t += dt
	var limit: float = m["limit"]
	match String(m["type"]):
		"race":
			_run_cp(dt, true)
		"courier":
			_run_cp(dt, true)
		"speed":
			info_l.text = "TARGET %d km/h   NOW %d" % [int(m["target"]), int(kmh)]
			if kmh >= float(m["target"]):
				_finish(true, t)
		"drift":
			_drift_mission(dt)
	if director != null:
		_race_hud(dt)
	_drift_fx(dt)
	time_l.text = _fmt(maxf(limit - t, 0.0)) if m["type"] != "race" else _fmt(t)
	time_l.add_theme_color_override("font_color", Color(1, 0.3, 0.25) if (limit - t < 10.0 and m["type"] != "race") else Color.WHITE)
	if t >= limit:
		_finish(false, score if m["type"] == "drift" else t)
	_update_markers()


## Launch quality: pressing the pedal in the last 0.6 s before GO gives a free nitro burst, holding it much earlier spins the wheels.
func _start_check() -> void:
	var p := gw.player
	var held := _gas_press_cd if _gas_pressed() else -1.0
	if held >= 0.0 and held <= 0.6:
		p.nitro_gain(0.5)
		gw.force_nitro_t = 1.6
		_bonus += 50
		G.ui("perfect", -3.0)
		_banner("PERFECT START!", Ui.GOLD, 1.8)
	elif held > 1.1:
		gw.gas_scale_t = 1.0
		_banner("WHEELSPIN", Color(1.0, 0.35, 0.3), 1.4)


func _drift_mission(dt: float) -> void:
	var p := gw.player
	if p.drifting and absf(p.speed) > 8.0:
		combo_t = 2.0
		combo = minf(combo + dt * 0.5, 8.0)
		score += dt * absf(p.speed) * 2.2 * combo
	else:
		combo_t -= dt
		if combo_t <= 0.0:
			combo = 1.0
	info_l.text = "SCORE %d / %d   COMBO x%.1f" % [int(score), int(m["target"]), combo]
	if score >= float(m["target"]):
		_finish(true, score)


## Drifting in any race / mission charges the nitro and shows a combo counter.
func _drift_fx(dt: float) -> void:
	var p := gw.player
	if m["type"] == "drift":
		return
	if p.drifting and absf(p.speed) > 12.0 and not p.airborne:
		_drift_hold = 1.0
		_drift_combo = minf(_drift_combo + dt * 0.5, 6.0)
		drift_pts += dt * absf(p.speed) * 2.2 * _drift_combo
		p.nitro_gain(dt * 0.10)
		_drift_show = drift_pts
		drift_l.text = "DRIFT  %d   x%.1f" % [int(_drift_show), _drift_combo]
		drift_l.add_theme_color_override("font_color", Color(0.85, 0.45, 1.0))
		drift_l.modulate.a = 1.0
	elif _drift_hold > 0.0:
		_drift_hold -= dt
		if _drift_hold <= 0.0:
			_drift_combo = 1.0
			var tw := create_tween()
			tw.tween_property(drift_l, "modulate:a", 0.0, 0.6)


func _race_hud(dt: float) -> void:
	_tower_tick(dt)
	var pos := director.player_position()
	var n := director.racers.size()
	var lp := director.lap_of(director._you)
	info_l.text = "P%d/%d   %s %d/%d" % [pos, n, Tx.t("lap"), lp, director.laps]
	var dr: float = director._you["draft"]
	if dr > 0.3:
		sub_l.text = "SLIPSTREAM"
		sub_l.add_theme_color_override("font_color", Color(0.4, 0.9, 1.0))
		sub_l.modulate.a = clampf(dr * 1.4, 0.0, 1.0)


func _tower_tick(dt: float) -> void:
	_tower_t -= dt
	if _tower_t <= 0.0:
		_tower_t = 0.25
		_tower_update()


func _tower_update() -> void:
	if tower == null:
		return
	var st := director.standings()
	var lead: float = float(st[0]["prog"]) if st.size() > 0 else 0.0
	for i in _rows.size():
		var row: PanelContainer = _rows[i]
		if i >= st.size():
			row.visible = false
			continue
		row.visible = true
		var r: Dictionary = st[i]
		var inner := row.get_child(0) as HBoxContainer
		(inner.get_child(0) as Label).text = "%d" % (i + 1)
		var nm := inner.get_child(1) as Label
		nm.text = String(r["name"])
		var gp := inner.get_child(2) as Label
		var col := Color(1, 1, 1)
		if bool(r["you"]):
			col = Ui.GOLD
		elif bool(r["fin"]):
			col = Ui.GOOD
		nm.add_theme_color_override("font_color", col)
		if bool(r["fin"]):
			gp.text = "FIN"
			gp.add_theme_color_override("font_color", Ui.GOOD)
		elif i == 0:
			gp.text = "%s %d/%d" % [Tx.t("lap"), director.lap_of(r), director.laps]
			gp.add_theme_color_override("font_color", Ui.DIM)
		else:
			var d := maxf(lead - float(r["prog"]), 0.0)
			gp.text = "+%.1fs" % (d / maxf(float(r["spd"]), 25.0))
			gp.add_theme_color_override("font_color", Ui.DIM if not bool(r["you"]) else Ui.GOLD)


func _run_cp(_dt: float, _timed: bool) -> void:
	if cp_i >= cps.size():
		return
	var p := gw.player.global_position
	var tgt: Vector3 = cps[cp_i]
	dist_to = Vector2(p.x - tgt.x, p.z - tgt.z).length()
	if director == null:
		info_l.text = "CHECKPOINT %d / %d   %d m" % [cp_i + 1, cps.size(), int(dist_to)]
	if dist_to < 20.0:
		cp_i += 1
		G.ui("checkpoint", -3.0)
		if cp_i >= cps.size():
			_finish(true, t)


func _update_markers() -> void:
	if not (m["type"] in ["race", "courier"]):
		for mk in markers:
			(mk as Node3D).visible = false
		arrow.visible = false
		return
	for k in 2:
		var idx := cp_i + k
		var mk: MeshInstance3D = markers[k]
		if idx < cps.size() and state != "done":
			var q: Vector3 = cps[idx]
			mk.global_position = q + Vector3(0, 40.0, 0)
			mk.visible = true
		else:
			mk.visible = false
	if cp_i < cps.size():
		var cam := gw.cam
		var d := (cps[cp_i] as Vector3) - cam.global_position
		var l := cam.global_transform.basis.inverse() * d
		arrow_ang = atan2(l.x, -l.z)
		arrow.visible = true
		arrow.queue_redraw()
	else:
		arrow.visible = false


func _draw_arrow() -> void:
	var a := arrow_ang
	var c := Vector2.ZERO
	var pts := PackedVector2Array([
		c + Vector2(sin(a), -cos(a)) * 40.0,
		c + Vector2(sin(a + 2.5), -cos(a + 2.5)) * 30.0,
		c + Vector2(sin(a + PI), -cos(a + PI)) * 12.0,
		c + Vector2(sin(a - 2.5), -cos(a - 2.5)) * 30.0,
	])
	arrow.draw_colored_polygon(pts, Color(0.1, 0.85, 1.0, 0.92))
	arrow.draw_polyline(pts + PackedVector2Array([pts[0]]), Color(1, 1, 1, 0.9), 2.5)


func _fmt(x: float) -> String:
	return "%d:%04.1f" % [int(x / 60.0), fmod(x, 60.0)]


func _finish(success: bool, value: float) -> void:
	if state == "done":
		return
	state = "done"
	gw.input_locked = true
	for mk in markers:
		(mk as Node3D).visible = false
	arrow.visible = false
	var pos := 0
	var n := 0
	var rows: Array = []
	var stars := 0
	if director != null:
		n = director.racers.size()
		pos = director.player_finish() if success else director.player_position()
		rows = director.classification()
		var win_pos := maxi(2, (n + 1) / 2)
		success = success and pos <= win_pos
		stars = (3 if pos == 1 else (2 if pos == 2 else 1)) if success else 0
	else:
		stars = Missions.stars_for(m, value, success)
	var reward := int(roundf(float(Missions.reward_for(m, stars)) * float(R.cfg("econ.reward_mult", 1.0))))
	var bonus := 0
	if success and m["type"] != "drift":
		bonus = _bonus + mini(int(drift_pts * 0.02), 300)
	reward += bonus
	var res := {"success": success, "value": value, "stars": stars, "reward": reward, "mission": m, "top": top_kmh,
		"pos": pos, "n": n, "rows": rows, "bonus": bonus, "takedowns": director.takedowns if director else 0, "drift_pts": int(drift_pts)}
	G.ui("jingle_podium" if success else "jingle_lose", -3.0)
	if success:
		var prev: int = int(G.mission_stars.get(m["id"], 0))
		if stars > prev:
			G.mission_stars[m["id"]] = stars
		var best: float = float(G.mission_best.get(m["id"], 0.0))
		var better := value > best if m["type"] == "drift" else (best <= 0.0 or value < best)
		if better:
			G.mission_best[m["id"]] = value
		G.credits += reward
		if m["type"] == "race" and pos <= 1:
			G.races_won += 1
	G.races_total += 1
	G.add_xp((20 + stars * 40) if success else 10)
	R.note_race_finished()
	R.track("race_end", {"mission": String(m["id"]), "type": String(m["type"]), "ok": success, "stars": stars, "t": snappedf(value, 0.01), "coins": reward if success else 0, "car": String(G.car()["id"]), "pos": pos, "n": n})
	G.save_game()
	finished.emit(res)
