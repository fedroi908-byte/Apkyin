extends Node
## Splits the per-frame cost by direct child of GameWorld (hide one child at a time). user args: <quality> <car idx>
var gw: GameWorld
var f := 0
var kids: Array = []
var step := -1
var base := {}
func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	G.quality = int(a[0]) if a.size() > 0 else 0
	G.selected_car = int(a[1]) if a.size() > 1 else 0
	G.start_hour = 11.0
	Q.apply(get_viewport())
	gw = GameWorld.new()
	add_child(gw)
func _info() -> Dictionary:
	return {"dc": int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)), "prim": int(Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)), "obj": int(Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME))}
func _nm(k: Node) -> String:
	for v in ["atmo", "terrain", "water", "roads", "blds", "player", "cam", "hud", "audio", "runner"]:
		if gw.get(v) == k:
			return v
	return str(k.name)
func _count(n: Node) -> int:
	var c := 1
	for k in n.get_children():
		c += _count(k)
	return c
func _process(_d: float) -> void:
	f += 1
	if f == 4:
		base = _info()
		print("SPLIT base ", base, " nodes ", _count(gw))
		for k in gw.get_children():
			if k is Node3D or k is CanvasLayer:
				kids.append(k)
				print("SPLIT child ", _nm(k), " ", k.get_class(), " nodes=", _count(k))
		step = 0
	if f > 4 and (f % 3) == 1 and step >= 0:
		# measure the frame rendered with kids[step-1] hidden
		if step > 0:
			var k: Node = kids[step - 1]
			var i := _info()
			print("SPLIT hide ", _nm(k), " -> dc ", base["dc"] - i["dc"], " prim ", (base["prim"] - i["prim"]) / 1000, "k obj ", base["obj"] - i["obj"])
			k.visible = true
		if step >= kids.size():
			get_tree().quit()
			return
		kids[step].visible = false
		step += 1
