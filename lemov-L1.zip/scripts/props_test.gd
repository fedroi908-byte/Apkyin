extends Node

var gw: GameWorld
var p: Vehicle
var t := 0.0
var mode := "scan"
var kmh := 50.0
var tp := 0
var tgt := Vector3.ZERO
var tyaw := 0.0
var go := false
var hd := Vector3.ZERO
var vmin := 1000.0
var v_pre := 0.0
var passed := false
var t_pass := 0.0


func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	mode = a[0] if a.size() > 0 else "scan"
	kmh = float(a[1]) if a.size() > 1 else 50.0
	G.start_hour = 11.0
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)
	await get_tree().process_frame
	await get_tree().process_frame
	p = gw.player
	var pr := gw.props
	var t0 := Time.get_ticks_usec()
	pr.build_all_near(p.global_position, 1)
	print("PT built cells=", pr.cells.size(), " ms=", (Time.get_ticks_usec() - t0) / 1000)
	if mode == "scan":
		scan(pr)
		get_tree().quit()
		return
	var types := {"lamp": 0, "signal": 1, "bin": 2, "hydrant": 3, "bollard": 4, "sign": 5, "bench": 6, "mailbox": 7, "dumpster": 8, "cone": 9}
	tp = types.get(mode, 0)
	var best := 1e9
	for cid in pr.cells:
		var b: PropGen.Built = pr.cells[cid].b
		for i in b.recs.size() >> 3:
			var o := i * 8
			if int(b.recs[o]) != tp or b.alive[i] == 0:
				continue
			var q := Vector3(b.recs[o + 1], b.recs[o + 2], b.recs[o + 3])
			var d := q.distance_to(p.global_position)
			if d < best:
				best = d
				tgt = q
				tyaw = b.recs[o + 4]
	if best > 1e8:
		print("PT no prop of type ", mode)
		get_tree().quit()
		return
	var toward := Vector3(sin(tyaw), 0.0, cos(tyaw))
	var st := tgt + toward * (float(a[2]) if a.size() > 2 else 14.0)
	hd = -toward
	p.reset_to(Vector3(st.x, W.ground_height(st.x, st.z) + 0.3, st.z), tyaw + PI)
	p.linear_velocity = hd * kmh / 3.6
	print("PT target ", mode, " at ", tgt, " yaw ", snapped(tyaw, 0.01), " start ", st)
	go = true


func scan(pr: StreetProps) -> void:
	var cnt := {}
	var bad := 0
	var dmax := -9.0
	var dmin := 9.0
	var tot := 0
	for cid in pr.cells:
		var b: PropGen.Built = pr.cells[cid].b
		for i in b.recs.size() >> 3:
			var o := i * 8
			var ty := int(b.recs[o])
			cnt[ty] = int(cnt.get(ty, 0)) + 1
			var d := b.recs[o + 2] - W.ground_height(b.recs[o + 1], b.recs[o + 3], b.recs[o + 2] + 1.0)
			dmax = maxf(dmax, d)
			dmin = minf(dmin, d)
			if d > 0.5 or d < -0.35:
				bad += 1
			tot += 1
	var hist := [0, 0, 0, 0, 0]
	var worst := []
	for cid in pr.cells:
		var b2: PropGen.Built = pr.cells[cid].b
		for i in b2.recs.size() >> 3:
			var o := i * 8
			var d := b2.recs[o + 2] - W.ground_height(b2.recs[o + 1], b2.recs[o + 3], b2.recs[o + 2] + 1.0)
			hist[0 if d < -0.35 else (1 if d < 0.0 else (2 if d < 0.3 else (3 if d < 0.5 else 4)))] += 1
			if absf(d) > 1.0:
				worst.append([snapped(d, 0.01), int(b2.recs[o]), Vector2(snapped(b2.recs[o + 1], 1.0), snapped(b2.recs[o + 3], 1.0))])
	worst.sort_custom(func(x, y): return absf(x[0]) > absf(y[0]))
	print("PT hist ", hist, " worst ", worst.slice(0, 6))
	print("PT scan total=", tot, " types=", cnt, " dy_min=", snapped(dmin, 0.01), " dy_max=", snapped(dmax, 0.01), " off=", bad)


func _physics_process(dt: float) -> void:
	if not go:
		return
	t += dt
	var dist := (tgt - p.global_position).dot(hd)
	p.in_gas = 1.0 if p.kmh() < kmh else 0.0
	p.in_brake = 0.0
	p.in_steer = 0.0
	if dist > 6.0:
		v_pre = p.kmh()
	if dist < 3.0:
		vmin = minf(vmin, p.kmh())
	if int(t * 60.0) % 12 == 0 and dist < 8.0 and dist > -6.0:
		print("PT t=%.2f kmh=%.1f dist=%.2f actors=%d dmg=%.2f" % [t, p.kmh(), dist, gw.props.actors.size(), p.damage])
	if dist < -4.0 and not passed:
		passed = true
		t_pass = t
	if passed and t > t_pass + 4.5 or t > 14.0:
		report()
		get_tree().quit()


func report() -> void:
	print("PT RESULT mode=", mode, " v_pre=", snapped(v_pre, 0.1), " v_min=", snapped(vmin, 0.1), " v_now=", snapped(p.kmh(), 0.1), " dmg=", snapped(p.damage, 0.01))
	for a in gw.props.actors:
		var up: float = (a.rot * Vector3.UP).y
		print("PT actor t=", a.t, " pos=", a.pos - tgt, " tilt_deg=", snapped(rad_to_deg(acos(clampf(up, -1.0, 1.0))), 1.0), " v=", snapped(a.vel.length(), 0.1), " torn=", a.torn, " anch=", a.anch, " asleep=", a.asleep)
	print("PT water geysers=", gw.props.geysers.size(), " drops=", gw.props.dn, " under_k=", snapped(gw.props.under_k, 0.01))
