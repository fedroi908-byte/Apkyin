class_name Vehicle
extends RigidBody3D
## Rigid-body car with per-wheel spring/damper suspension on a virtual ground (terrain + bridge decks),
## slip-angle tyre model with a friction ellipse, engine torque curve with gearbox, aero drag/downforce,
## hull contact for roll-overs, and crash deformation (dents are applied in the paint shader).

signal crashed(speed: float)
signal hit_info(e: float, wp: Vector3, flags: int)   # damage hit for the sound system: flags 1 glass, 2 lamp, 4 wheel off, 8 body part

const GRAV := 9.81
const N_DENTS := 16

var body_kind := "sedan"
var color := Color(0.9, 0.2, 0.1)
var is_player := false
var is_bot := false                 # AI racer: no particle effects, otherwise the same physics
var drag_mult := 1.0                # < 1 in a slipstream (set by the race director)
static var wetness := 0.0           # rain on the road 0..1 (set by the world); lowers tyre grip
var stats: Dictionary = {}

# input
var in_steer := 0.0
var in_gas := 0.0
var in_brake := 0.0
var in_nitro := false
var _pm := 1.0                      # server tunables (game.power_mult / grip_mult / nitro_mult / damage_mult), read once per spawn
var _gm := 1.0
var _nm := 1.0
var _dm := 1.0
var in_handbrake := false

# car parameters (set in setup)
var car_mass := 1400.0
var wheel_r := 0.35
var wheelbase := 2.8
var track := 1.6
var t_max := 520.0                  # engine peak torque Nm
var rpm_idle := 900.0
var rpm_max := 7600.0
var gear_ratios := [3.55, 2.25, 1.62, 1.22, 0.98, 0.80]
var final_drive := 3.0
var drive_front := 0.0              # share of drive to the front axle
var cdA := 0.62
var clA := 0.25
var mu_tyre := 1.18
var max_steer := 0.55
var brake_bias := 0.62
var k_spring := 40000.0
var c_damp := 3200.0
var susp_len := 0.34
var arb := 16000.0

# state exposed to HUD / audio / camera
var speed := 0.0                    # signed km-independent forward speed in m/s
var lateral := 0.0
var yaw := 0.0
var steer := 0.0
var nitro := 1.0
var rpm := 0.0                      # 0..1
var gear := 1
var drifting := false
var slip := 0.0
var airborne := false
var damage := 0.0                   # 0..1
var model: Node3D
var wheels: Array = []
var spec: Dictionary = {}
var _blob: MeshInstance3D
var _blob_mat: StandardMaterial3D
var tail_mat: Material
var tail_mats: Array = []
var head_mats: Array = []
var skid: GPUParticles3D
var smoke: GPUParticles3D
var flame: GPUParticles3D
var headlights: Array = []

var _anchors: Array = []            # local suspension anchor per wheel
var _comp_prev := [0.0, 0.0, 0.0, 0.0]
var _comp := [0.0, 0.0, 0.0, 0.0]
var _grounded := [false, false, false, false]
var _wheel_spin := [0.0, 0.0, 0.0, 0.0]
var _wheel_w := [0.0, 0.0, 0.0, 0.0]
var _gear_i := 0
var _eng_rpm := 900.0
var _shift_t := 0.0
var _hull_pts: Array = []
var _paint: ShaderMaterial
var _paints: Array = []
var _dents: PackedVector4Array = PackedVector4Array()
var _dent_dirs: PackedVector4Array = PackedVector4Array()
var _dent_n := 0
var _hit_cool := 0.0
var _last_vel := Vector3.ZERO
var _rest_wheel_y := [0.0, 0.0, 0.0, 0.0]
var _reverse := false
var _surface_mu := 1.0
var damp_bump := 0.75               # shock absorbers: compression damping (x c_damp) - softer than rebound
var damp_reb := 1.35                # rebound damping (x c_damp)
var drift_k := 0.9                  # counter-steer gain on the slip angle
var drift_d := 0.15                 # ... and on its rate (damps fishtailing)
var _beta_prev := 0.0
var _dbeta_f := 0.0
var drift_assist := 0.85            # 0..1 counter-steer help in slides
var abs_on := true                  # anti-lock brakes (off: a wheel braked beyond the grip limit locks and loses side grip)
var brake_temp := 0.0               # 0..1 brake disc heat, above ~0.55 the brakes fade
var upside_down := false
var _wall_t := 0.0                  # seconds in continuous wall contact
var _wall_block := 0.0              # 0..1 how much the car is pushing head-on into a wall (cuts the drive force)
var _rebound_cool := 0.0
var _dmg_cool := 0.0
var _flip_t := 0.0
var _ground_y_cache := 0.0
var dmg := CarDamage.new()          # zone / part damage model: body zones, engine, radiator, struts, tyres, glass, lamps
var _dmg_ver := -1
var _parts: Array = []              # every non-paint body material that follows the deformation (car_part shader)
var _glass_mat: ShaderMaterial
var _hull_shape: BoxShape3D
var _hull_cs: CollisionShape3D
var _hull_base := Vector3.ONE
var _blast_pending := false
var blast: GPUParticles3D
var _wheel_camber := [0.0, 0.0, 0.0, 0.0]
var _wheel_toe := [0.0, 0.0, 0.0, 0.0]
var _lights_on := false
var _spark_t := 0.0
var scrape_amt := 0.0               # 0..1 metal scraping right now (sound)
var scrape_kind := 0                # 0 wall, 1 ground
var _spark_pos := Vector3.ZERO
var _bump_f := false
var _bump_r := false
var steam: GPUParticles3D
var dsmoke: GPUParticles3D
var fire: GPUParticles3D
var sparks: GPUParticles3D


func setup(kind: String, col: Color, st: Dictionary = {}) -> void:
	_pm = float(R.cfg("game.power_mult", 1.0))
	_gm = float(R.cfg("game.grip_mult", 1.0))
	_nm = float(R.cfg("game.nitro_mult", 1.0))
	_dm = float(R.cfg("game.damage_mult", 1.0))
	body_kind = kind
	color = col
	stats = st
	if is_bot:
		add_to_group("audio_cars")
	var light := not (is_player and int(Q.get_v("car_detail")) >= 3)       # ULTRA keeps the full model for the player only
	var c := CarBuilder.build(kind, col, Color(0.05, 0.05, 0.06), light)
	model = c["node"]
	wheels = c["wheels"]
	spec = c["spec"]
	tail_mat = c["tail"]
	tail_mats = c.get("tails", [])
	head_mats = c.get("heads", [])
	if model.has_meta("paint"):
		_paint = model.get_meta("paint") as ShaderMaterial
		_paints = model.get_meta("paints") if model.has_meta("paints") else [_paint]
	if tail_mats.is_empty() and tail_mat != null:
		tail_mats = [tail_mat]
	var dm := CarBuilder.make_deformable(model, wheels, head_mats, tail_mats)
	_parts = dm["parts"]
	_glass_mat = dm["glass"]
	if not tail_mats.is_empty():
		tail_mat = tail_mats[0]
	add_child(model)
	if not bool(Q.get_v("car_shadow")):
		# LOW quality: no real-time shadow from the (heavy) car meshes, use a cheap blob shadow instead
		for mi in model.find_children("*", "MeshInstance3D", true, false):
			(mi as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var blob := MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2(float(spec["wid"]) * 1.25, float(spec["len"]) * 1.15)
		qm.orientation = PlaneMesh.FACE_Y
		blob.mesh = qm
		var bm := StandardMaterial3D.new()
		bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		bm.albedo_color = Color(0, 0, 0, 0.45)
		bm.albedo_texture = _soft_tex()
		bm.render_priority = -1
		blob.material_override = bm
		blob.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		blob.top_level = true                # lies on the real ground below the car (junction patches / lifted roads would hide a body-attached quad)
		add_child(blob)
		_blob = blob
		_blob_mat = bm
	wheel_r = float(spec["wr"])
	wheelbase = float(spec["wb"])
	track = float(spec["wid_track"]) if spec.has("wid_track") else float(spec["wid"]) * 0.5 - 0.07
	var tp := float(st.get("top_speed", 0.6))
	var ac := float(st.get("accel", 0.6))
	var hd := float(st.get("handling", 0.6))
	var phys := CarBuilder.phys_of(kind)
	match phys:
		"hyper":
			car_mass = 1380.0
			t_max = 380.0 + 360.0 * ac
			mu_tyre = 1.35
			clA = 0.9
			cdA = 0.62
			drive_front = 0.0
		"super":
			car_mass = 1500.0
			t_max = 360.0 + 330.0 * ac
			mu_tyre = 1.3
			clA = 0.6
			cdA = 0.66
			drive_front = 0.0
		"muscle":
			car_mass = 1850.0
			t_max = 560.0 + 200.0 * ac
			mu_tyre = 1.05
			clA = 0.1
			cdA = 0.72
			drive_front = 0.0
		"coupe":
			car_mass = 1450.0
			t_max = 340.0 + 300.0 * ac
			mu_tyre = 1.25
			clA = 0.35
			cdA = 0.64
		"sedan":
			car_mass = 1550.0
			t_max = 300.0 + 220.0 * ac
			mu_tyre = 1.12
			drive_front = 0.0
		"hatch":
			car_mass = 1150.0
			t_max = 240.0 + 150.0 * ac
			mu_tyre = 1.1
			drive_front = 1.0
			cdA = 0.66
		"suv":
			car_mass = 2100.0
			t_max = 420.0 + 150.0 * ac
			mu_tyre = 1.0
			drive_front = 0.4
			cdA = 0.95
		"pickup":
			car_mass = 2300.0
			t_max = 450.0 + 120.0 * ac
			mu_tyre = 0.98
			drive_front = 0.4
			cdA = 1.0
		"van":
			car_mass = 2400.0
			t_max = 380.0
			mu_tyre = 0.95
			drive_front = 1.0
			cdA = 1.2
		"bus":
			car_mass = 11500.0
			t_max = 1500.0
			mu_tyre = 0.9
			cdA = 4.5
	max_steer = 0.48 + 0.14 * hd
	var load := car_mass * GRAV / 4.0
	k_spring = load / 0.095
	c_damp = 2.0 * 0.42 * sqrt(k_spring * car_mass / 4.0)
	arb = k_spring * 0.5
	abs_on = bool(st.get("abs", true))
	mass = car_mass
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0, 0.42 if phys != "bus" else 0.9, 0.0)
	var ext := Vector3(float(spec["wid"]), 1.3, float(spec["len"]))
	inertia = Vector3(car_mass * (ext.y * ext.y + ext.z * ext.z) / 11.0, car_mass * (ext.x * ext.x + ext.z * ext.z) / 11.0, car_mass * (ext.x * ext.x + ext.y * ext.y) / 11.0)
	linear_damp_mode = RigidBody3D.DAMP_MODE_REPLACE
	angular_damp_mode = RigidBody3D.DAMP_MODE_REPLACE
	linear_damp = 0.0
	angular_damp = 0.5
	collision_layer = 2
	collision_mask = 1 | 2 | 4          # world, other cars, props
	var pmat := PhysicsMaterial.new()    # slippery hull: side-swipes and walls slide instead of grabbing the car (tyre grip is computed separately)
	pmat.friction = 0.1
	pmat.bounce = 0.05
	physics_material_override = pmat
	continuous_cd = true
	contact_monitor = true
	max_contacts_reported = 6
	can_sleep = false
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(ext.x * 0.94, 0.86, ext.z * 0.96)
	cs.shape = sh
	cs.position = Vector3(0, 0.78, 0)
	_hull_shape = sh
	_hull_cs = cs
	_hull_base = sh.size
	add_child(cs)
	var ay := wheel_r + susp_len * 0.55
	_anchors = [Vector3(-track, ay, wheelbase * 0.5), Vector3(track, ay, wheelbase * 0.5), Vector3(-track, ay, -wheelbase * 0.5), Vector3(track, ay, -wheelbase * 0.5)]
	var hx := ext.x * 0.46
	var hz := ext.z * 0.46
	_hull_pts = [Vector3(-hx, 0.28, hz), Vector3(hx, 0.28, hz), Vector3(-hx, 0.28, -hz), Vector3(hx, 0.28, -hz),
		Vector3(-hx * 0.9, 1.25, hz * 0.55), Vector3(hx * 0.9, 1.25, hz * 0.55), Vector3(-hx * 0.9, 1.25, -hz * 0.55), Vector3(hx * 0.9, 1.25, -hz * 0.55)]
	if phys == "bus" or phys == "van":
		for p in _hull_pts.size():
			if (_hull_pts[p] as Vector3).y > 1.0:
				_hull_pts[p] = Vector3(_hull_pts[p].x, 2.4 if phys == "van" else 3.0, _hull_pts[p].z)
	for i in N_DENTS:
		_dents.append(Vector4(0, 0, 0, 0))
		_dent_dirs.append(Vector4(0, 0, 0, 0))
	if not is_bot:
		_make_fx()
		_make_dmg_fx()
	_make_lights()
	var hubs: Array = []
	for an in _anchors:
		hubs.append(Vector3((an as Vector3).x, wheel_r, (an as Vector3).z))
	dmg.configure(float(spec["len"]), float(spec["wid"]), 1.3, hubs, _dm)
	_push_dents()


static func _soft_tex() -> GradientTexture2D:
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 1))
	g.set_color(1, Color(1, 1, 1, 0))
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 64
	t.height = 64
	return t


func _make_fx() -> void:
	smoke = GPUParticles3D.new()
	smoke.amount = 70
	smoke.lifetime = 1.6
	smoke.emitting = false
	smoke.local_coords = false
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 25.0
	pm.initial_velocity_min = 0.6
	pm.initial_velocity_max = 2.0
	pm.gravity = Vector3(0, 0.6, 0)
	pm.scale_min = 0.8
	pm.scale_max = 2.4
	var sc := Curve.new()
	sc.add_point(Vector2(0, 0.3))
	sc.add_point(Vector2(1, 1.4))
	var sct := CurveTexture.new()
	sct.curve = sc
	pm.scale_curve = sct
	var gr := Gradient.new()
	gr.set_color(0, Color(0.85, 0.85, 0.85, 0.5))
	gr.set_color(1, Color(0.85, 0.85, 0.85, 0.0))
	var gt := GradientTexture1D.new()
	gt.gradient = gr
	pm.color_ramp = gt
	smoke.process_material = pm
	var qm := QuadMesh.new()
	qm.size = Vector2(1, 1)
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.vertex_color_use_as_albedo = true
	mt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mt.albedo_texture = _soft_tex()
	qm.material = mt
	smoke.draw_pass_1 = qm
	smoke.position = Vector3(0, 0.3, -float(spec["len"]) * 0.35)
	add_child(smoke)
	flame = GPUParticles3D.new()
	flame.amount = 40
	flame.lifetime = 0.25
	flame.emitting = false
	flame.local_coords = false
	var fm := ParticleProcessMaterial.new()
	fm.direction = Vector3(0, 0, -1)
	fm.spread = 6.0
	fm.initial_velocity_min = 8.0
	fm.initial_velocity_max = 12.0
	fm.gravity = Vector3.ZERO
	fm.scale_min = 0.2
	fm.scale_max = 0.5
	var fg := Gradient.new()
	fg.set_color(0, Color(0.5, 0.8, 1.0, 1.0))
	fg.set_color(1, Color(0.2, 0.3, 1.0, 0.0))
	var fgt := GradientTexture1D.new()
	fgt.gradient = fg
	fm.color_ramp = fgt
	flame.process_material = fm
	var fq := QuadMesh.new()
	fq.size = Vector2(0.4, 0.4)
	var fmt := StandardMaterial3D.new()
	fmt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fmt.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fmt.vertex_color_use_as_albedo = true
	fmt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	fmt.albedo_texture = _soft_tex()
	fq.material = fmt
	flame.draw_pass_1 = fq
	flame.position = Vector3(0, 0.4, -float(spec["len"]) * 0.5)
	add_child(flame)


func _make_lights() -> void:
	if not is_player:
		return
	for sx in [-1.0, 1.0]:
		var sl := SpotLight3D.new()
		sl.position = Vector3(sx * float(spec["wid"]) * 0.3, 0.75, float(spec["len"]) * 0.5)
		sl.rotation = Vector3(deg_to_rad(-3), PI, 0)
		sl.spot_range = 70.0
		sl.spot_angle = 32.0
		sl.light_energy = 0.0
		sl.shadow_enabled = false
		add_child(sl)
		headlights.append(sl)


func set_headlights(on: bool) -> void:
	_lights_on = on
	for i in headlights.size():
		var ok := dmg.lamp_f < (0.45 if i == 0 else 0.85)          # a smashed headlamp goes dark
		(headlights[i] as SpotLight3D).light_energy = 3.0 if (on and ok) else 0.0
	for hm in head_mats:
		_emit(hm, (2.5 if on else 0.25) * (0.1 if dmg.lamp_f > 0.6 else 1.0))


func reset_to(pos: Vector3, yaw_rad: float, keep_damage: bool = false) -> void:
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	global_transform = Transform3D(Basis(Vector3.UP, yaw_rad), pos)
	yaw = yaw_rad
	speed = 0.0
	lateral = 0.0
	_gear_i = 0
	_eng_rpm = rpm_idle
	for i in 4:
		_comp[i] = 0.0
		_comp_prev[i] = 0.0
	if not keep_damage:
		repair()


## Extra nitro from drifting / takedowns / perfect starts.
func nitro_gain(x: float) -> void:
	nitro = clampf(nitro + x, 0.0, 1.0)


func repair() -> void:
	damage = 0.0
	for i in N_DENTS:
		_dents[i] = Vector4(0, 0, 0, 0)
		_dent_dirs[i] = Vector4(0, 0, 0, 0)
	_dent_n = 0
	dmg.repair()
	_bump_f = false
	_bump_r = false
	_push_dents()
	_apply_damage()


func forward() -> Vector3:
	var f := -global_transform.basis.z
	return Vector3(f.x, 0, f.z).normalized() if false else global_transform.basis.z


func flat_forward() -> Vector3:
	var f := global_transform.basis.z
	f.y = 0.0
	return f.normalized() if f.length() > 0.01 else Vector3.FORWARD


func right() -> Vector3:
	var r := global_transform.basis.x
	r.y = 0.0
	return r.normalized() if r.length() > 0.01 else Vector3.RIGHT


func kmh() -> float:
	return absf(speed) * 3.6


func _push_dents() -> void:
	for pm in _paints:
		(pm as ShaderMaterial).set_shader_parameter("dents", _dents)
		(pm as ShaderMaterial).set_shader_parameter("dent_dirs", _dent_dirs)
		var dn := 0
		for i in _dents.size():
			if _dents[i].w > 0.0:
				dn = i + 1
		(pm as ShaderMaterial).set_shader_parameter("dent_n", dn)
		(pm as ShaderMaterial).set_shader_parameter("damage", damage)


func add_dent(local_pos: Vector3, local_dir: Vector3, amount_in: float) -> void:
	var amount := amount_in * _dm
	if amount <= 0.0005:
		return
	# merge into a nearby dent if there is one
	for i in _dent_n:
		var d := _dents[i]
		if Vector3(d.x, d.y, d.z).distance_to(local_pos) < 0.5:
			_dents[i].w = minf(d.w + amount, 0.55)
			var dd := Vector3(_dent_dirs[i].x, _dent_dirs[i].y, _dent_dirs[i].z) + local_dir * amount
			dd = dd.normalized()
			_dent_dirs[i] = Vector4(dd.x, dd.y, dd.z, 0)
			_push_dents()
			return
	var idx := _dent_n % N_DENTS
	_dents[idx] = Vector4(local_pos.x, local_pos.y, local_pos.z, minf(amount, 0.5))
	var ld := local_dir.normalized()
	_dent_dirs[idx] = Vector4(ld.x, ld.y, ld.z, 0)
	_dent_n += 1
	_push_dents()


func _engine_torque(r: float) -> float:
	# smooth torque curve peaking mid-range and falling towards the limiter
	var x := clampf((r - rpm_idle) / (rpm_max - rpm_idle), 0.0, 1.0)
	var curve := 0.55 + 1.6 * x - 1.55 * x * x * x
	curve = clampf(curve, 0.2, 1.0)
	if r > rpm_max * 0.985:
		curve *= 0.2
	return t_max * curve


func _surface_mu_at(p: Vector3) -> float:
	var rm := W.road_blend(p.x, p.z)
	var wet := 1.0 - 0.28 * wetness
	return lerpf(0.78, 1.0, rm) * wet


func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	var dt := state.step
	var xf := state.transform
	var up := xf.basis.y
	var vel := state.linear_velocity
	var fwd_flat := xf.basis.z
	fwd_flat.y = 0.0
	fwd_flat = fwd_flat.normalized() if fwd_flat.length() > 0.01 else Vector3.FORWARD
	speed = vel.dot(xf.basis.z)
	lateral = vel.dot(xf.basis.x)
	yaw = atan2(xf.basis.z.x, xf.basis.z.z)
	# ----- steering
	var spd := absf(speed)
	var steer_lim := max_steer / (1.0 + spd * spd * 0.0016) * dmg.steer_limit()
	# drift assist: the front wheels follow the slide (counter-steer) so a drift is controllable and recoverable; the handbrake / steering still start it
	var ctr := 0.0
	if speed > 5.0 and not airborne and drift_assist > 0.0:
		var beta := atan2(lateral, speed)                          # slip angle, > 0 = sliding to the car's left
		var be := signf(beta) * maxf(absf(beta) - 0.08, 0.0)
		_dbeta_f = lerpf(_dbeta_f, (beta - _beta_prev) / maxf(dt, 0.001), 0.3)
		ctr = -(be * drift_k + _dbeta_f * drift_d) * drift_assist * (1.0 - 0.45 * float(in_handbrake))
		steer_lim = maxf(steer_lim, max_steer * 0.55 * clampf(absf(beta) / 0.5, 0.0, 1.0))
	_beta_prev = atan2(lateral, maxf(speed, 1.0))
	var target := clampf(in_steer * steer_lim + ctr - dmg.steer_pull() * clampf(spd / 8.0, 0.0, 1.0), -max_steer * 1.2, max_steer * 1.2)
	# anti-spin: in a deep slide the engine backs off unless the driver steers into the drift
	var spin_cut := 1.0
	if speed > 5.0 and not airborne and drift_assist > 0.0 and not in_handbrake:
		var b2 := atan2(lateral, speed)
		var into_slide := in_steer * signf(b2)
		spin_cut = 1.0 - 0.85 * drift_assist * smoothstep(0.45, 0.85, absf(b2)) * (1.0 - clampf(into_slide, 0.0, 1.0) * 0.6)
	steer = lerpf(steer, target, clampf(dt * (10.0 if absf(target) > absf(steer) else 14.0), 0.0, 1.0))
	# ----- gearbox / engine
	var wheel_w_drive := 0.0
	wheel_w_drive = spd / wheel_r
	var ratio := 0.0
	var boosting := in_nitro and nitro > 0.02 and in_gas > 0.1
	_reverse = false
	if in_brake > 0.05 and speed < 0.8 and in_gas < 0.05:
		_reverse = true
	if _reverse:
		gear = -1
		ratio = -3.2 * final_drive
	else:
		var gr: float = gear_ratios[_gear_i]
		ratio = gr * final_drive
		var r_try := wheel_w_drive * ratio * 60.0 / TAU
		_shift_t = maxf(_shift_t - dt, 0.0)
		if _shift_t <= 0.0:
			if r_try > rpm_max * 0.86 and _gear_i < gear_ratios.size() - 1:
				_gear_i += 1
				_shift_t = 0.22
			elif r_try < rpm_max * 0.42 and _gear_i > 0:
				_gear_i -= 1
				_shift_t = 0.15
		gear = _gear_i + 1
		ratio = gear_ratios[_gear_i] * final_drive
	var wheel_rpm := wheel_w_drive * absf(ratio) * 60.0 / TAU
	var target_rpm := maxf(rpm_idle, wheel_rpm)
	if in_gas > 0.05 and spd < 6.0:
		target_rpm = maxf(target_rpm, rpm_idle + in_gas * 0.55 * (rpm_max - rpm_idle) * clampf(1.0 - spd / 8.0, 0.2, 1.0))
	_eng_rpm = lerpf(_eng_rpm, target_rpm, clampf(dt * 9.0, 0.0, 1.0))
	rpm = clampf((_eng_rpm - rpm_idle) / (rpm_max - rpm_idle), 0.0, 1.0)
	var torque := _engine_torque(_eng_rpm) * in_gas * (1.0 if _shift_t <= 0.0 else 0.2) * _pm * dmg.power_mult()
	if boosting:
		torque *= 1.0 + 0.6 * _nm
		nitro = maxf(nitro - dt * 0.17, 0.0)
	else:
		nitro = minf(nitro + dt * 0.035 * (1.0 if in_gas > 0.1 else 0.4), 1.0)
	var drive_total := torque * ratio * 0.9 / wheel_r * spin_cut     # N at the contact patches
	if wheel_rpm > rpm_max * 1.02 and not _reverse:
		drive_total = 0.0
	# ----- aero
	var v2 := vel.length_squared()
	var vdir := vel.normalized() if vel.length() > 0.1 else Vector3.ZERO
	state.apply_central_force(-vdir * (0.5 * 1.2 * cdA * drag_mult * dmg.drag_mult() * v2 + 0.012 * car_mass * GRAV * minf(vel.length(), 1.0)))
	state.apply_central_force(-up * 0.5 * 1.2 * clA * v2)
	# ----- suspension and tyres: the rays run along the car's OWN down axis, so a flipped / rolled car has no wheel contact (cannot drive or pop itself up)
	var grounded := 0
	var total_slip := 0.0
	var hs_brake := in_handbrake
	var ray_len := susp_len + wheel_r
	var drive_cut := 1.0 - 0.9 * _wall_block
	var brake_fade := 1.0 - 0.38 * smoothstep(0.55, 1.0, brake_temp)
	var brake_pw := 0.0
	var anchors_w: Array = []
	var nrms: Array = []
	var hits: Array = []
	var cpts: Array = []
	var cc := [0.0, 0.0, 0.0, 0.0]
	for i in 4:
		var anchor := xf * (_anchors[i] as Vector3)
		var ground_y := W.ground_height(anchor.x, anchor.z, anchor.y + 0.5)
		var nrm := W.terrain_normal(anchor.x, anchor.z)
		var ndot := up.dot(nrm)
		var th := 1e9
		if ndot > 0.12:
			th = (anchor.y - ground_y) * nrm.y / ndot          # distance along the strut axis to the ground plane
		var comp := ray_len - th
		var contact := th < 1e8 and comp > 0.0 and th > -0.5 and not bool(dmg.detached[i])
		_grounded[i] = contact
		anchors_w.append(anchor)
		nrms.append(nrm)
		hits.append(th)
		cpts.append(anchor - up * th if contact else anchor - up * ray_len)
		cc[i] = minf(comp, susp_len + 0.12) if contact else 0.0
	for i in 4:
		var local_anchor: Vector3 = _anchors[i]
		var wp: Node3D = wheels[i]
		if not _grounded[i]:
			_comp_prev[i] = 0.0
			_comp[i] = lerpf(_comp[i], -0.02, clampf(dt * 6.0, 0.0, 1.0))
			wp.position = Vector3(local_anchor.x, local_anchor.y - (susp_len + 0.1), local_anchor.z)
			_wheel_w[i] = lerpf(_wheel_w[i], speed / wheel_r * 0.3, dt * 0.5)
			continue
		grounded += 1
		var th: float = hits[i]
		var nrm: Vector3 = nrms[i]
		var contact_pt: Vector3 = cpts[i]
		var rel := contact_pt - xf.origin
		var comp_c: float = cc[i]
		var other: int = i ^ 1
		var arb_f: float = arb * (comp_c - float(cc[other])) * 0.5 if _grounded[other] else 0.0
		# shock absorber: stiffer on rebound than on bump; first contact uses the strut velocity (no spike); progressive bump stop
		var cvel: float
		if _comp_prev[i] > 0.0:
			cvel = (comp_c - _comp_prev[i]) / dt
		else:
			cvel = -state.get_velocity_at_local_position((anchors_w[i] as Vector3) - xf.origin).dot(up)
		cvel = clampf(cvel, -6.0, 6.0)
		var cdamp := c_damp * (damp_bump if cvel > 0.0 else damp_reb) * dmg.damper_mult(i)
		var stop := k_spring * 5.0 * maxf(comp_c - susp_len * 0.9, 0.0)
		var load := maxf(k_spring * dmg.spring_mult(i) * comp_c + cdamp * cvel + arb_f + stop, 0.0)
		load = minf(load, car_mass * GRAV * 3.2)
		_comp_prev[i] = comp_c
		_comp[i] = comp_c
		# visual wheel position
		wp.position = Vector3(local_anchor.x, local_anchor.y - clampf(th - wheel_r, 0.04, susp_len + 0.16), local_anchor.z)
		# normal force along ground normal (mostly up)
		state.apply_force(nrm * load, rel)
		# tyre frame
		var steer_a := steer if i < 2 else 0.0
		var wf := (Basis(up, -steer_a) * fwd_flat) if absf(steer_a) > 0.0001 else fwd_flat
		wf = (wf - nrm * wf.dot(nrm)).normalized()
		var wl := nrm.cross(wf).normalized()
		var cv := state.get_velocity_at_local_position(rel)
		var vlong := cv.dot(wf)
		var vlat := cv.dot(wl)
		var mu := mu_tyre * _gm * _surface_mu_at(contact_pt) * dmg.grip_mult(i)
		var rear := i >= 2
		var drive_share := drive_front if not rear else (1.0 - drive_front)
		var fx := drive_total * drive_share * 0.5 * drive_cut
		# brakes: bias, heat fade; the friction ellipse below is the ABS limit
		var brake_f := 0.0
		if in_brake > 0.05 and not _reverse:
			var share := brake_bias if not rear else (1.0 - brake_bias)
			brake_f = in_brake * load * mu * share * 2.0 * brake_fade * dmg.brake_mult()
		var lock := 0.0
		if hs_brake and rear:
			lock = 1.0
		var fx_req := fx
		if absf(vlong) > 0.05:
			fx_req -= signf(vlong) * (brake_f + lock * load * mu * 0.95)
		else:
			fx_req -= vlong * 4000.0 * (1.0 if (in_brake > 0.05 or in_gas < 0.05) else 0.0)
		# reverse: brake pedal drives backwards
		if _reverse:
			fx_req = (-3200.0 * in_brake) * drive_share * 0.5 * 1.0
		var fmax := load * mu
		# lateral slip-angle force
		var sa := atan2(vlat, absf(vlong) + 0.8)
		var lat_gain := clampf(absf(vlat) / 0.35, 0.0, 1.0) if absf(vlong) < 2.0 else 1.0
		var mu_l := mu * (0.55 if lock > 0.5 else 1.0)
		if not abs_on and brake_f > fmax * 1.04 and absf(vlong) > 2.0:
			mu_l *= 0.45                                         # no ABS: braked beyond the limit -> wheel locks, little side grip, less braking
			fx_req = fx - signf(vlong) * fmax * 0.8
		var fy_req := -load * mu_l * sin(1.55 * atan(7.5 * sa)) * lat_gain
		# friction ellipse
		var mag := sqrt(fx_req * fx_req + fy_req * fy_req)
		if mag > fmax and mag > 0.001:
			var k := fmax / mag
			fx_req *= k
			fy_req *= k
			total_slip += 1.0
		brake_pw += minf(brake_f, fmax) * absf(vlong)
		# low-speed lateral stiction: tyres hold the car still
		if spd < 1.5 and absf(vlat) < 1.5:
			fy_req += -vlat * load * 0.8
		state.apply_force(wf * fx_req + wl * fy_req, rel)
		_wheel_w[i] = vlong / wheel_r
		if (absf(fx) > fmax * 0.9 and in_gas > 0.5 and spd < 40.0 and rear):
			_wheel_w[i] = vlong / wheel_r + 25.0 * in_gas
		if lock > 0.5 and spd > 3.0:
			_wheel_w[i] = 0.0
	brake_temp = clampf(brake_temp + brake_pw * dt / (1.12e7 * car_mass / 1400.0) - brake_temp * (0.012 + 0.0006 * spd) * dt, 0.0, 1.0)
	airborne = grounded == 0
	upside_down = up.y < -0.2
	slip = clampf(absf(lateral) / maxf(spd, 5.0), 0.0, 1.0)
	drifting = (absf(lateral) > 3.2 and spd > 8.0) or (hs_brake and spd > 8.0) or (total_slip > 1.5 and spd > 12.0)
	# a car left on its roof / side rights itself after a moment
	if up.y < 0.35 and spd < 5.0 and grounded == 0:
		_flip_t += dt
		if _flip_t > 2.5:
			_flip_t = 0.0
			state.transform = Transform3D(Basis(Vector3.UP, yaw), xf.origin + Vector3.UP * 1.1)
			state.linear_velocity = Vector3.ZERO
			state.angular_velocity = Vector3.ZERO
	else:
		_flip_t = 0.0
	# ----- hull contact with the virtual ground (roll-overs, hard landings)
	for hp in _hull_pts:
		var wp2 := xf * (hp as Vector3)
		var gy := W.ground_height(wp2.x, wp2.z, wp2.y + 0.5)
		var pen := gy - wp2.y
		if pen > 0.0:
			var rel2 := wp2 - xf.origin
			var hv := state.get_velocity_at_local_position(rel2)
			var fn := clampf(90000.0 * pen - 2500.0 * hv.y, 0.0, car_mass * GRAV * 4.0)
			state.apply_force(Vector3.UP * fn, rel2)
			var tang := Vector3(hv.x, 0, hv.z)
			state.apply_force(-tang * minf(fn * 0.6 / maxf(tang.length(), 0.5), 6000.0) , rel2)
			if tang.length() > 5.0 and fn > car_mass * GRAV * 0.3:
				_spark_t = 0.1
				_spark_pos = wp2
				scrape_amt = clampf(tang.length() / 30.0, 0.2, 1.0)
				scrape_kind = 1
				dmg.scrape(hp as Vector3, 0.002 * tang.length() * dt)
			if fn > car_mass * GRAV * 2.0 and _hit_cool <= 0.0:
				_hit_cool = 0.4
				dmg.hit(hp as Vector3, clampf(absf(hv.y) / 20.0, 0.05, 0.9))
				damage = dmg.overall()
				_spark_t = 0.2
				_spark_pos = wp2
				crashed.emit(absf(hv.y) + 4.0)
	# weak stabilising torque so tiny perturbations on the road do not build up
	# ----- crash response: walls / buildings
	if _blast_pending:
		_blast_pending = false
		state.apply_central_impulse(Vector3(0, 3.2 * car_mass, 0))
		state.apply_torque_impulse(Vector3(randf_range(-1.0, 1.0), 0.0, randf_range(-1.0, 1.0)) * car_mass * 0.8)
	_hit_cool = maxf(_hit_cool - dt, 0.0)
	_rebound_cool = maxf(_rebound_cool - dt, 0.0)
	_dmg_cool = maxf(_dmg_cool - dt, 0.0)
	var ncon := state.get_contact_count()
	var wall_n := Vector3.ZERO
	var wall_imp := 0.0
	var best := 0.0
	var bp := xf.origin
	var bn := Vector3.ZERO
	var have_c := false
	var pre_w := 0.0
	var cpos: Array = []
	var cimp: Array = []
	for ci in ncon:
		var cn := state.get_contact_local_normal(ci)
		var imp := state.get_contact_impulse(ci).length() / car_mass
		cpos.append(state.get_contact_local_position(ci))
		cimp.append(imp)
		if cn.y < 0.6 and state.get_contact_collider_object(ci) is StaticBody3D:      # buildings / barriers only (cars keep the plain solver response)
			wall_n += cn
			wall_imp += imp
		if imp > best or not have_c:
			best = maxf(best, imp)
			bp = state.get_contact_local_position(ci)
			bn = cn
			have_c = true
	if wall_n.length() > 0.01:
		wall_n = wall_n.normalized()
		_wall_t += dt
		pre_w = -wall_n.dot(_last_vel)
		var pre := pre_w                       # speed into the wall before the solver stopped it
		var into := -wall_n.dot(vel)
		# rebound grows with the impact speed: the car bounces off the building instead of dying on it
		if pre > 4.0 and _rebound_cool <= 0.0:
			var e := 0.1 + 0.2 * clampf((pre - 4.0) / 24.0, 0.0, 1.0)
			var want := e * pre
			if want > -into:
				state.apply_impulse(wall_n * car_mass * (want + into), Vector3((bp - xf.origin).x, 0.0, (bp - xf.origin).z).limit_length(3.0))
			_rebound_cool = 0.25
		# scraping resistance grows with speed
		var vt := vel - wall_n * vel.dot(wall_n)
		var vtl := vt.length()
		if vtl > 0.5:
			state.apply_central_force(-vt / vtl * car_mass * (2.5 + 0.1 * vtl) * clampf(_wall_t * 8.0, 0.0, 1.0))
		if vtl > 4.0:
			_spark_t = 0.1
			_spark_pos = bp
			scrape_amt = clampf(vtl / 25.0, 0.25, 1.0)
			scrape_kind = 0
			dmg.scrape(xf.affine_inverse() * bp, 0.0035 * vtl * dt)
			damage = dmg.overall()
		_wall_block = clampf(-wall_n.dot(fwd_flat) * 2.0, 0.0, 1.0)
		# wedged against a wall: ease the car out
		if _wall_t > 0.8 and spd < 1.5:
			state.apply_central_force(wall_n * car_mass * 5.0)
	else:
		_wall_t = 0.0
		_wall_block = 0.0
	var dv := maxf(best, pre_w)
	if dv > 2.2 and _dmg_cool <= 0.0:
		_dmg_cool = 0.3
		var inv := xf.affine_inverse()
		var lp := inv * bp
		var ln := (inv.basis * bn).normalized()                # dent direction: into the body
		var e := clampf(pow(dv / 18.0, 2.0), 0.0, 4.0)         # kinetic-energy scale: 50 km/h ~ 0.6, 100 km/h ~ 2.4
		var g0 := dmg.glass
		var lf0 := dmg.lamp_f
		var lr0 := dmg.lamp_r
		var det0: Array = dmg.detached.duplicate()
		var tot := 0.0
		for im in cimp:
			tot += float(im)
		var nc := maxi(cpos.size(), 1)
		for k in cpos.size():
			var share := (float(cimp[k]) / tot) if tot > 0.001 else 1.0 / float(nc)
			var lpk := inv * (cpos[k] as Vector3)
			dmg.hit(lpk, e * share)                             # the whole contact patch crumples, not one corner
			if share > 0.2:
				add_dent(lpk, ln, clampf(dv * 0.03 * (0.5 + share), 0.03, 0.4))
		damage = dmg.overall()
		call_deferred("_on_dmg_hit", lp, bp, minf(e, 1.5), g0, lf0, lr0, det0)
		crashed.emit(dv)
	_last_vel = vel
	# anti-tumble when upside down on the ground: leave physics alone
	# lights / fx
	var wheel_avg := 0.0
	for i in 4:
		_wheel_spin[i] += _wheel_w[i] * dt
	_after_physics(dt, boosting)


func _after_physics(dt: float, boosting: bool) -> void:
	if dmg.version != _dmg_ver:
		_apply_damage()
	_dmg_fx(dt)
	var ev := dmg.step(dt, absf(speed), in_gas, _spark_t > 0.0)
	if ev == 2:
		_explode()
	if _blob:
		var bp := global_position
		var gy := W.ground_height(bp.x, bp.z, bp.y + 1.0)
		var yaw := atan2(global_transform.basis.z.x, global_transform.basis.z.z)
		_blob.global_transform = Transform3D(Basis(Quaternion(Vector3.UP, W.terrain_normal(bp.x, bp.z))) * Basis(Vector3.UP, yaw), Vector3(bp.x, gy + 0.11, bp.z))
		_blob_mat.albedo_color = Color(0, 0, 0, 0.55 * clampf(1.0 - maxf(bp.y - gy - 0.5, 0.0) / 5.0, 0.0, 1.0))
	var w2c := global_transform.affine_inverse()
	for pm in _paints:
		(pm as ShaderMaterial).set_shader_parameter("car_to_world", global_transform)
		(pm as ShaderMaterial).set_shader_parameter("world_to_car", w2c)
	if dmg.any():
		for pm in _parts:
			(pm as ShaderMaterial).set_shader_parameter("world_to_car", w2c)
		if _glass_mat != null:
			_glass_mat.set_shader_parameter("world_to_car", w2c)
	for i in wheels.size():
		var w: Node3D = wheels[i]
		w.rotation = Vector3(0, (-steer if i < 2 else 0.0) + _wheel_toe[i], _wheel_camber[i])
		(w.get_child(0) as Node3D).rotation.x = _wheel_spin[i]
	if model.has_meta("steer_pivot"):
		var sax: Vector3 = model.get_meta("steer_axis") if model.has_meta("steer_axis") else Vector3(0, 0.35, -0.94).normalized()
		(model.get_meta("steer_pivot") as Node3D).basis = Basis(sax, -steer * (11.0 if model.has_meta("steer_axis") else 7.5))
	if smoke:
		smoke.emitting = (drifting and absf(speed) > 8.0 and not airborne) or (damage > 0.7 and absf(speed) > 2.0)
		flame.emitting = boosting
	if tail_mats.is_empty():
		tail_mats = [tail_mat] if tail_mat else []
	for tm in tail_mats:
		_emit(tm, (0.5 + 2.5 * in_brake) * (0.12 if dmg.lamp_r > 0.5 else 1.0))


## Visual state after the damage model changed: crumple of every body surface, bent / missing wheels, cracked glass, dead lamps, hull size.
func _apply_damage() -> void:
	_dmg_ver = dmg.version
	damage = dmg.overall()
	var dim := Vector3(float(spec["wid"]), 1.3, float(spec["len"]))
	var on := 1.0 if dmg.any() else 0.0
	var mats: Array = _paints + _parts
	if _glass_mat != null:
		mats.append(_glass_mat)
	for pm in mats:
		var m := pm as ShaderMaterial
		m.set_shader_parameter("zd0", dmg.pack0())
		m.set_shader_parameter("zd1", dmg.pack1())
		m.set_shader_parameter("zd2", dmg.pack2())
		m.set_shader_parameter("zd3", dmg.pack3())
		m.set_shader_parameter("zd_dim", dim)
		m.set_shader_parameter("zd_on", on)
	for pm in _paints:
		(pm as ShaderMaterial).set_shader_parameter("damage", damage)
	if _glass_mat != null:
		_glass_mat.set_shader_parameter("crack", dmg.glass)
	for i in wheels.size():
		(wheels[i] as Node3D).visible = not bool(dmg.detached[i])
		var sgn := signf((_anchors[i] as Vector3).x)
		_wheel_camber[i] = sgn * dmg.susp[i] * 0.22
		_wheel_toe[i] = -sgn * dmg.susp[i] * 0.12
	set_headlights(_lights_on)
	call_deferred("_update_hull")


func _mk_ps(amount: int, life: float, dir: Vector3, spread: float, v0: float, v1: float, grav: Vector3, s0: float, s1: float, c0: Color, c1: Color, additive: bool, size: float = 1.0) -> GPUParticles3D:
	var ps := GPUParticles3D.new()
	ps.amount = amount
	ps.lifetime = life
	ps.emitting = false
	ps.local_coords = false
	var pm := ParticleProcessMaterial.new()
	pm.direction = dir
	pm.spread = spread
	pm.initial_velocity_min = v0
	pm.initial_velocity_max = v1
	pm.gravity = grav
	pm.scale_min = s0
	pm.scale_max = s1
	var gr := Gradient.new()
	gr.set_color(0, c0)
	gr.set_color(1, c1)
	var gt := GradientTexture1D.new()
	gt.gradient = gr
	pm.color_ramp = gt
	ps.process_material = pm
	var qm := QuadMesh.new()
	qm.size = Vector2(size, size)
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.vertex_color_use_as_albedo = true
	mt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mt.albedo_texture = _soft_tex()
	if additive:
		mt.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	qm.material = mt
	ps.draw_pass_1 = qm
	add_child(ps)
	return ps


## Engine steam / smoke / fire at the bonnet and wall / road scrape sparks (player and traffic-near cars only).
func _make_dmg_fx() -> void:
	var hood := Vector3(0, 0.95, float(spec["len"]) * 0.3)
	steam = _mk_ps(36, 1.3, Vector3.UP, 20.0, 1.0, 2.5, Vector3(0, 1.0, 0), 0.6, 1.6, Color(1, 1, 1, 0.5), Color(1, 1, 1, 0.0), false)
	dsmoke = _mk_ps(40, 1.8, Vector3.UP, 18.0, 1.5, 3.5, Vector3(0, 0.8, 0), 0.7, 2.0, Color(0.1, 0.1, 0.1, 0.75), Color(0.15, 0.15, 0.15, 0.0), false)
	fire = _mk_ps(26, 0.5, Vector3.UP, 14.0, 1.2, 3.0, Vector3(0, 2.0, 0), 0.3, 0.7, Color(1.0, 0.6, 0.15, 0.9), Color(1.0, 0.1, 0.0, 0.0), true)
	steam.position = hood
	dsmoke.position = hood
	fire.position = hood
	sparks = _mk_ps(40, 0.5, Vector3.UP, 80.0, 3.0, 9.0, Vector3(0, -12, 0), 0.2, 0.5, Color(1, 0.9, 0.5, 1), Color(1, 0.4, 0.05, 0), true, 0.12)
	sparks.top_level = true
	blast = _mk_ps(70, 1.3, Vector3.UP, 70.0, 3.0, 9.0, Vector3(0, 2.5, 0), 0.8, 2.6, Color(1.0, 0.75, 0.25, 0.95), Color(0.25, 0.1, 0.05, 0.0), true, 1.0)
	blast.one_shot = true
	blast.explosiveness = 0.95
	blast.position = Vector3(0, 0.8, 0)


func _dmg_fx(dt: float) -> void:
	_spark_t = maxf(_spark_t - dt, 0.0)
	scrape_amt = maxf(scrape_amt - dt * 5.0, 0.0)
	if steam == null:
		return
	steam.emitting = (dmg.radiator > 0.3 or dmg.temp > 0.85) and dmg.engine < 0.9 and not dmg.fire
	dsmoke.emitting = dmg.engine > 0.55 or dmg.burn > 0.15
	fire.emitting = dmg.fire
	sparks.emitting = _spark_t > 0.0
	if _spark_t > 0.0:
		sparks.global_position = _spark_pos


## Debris after a hit: body chunks, glass / lamp shards, a bumper, mirrors, a wheel that comes off.
func _on_dmg_hit(lp: Vector3, wp: Vector3, e: float, g0: float, lf0: float, lr0: float, det0: Array) -> void:
	_spark_t = 0.25
	_spark_pos = wp
	var fl := 0
	if dmg.glass > g0 + 0.05:
		fl |= 1
	if dmg.lamp_f > lf0 + 0.05 or dmg.lamp_r > lr0 + 0.05:
		fl |= 2
	for wi in 4:
		if bool(dmg.detached[wi]) and not bool(det0[wi]):
			fl |= 4
	if e > 0.55:
		fl |= 8
	hit_info.emit(e, wp, fl)
	var par := get_parent()
	if par == null or (is_bot and e < 0.45):
		return
	var xf := global_transform
	var vel := linear_velocity
	var len_m := float(spec["len"])
	var wid_m := float(spec["wid"])
	var out := wp - global_position
	out.y = 0.0
	out = out.normalized() if out.length() > 0.05 else xf.basis.z
	var n_pan := clampi(int(e * 7.0), 1, 9)
	for k in n_pan:
		var sz := Vector3(randf_range(0.08, 0.3), randf_range(0.02, 0.06), randf_range(0.08, 0.25))
		var v := out * randf_range(2.0, 6.0) * (0.6 + e) + vel * 0.35 + Vector3(randf_range(-2.0, 2.0), randf_range(1.5, 4.5), randf_range(-2.0, 2.0))
		var sp := Vector3(randf_range(-9.0, 9.0), randf_range(-9.0, 9.0), randf_range(-9.0, 9.0))
		Debris.spawn(par, "panel" if k % 3 != 0 else "dark", sz, color, wp + Vector3(randf_range(-0.25, 0.25), 0.25, randf_range(-0.25, 0.25)), v, sp, 5.0 + randf() * 3.0)
	if dmg.glass > 0.5 and g0 <= 0.5:
		for k in 8:
			var gp := xf * Vector3(randf_range(-0.5, 0.5) * wid_m * 0.5, 1.0, randf_range(-0.2, 0.5) * len_m * 0.5)
			Debris.spawn(par, "glass", Vector3(0.07, 0.015, 0.07) * randf_range(0.6, 1.8), color, gp, vel * 0.4 + Vector3(randf_range(-2.0, 2.0), randf_range(1.0, 4.0), randf_range(-2.0, 2.0)), Vector3(randf_range(-6.0, 6.0), randf_range(-6.0, 6.0), randf_range(-6.0, 6.0)), 4.0)
	if dmg.lamp_f > 0.5 and lf0 <= 0.5:
		for k in 5:
			Debris.spawn(par, "lamp", Vector3(0.06, 0.03, 0.06), color, xf * Vector3(float(k % 2 * 2 - 1) * wid_m * 0.3, 0.7, len_m * 0.46), vel * 0.5 + Vector3(randf_range(-2.0, 2.0), randf_range(1.0, 3.5), randf_range(1.0, 3.0)), Vector3(randf_range(-8.0, 8.0), randf_range(-8.0, 8.0), randf_range(-8.0, 8.0)), 4.0)
	if dmg.lamp_r > 0.5 and lr0 <= 0.5:
		for k in 5:
			Debris.spawn(par, "lamp", Vector3(0.06, 0.03, 0.06), color, xf * Vector3(float(k % 2 * 2 - 1) * wid_m * 0.3, 0.7, -len_m * 0.46), vel * 0.5 + Vector3(randf_range(-2.0, 2.0), randf_range(1.0, 3.5), randf_range(-3.0, -1.0)), Vector3(randf_range(-8.0, 8.0), randf_range(-8.0, 8.0), randf_range(-8.0, 8.0)), 4.0)
	if e > 0.55 and lp.z > 0.2 * len_m and not _bump_f:
		_bump_f = true
		Debris.spawn(par, "dark", Vector3(wid_m * 0.7, 0.18, 0.32), color, xf * Vector3(0, 0.45, len_m * 0.48), out * 3.0 + vel * 0.5 + Vector3.UP * 2.5, Vector3(randf_range(-2.0, 2.0), randf_range(-3.0, 3.0), randf_range(-2.0, 2.0)), 7.0)
	if e > 0.55 and lp.z < -0.2 * len_m and not _bump_r:
		_bump_r = true
		Debris.spawn(par, "dark", Vector3(wid_m * 0.7, 0.18, 0.32), color, xf * Vector3(0, 0.45, -len_m * 0.48), out * 3.0 + vel * 0.5 + Vector3.UP * 2.5, Vector3(randf_range(-2.0, 2.0), randf_range(-3.0, 3.0), randf_range(-2.0, 2.0)), 7.0)
	if e > 0.45 and absf(lp.x) > 0.3 * wid_m and absf(lp.z) < 0.35 * len_m:
		Debris.spawn(par, "chrome", Vector3(0.12, 0.1, 0.06), color, xf * Vector3(signf(lp.x) * wid_m * 0.52, 1.0, len_m * 0.12), out * 3.0 + vel * 0.4 + Vector3.UP * 2.0, Vector3(randf_range(-9.0, 9.0), randf_range(-9.0, 9.0), randf_range(-9.0, 9.0)), 5.0)
	for i in 4:
		if bool(dmg.detached[i]) and not bool(det0[i]):
			var side := signf((_anchors[i] as Vector3).x)
			Debris.spawn_wheel(par, wheel_r, 0.26, xf * (wheels[i] as Node3D).position, vel * 0.85 + xf.basis.x * side * 3.0 + Vector3.UP * 2.5, yaw)


## The collision box follows the crushed body: a flattened nose no longer collides at its old length.
func _update_hull() -> void:
	if _hull_shape == null:
		return
	var cf := clampf(dmg.front() * 0.62, 0.0, 0.7)
	var cr := clampf(dmg.rear() * 0.55, 0.0, 0.6)
	var cl := clampf(dmg.zone[3] * 0.3, 0.0, 0.3)
	var crr := clampf(dmg.zone[4] * 0.3, 0.0, 0.3)
	var ch := clampf(dmg.zone[8] * 0.25, 0.0, 0.25)
	_hull_shape.size = Vector3(_hull_base.x - cl - crr, _hull_base.y - ch, _hull_base.z - cf - cr)
	_hull_cs.position = Vector3((crr - cl) * 0.5, 0.78 - ch * 0.5, (cr - cf) * 0.5)


## Fuel fire reached the tank: fireball, hop, flying fragments.
func _explode() -> void:
	_blast_pending = true
	if blast != null:
		blast.restart()
		blast.emitting = true
	var par := get_parent()
	if par != null:
		for k in 10:
			Debris.spawn(par, "panel" if k % 2 == 0 else "dark", Vector3(randf_range(0.15, 0.5), 0.04, randf_range(0.15, 0.4)), color, global_position + Vector3(0, 0.8, 0), Vector3(randf_range(-6.0, 6.0), randf_range(4.0, 10.0), randf_range(-6.0, 6.0)), Vector3(randf_range(-9.0, 9.0), randf_range(-9.0, 9.0), randf_range(-9.0, 9.0)), 8.0)
	crashed.emit(30.0)


## Lamp brightness on either material kind (StandardMaterial3D or the car_part shader material).
func _emit(m: Material, v: float) -> void:
	if m is ShaderMaterial:
		(m as ShaderMaterial).set_shader_parameter("emit_energy", v)
	elif m is StandardMaterial3D:
		(m as StandardMaterial3D).emission_energy_multiplier = v


func prop_hit(wp: Vector3, n: Vector3, dv: float, k: float) -> void:
	if dv < 2.0 or _dmg_cool > 0.0:
		return
	var e := clampf(pow(dv / 18.0, 2.0) * k, 0.0, 4.0)
	if e < 0.02:
		return
	_dmg_cool = 0.25
	var inv := global_transform.affine_inverse()
	var lp := inv * wp
	var ln := (inv.basis * n).normalized()
	var g0 := dmg.glass
	var lf0 := dmg.lamp_f
	var lr0 := dmg.lamp_r
	var det0: Array = dmg.detached.duplicate()
	dmg.hit(lp, e)
	add_dent(lp, ln, clampf(dv * 0.03 * k, 0.02, 0.35))
	damage = dmg.overall()
	call_deferred("_on_dmg_hit", lp, wp, minf(e, 1.5), g0, lf0, lr0, det0)
	if dv * k > 3.0:
		crashed.emit(dv * k)
