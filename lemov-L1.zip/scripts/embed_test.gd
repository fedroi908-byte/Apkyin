extends SceneTree
## Real-data check of the config that ships inside the game (data/fx.bin) against the live manifest of the server repo.
## run:  godot --headless --path . --script res://scripts/embed_test.gd -- <manifest.json> <manifest.sig>
var R = null
var fails := 0


func _chk(ok: bool, what: String) -> void:
	if not ok:
		fails += 1
		print("FAIL ", what)


func _initialize() -> void:
	_run()


func _run() -> void:
	await process_frame
	await process_frame
	R = root.get_node("R")
	var a := OS.get_cmdline_user_args()
	_chk(R.enabled, "embedded config boots the client")
	_chk(R._src.size() == 2, "two content sources")
	_chk(R._src.size() > 0 and String(R._src[0]).begins_with("https://"), "https sources")
	_chk(String(R._tel).begins_with("https://"), "telemetry url")
	_chk(String(R._hk).length() == 64, "hmac key present")
	var mf := FileAccess.get_file_as_bytes(a[0])
	var sig := FileAccess.get_file_as_string(a[1]).strip_edges()
	_chk(mf.size() > 100, "manifest file read")
	_chk(R.verify_sig(mf, sig, R._key), "real manifest signature verifies with the embedded key")
	var bad := mf.duplicate()
	bad[10] = int(bad[10]) ^ 1
	_chk(not R.verify_sig(bad, sig, R._key), "tampered manifest rejected")
	print("EMBED_TEST fails=", fails)
	quit(1 if fails > 0 else 0)
