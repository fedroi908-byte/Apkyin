extends SceneTree
func _init() -> void:
	for c in ["AudioEffectLowShelfFilter", "AudioEffectHighShelfFilter", "AudioEffectLowPassFilter", "AudioEffectLimiter", "AudioEffectHardLimiter", "AudioEffectReverb", "AudioEffectCompressor"]:
		print(c, " exists=", ClassDB.class_exists(c))
		if ClassDB.class_exists(c):
			var o: Object = ClassDB.instantiate(c)
			var names := []
			for pr in o.get_property_list():
				if int(pr["usage"]) & PROPERTY_USAGE_EDITOR:
					names.append(pr["name"])
			print("  ", names)
	var s := AudioStreamPlayer3D.new()
	print("3d props doppler=", "doppler_tracking" in s, " filt=", "attenuation_filter_cutoff_hz" in s, " maxdb=", "max_db" in s, " pan=", "panning_strength" in s)
	print("cam doppler=", "doppler_tracking" in Camera3D.new())
	quit()
