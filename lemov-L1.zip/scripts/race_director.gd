class_name RaceDirector
extends Node
## The opponents and the rules of a road race: start grid, AI racers with personalities, progress / laps / lap times, standings and rubber
## banding, slipstream, takedowns, wrong-way warning, finish classification. The mission runner owns the clock, HUD and result.

signal event(kind: String, text: String)

const NAMES := ["VIPER", "NOVA", "BLAZE", "RAVEN", "COMET", "GHOST", "TURBO", "FALCON", "NITRO", "SPECTRE", "DRAKE", "ORBIT"]

var gw: GameWorld
var m: Dictionary
var path: RacePath
var laps := 1
var total := 0.0
var racers: Array = []                  # {name, car, drv, prog, lat, spd, fin, ft, you, lap, lap_t, best, draft, tag}
var go := false
var t := 0.0                            # race clock (since GO)
var takedowns := 0
var half_w := 6.0
var _you: Dictionary = {}
var _pidx := 0
var _ptrk: RacePath.Tracker
var _plap := 0
var _slow_t := 0.0
var _cull_t := 0.0
var _slot_n := 1
var _prev_pos := 0
var _wrong_t := 0.0
var _td_cd := {}
var _rng := RandomNumberGenerator.new()


static var force_bots := -1


static func bot_count() -> int:
	if force_bots >= 0:
		return force_bots
	var c := int(R.cfg("game.bots", -1))
	var n: int = int(Q.get_v("bots")) if c < 0 else c
	return clampi(n, 0, 11)


func setup(world: GameWorld, mission: Dictionary) -> void:
	gw = world
	m = mission
	laps = maxi(int(m.get("laps", 1)), 1)
	half_w = float(m.get("width", 12.0)) * 0.5
	path = RacePath.from_route(m["pts"], bool(m.get("loop", false)), half_w)
	path.start_optimize(70)
	total = path.length * float(laps)
	var n := bot_count()
	_slot_n = n + 1
	_rng.seed = hash(String(m["id"])) + int(G.races_total) * 7919
	_you = _mk(Tx.t("you"), gw.player, null, true)
	racers.append(_you)
	var cars := _pick_cars(n)
	var names := _shuffled(NAMES.duplicate())
	var diff := clampi(G.ai_difficulty, 0, 2)
	var pool := _persona_pool(diff)
	var ps := player_slot_index()
	var base: float = [0.84, 0.92, 0.99][diff]
	var slot := 0
	for i in cars.size():
		if slot == ps:
			slot += 1
		var c: Dictionary = cars[i]
		var car := Vehicle.new()
		car.is_bot = true
		var col: Color = G.PAINTS[(absi(hash(String(c["id"]))) + i * 3) % G.PAINTS.size()]
		car.setup(String(c["model"]), col, c)
		gw.add_child(car)
		var s := slot_transform(slot)
		car.reset_to(s["pos"], s["yaw"])
		var drv := BotDriver.new()
		var pers: Dictionary = BotDriver.PERSONAS[pool[i % pool.size()]]
		drv.setup(car, path, s["idx"], s["lap"], pers, base + _rng.randf_range(-0.02, 0.02), _rng.randi())
		drv.total_laps = laps
		var r := _mk(names[i], car, drv, false)
		r["tag"] = String(pers["title"])
		r["lap"] = s["lap"]
		racers.append(r)
		slot += 1
	var s0 := slot_transform(ps)
	_pidx = s0["idx"]
	_plap = s0["lap"]
	_you["lap"] = _plap
	_ptrk = RacePath.Tracker.new(path, _pidx, _plap)


func _mk(nm: String, car: Vehicle, drv: BotDriver, you: bool) -> Dictionary:
	return {"name": nm, "car": car, "drv": drv, "prog": 0.0, "lat": 0.0, "spd": 0.0, "fin": false, "ft": 0.0, "you": you,
		"lap": 0, "lap_t": 0.0, "best": 0.0, "draft": 0.0, "tag": ""}


func _shuffled(a: Array) -> Array:
	for i in range(a.size() - 1, 0, -1):
		var j := _rng.randi() % (i + 1)
		var tmp = a[i]
		a[i] = a[j]
		a[j] = tmp
	return a


## Indices into BotDriver.PERSONAS (ace, aggressor, defender, clean, rookie, drifter), mixed by difficulty.
func _persona_pool(diff: int) -> Array:
	var base: Array = [[4, 3, 5, 2, 4, 1, 0, 3], [0, 1, 2, 3, 5, 4, 1, 2], [0, 1, 0, 2, 1, 5, 0, 2]][diff]
	return _shuffled(base.duplicate())


func player_slot_index() -> int:
	return clampi(int(float(_slot_n) * 0.55), 1, maxi(_slot_n - 1, 1)) if _slot_n > 1 else 0


## Grid slot k: two columns, rows 8.5 m apart, the pole slot right behind the line.
func slot_transform(k: int) -> Dictionary:
	var row := k / 2
	var col := k % 2
	var back := 6.0 + float(row) * 8.5 + float(col) * 3.0
	var side := -2.4 if col == 0 else 2.4
	var pos: Vector3
	var yaw: float
	var idx := 0
	var lap := 0
	if path.loop:
		idx = path.wi(-int(round(back / RacePath.STEP)))
		lap = -1
		var d := path.dir_at(idx)
		pos = path.pts[idx] + path.sd[idx] * side
		yaw = atan2(d.x, d.z)
	else:
		var d0 := path.dir_at(0)
		pos = path.pts[0] - d0 * back + path.sd[0] * side
		yaw = atan2(d0.x, d0.z)
	pos.y = W.ground_height(pos.x, pos.z, 80.0) + 0.45
	return {"pos": pos, "yaw": yaw, "idx": idx, "lap": lap, "side": side}


func _pick_cars(n: int) -> Array:
	var pl := G.car()
	var pprice := int(pl.get("price", 0))
	var pool: Array = []
	for c in G.cars:
		if String(c["id"]) == String(pl["id"]):
			continue
		if c.has("path") and not ResourceLoader.exists(String(c["path"])):
			continue
		pool.append(c)
	pool.sort_custom(func(a, b): return absi(int(a.get("price", 0)) - pprice) < absi(int(b.get("price", 0)) - pprice))
	var near: Array = _shuffled(pool.slice(0, mini(pool.size(), n + 5)))
	return near.slice(0, mini(n, near.size()))


func lap_of(r: Dictionary) -> int:
	return clampi(int(r["lap"]) + 1, 1, laps)


# ---- per physics tick ------------------------------------------------------------------------------------------------------

func _physics_process(dt: float) -> void:
	if path.busy():
		path.poll()
	if go:
		t += dt
	_update_player()
	for r in racers:
		var car: Vehicle = r["car"]
		var d: BotDriver = r["drv"]
		if d != null:
			r["prog"] = d.progress()
			r["lat"] = d.trk.lat
			d.wet = Vehicle.wetness
		else:
			r["prog"] = float(_you["prog"])
			r["lat"] = _ptrk.lat
		r["spd"] = car.speed
	for r in racers:
		var d: BotDriver = r["drv"]
		if d != null:
			d.update(dt, racers, r, go)
	_laps_and_finish()
	_draft()
	_takedowns(dt)
	_slow_t -= dt
	if _slow_t <= 0.0:
		_slow_t = 0.25
		_slow_tick()
	_cull_t -= dt
	if _cull_t <= 0.0:
		_cull_t = 0.5
		_cull()


func _update_player() -> void:
	if _ptrk == null:
		return
	_ptrk.update(gw.player.global_position, gw.player.linear_velocity)
	_pidx = _ptrk.near()
	_plap = _ptrk.lap
	_you["lap"] = _plap
	if not bool(_you["fin"]):
		_you["prog"] = _ptrk.progress()


func _laps_and_finish() -> void:
	if not go:
		return
	for r in racers:
		var d: BotDriver = r["drv"]
		var lp: int = d.lap if d != null else _plap
		if lp != int(r["lap"]):
			if lp > int(r["lap"]) and lp >= 1:
				var lt: float = t - float(r["lap_t"])
				if float(r["best"]) <= 0.0 or lt < float(r["best"]):
					r["best"] = lt
				r["lap_t"] = t
				if bool(r["you"]):
					event.emit("lap", "%d/%d" % [mini(lp + 1, laps), laps])
			r["lap"] = lp
		if d != null and not bool(r["fin"]) and float(r["prog"]) >= total - 10.0:
			r["fin"] = true
			r["ft"] = t
			d.finished = true


func _draft() -> void:
	for r in racers:
		var best := 0.0
		for o in racers:
			if o == r:
				continue
			var ds: float = float(o["prog"]) - float(r["prog"])
			if ds > 4.0 and ds < 32.0 and absf(float(o["lat"]) - float(r["lat"])) < 2.2:
				best = maxf(best, 1.0 - (ds - 4.0) / 28.0)
		r["draft"] = lerpf(float(r["draft"]), best, 0.12)
		(r["car"] as Vehicle).drag_mult = 1.0 - 0.28 * float(r["draft"])


func _takedowns(dt: float) -> void:
	for k in _td_cd.keys():
		_td_cd[k] = float(_td_cd[k]) - dt
	if not go or bool(_you["fin"]):
		return
	var pl := gw.player
	for r in racers:
		if bool(r["you"]):
			continue
		var d: BotDriver = r["drv"]
		var car: Vehicle = r["car"]
		var rel := car.global_position - pl.global_position
		rel.y = 0.0
		var dist := rel.length()
		if dist > 5.0 or dist < 0.1 or d.is_wrecked():
			continue
		var nrm := rel / dist
		var closing := (pl.linear_velocity - car.linear_velocity).dot(nrm)
		if closing > 3.0:
			d.provoke(0.15 + 0.1 * clampf(closing / 10.0, 0.0, 1.0))
		var key := String(r["name"])
		if closing > 7.5 and pl.speed > 28.0 and float(_td_cd.get(key, 0.0)) <= 0.0:
			_td_cd[key] = 2.0
			takedowns += 1
			d.wreck(2.6)
			d.provoke(0.8)
			car.apply_central_impulse(Vector3.UP * car.mass * 3.5 + nrm * car.mass * 2.5)
			car.apply_torque_impulse(Vector3(_rng.randf_range(-0.4, 0.4), _rng.randf_range(-1.0, 1.0), _rng.randf_range(-0.9, 0.9)) * car.inertia.x * 4.0)
			pl.nitro_gain(0.35)
			event.emit("takedown", String(r["name"]))


func _slow_tick() -> void:
	var pp: float = _you["prog"]
	var diff := clampi(G.ai_difficulty, 0, 2)
	var band: float = [0.10, 0.07, 0.04][diff]
	var boost: float = [0.04, 0.07, 0.11][diff]
	for r in racers:
		var d: BotDriver = r["drv"]
		if d == null:
			continue
		var gap := float(r["prog"]) - pp
		if t < 6.0:
			d.mult = 1.0
		elif gap > 0.0:
			d.mult = 1.0 - band * clampf(gap / 350.0, 0.0, 1.0)
		else:
			d.mult = 1.0 + boost * clampf(-gap / 250.0, 0.0, 1.0)
	# position changes of the player
	var pos := player_position()
	if _prev_pos > 0 and go and not bool(_you["fin"]):
		if pos < _prev_pos:
			event.emit("pos_up", "P%d" % pos)
		elif pos > _prev_pos:
			event.emit("pos_down", "P%d" % pos)
	_prev_pos = pos
	# wrong way
	var pl := gw.player
	if go and not bool(_you["fin"]) and pl.speed > 6.0:
		var dir := path.dir_at(_pidx)
		if pl.flat_forward().dot(dir) < -0.3 and path.dist2d(pl.global_position, _pidx) < 25.0:
			_wrong_t += 0.25
			if _wrong_t > 2.0:
				_wrong_t = -4.0
				event.emit("wrong_way", "")
		else:
			_wrong_t = maxf(_wrong_t - 0.25, 0.0)


func _cull() -> void:
	var cp := gw.cam.global_position if gw.cam else gw.player.global_position
	for r in racers:
		if bool(r["you"]):
			continue
		var car: Vehicle = r["car"]
		car.model.visible = car.global_position.distance_to(cp) < 520.0


# ---- results -----------------------------------------------------------------------------------------------------------------

## Finished racers by finishing time, then the others by distance covered.
func standings() -> Array:
	var a: Array = racers.duplicate()
	a.sort_custom(func(x, y):
		if bool(x["fin"]) != bool(y["fin"]):
			return bool(x["fin"])
		if bool(x["fin"]):
			return float(x["ft"]) < float(y["ft"])
		return float(x["prog"]) > float(y["prog"]))
	return a


func player_position() -> int:
	var s := standings()
	for i in s.size():
		if bool(s[i]["you"]):
			return i + 1
	return s.size()


## The player has crossed the line: his position is 1 + the bots that were already home.
func player_finish() -> int:
	var pos := 1
	for r in racers:
		if not bool(r["you"]) and bool(r["fin"]):
			pos += 1
	_you["fin"] = true
	_you["ft"] = t
	_you["prog"] = total
	var lt := t - float(_you["lap_t"])
	if float(_you["best"]) <= 0.0 or lt < float(_you["best"]):
		_you["best"] = lt
	return pos


## Final table: [{pos, name, you, time, est, gap, best}] — racers still on the road get an estimated time.
func classification() -> Array:
	var rows: Array = []
	for r in racers:
		var tm: float = float(r["ft"])
		var est := false
		if not bool(r["fin"]):
			est = true
			tm = t + maxf(total - float(r["prog"]), 0.0) / maxf(float(r["spd"]), 18.0)
		rows.append({"name": String(r["name"]), "you": bool(r["you"]), "time": tm, "est": est, "best": float(r["best"])})
	rows.sort_custom(func(a, b): return float(a["time"]) < float(b["time"]))
	var win := float(rows[0]["time"]) if rows.size() > 0 else 0.0
	for i in rows.size():
		rows[i]["pos"] = i + 1
		rows[i]["gap"] = float(rows[i]["time"]) - win
	return rows


func gap_ahead_s() -> float:
	var s := standings()
	for i in s.size():
		if bool(s[i]["you"]) and i > 0:
			return maxf(float(s[i - 1]["prog"]) - float(_you["prog"]), 0.0) / maxf(gw.player.speed, 15.0)
	return 0.0


func gap_behind_s() -> float:
	var s := standings()
	for i in s.size():
		if bool(s[i]["you"]) and i < s.size() - 1:
			return maxf(float(_you["prog"]) - float(s[i + 1]["prog"]), 0.0) / maxf(float(s[i + 1]["spd"]), 15.0)
	return 0.0


func _exit_tree() -> void:
	if path and path.busy():
		WorkerThreadPool.wait_for_task_completion(path._task)
	for r in racers:
		if not bool(r["you"]) and is_instance_valid(r["car"]):
			(r["car"] as Node).queue_free()
