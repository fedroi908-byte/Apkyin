extends Node

var gw: GameWorld
var p: Vehicle
var t := 0.0
var kmh := 50.0
var tp := 0
var x0 := -3300.0
var zc := 2900.0
var go := false
var tx := 0.0
var t_hit := -1.0


func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	tp = int(a[0]) if a.size() > 0 else 0
	kmh = float(a[1]) if a.size() > 1 else 50.0
	seed(7)
	G.start_hour = 11.0
	G.mode = "training"
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)
	await get_tree().process_frame
	await get_tree().process_frame
	p = gw.player
	var y := W.runway_y
	tx = x0 + 60.0
	var b := PropGen.Built.new()
	b.recs = PackedFloat32Array([float(tp), tx, y, zc, -PI * 0.5, 0.2, 0.0, 0.0])
	PropGen.pack(b, gw.props.tpl, PackedInt32Array(), 0.0, 0.0)
	var id := gw.props.rb._cell_id(gw.props.rb._cell_of(tx, zc).x, gw.props.rb._cell_of(tx, zc).y)
	gw.props.finish_cell(id, b)
	p.reset_to(Vector3(x0, y + 0.3, zc), PI * 0.5)
	p.linear_velocity = Vector3(kmh / 3.6, 0, 0)
	go = true


func _physics_process(dt: float) -> void:
	if not go:
		return
	t += dt
	if t_hit < 0.0:
		p.in_gas = clampf((kmh - p.kmh()) * 0.15, 0.0, 1.0)
		p.in_brake = clampf((p.kmh() - kmh) * 0.15, 0.0, 1.0)
	else:
		p.in_gas = 0.0
		p.in_brake = 0.0
	p.in_steer = 0.0
	var gap := tx - p.global_position.x
	if t_hit < 0.0 and t > 0.5 and int(t * 60.0) % 30 == 0:
		print('FT pre kmh=', snapped(p.kmh(), 0.1), ' gap=', snapped(gap, 0.1))
	if gap < 2.4 and t_hit < 0.0:
		t_hit = t
	if t_hit > 0.0 and t < t_hit + 3.0 and (t < t_hit + 0.4 or int(t * 60.0) % 6 == 0):
		var s := "FT t=%.2f kmh=%.1f gap=%.2f dmg=%.2f uk=%.2f dn=%d" % [t - t_hit, p.kmh(), gap, p.damage, gw.props.under_k, gw.props.dn]
		for a in gw.props.actors:
			var up: float = (a.rot * Vector3.UP).y
			s += " | A dx=%.2f dz=%.2f y=%.2f vx=%.1f w=%.1f tilt=%d torn=%s" % [a.pos.x - p.global_position.x, a.pos.z - p.global_position.z, a.pos.y - W.runway_y, a.vel.x, a.w.length(), int(rad_to_deg(acos(clampf(up, -1.0, 1.0)))), a.torn]
		print(s)
	if t > 9.0:
		print("FT end kmh=", snapped(p.kmh(), 0.1), " dmg=", snapped(p.damage, 0.01))
		get_tree().quit()
