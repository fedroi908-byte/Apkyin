class_name Q
extends RefCounted
## Central graphics-quality table. Everything that scales with settings reads from here.
## Levels: 0 Low, 1 Medium, 2 High, 3 Ultra.  LOW/MEDIUM are tuned for mid-range phones (no real-time sun shadows on LOW,
## cheap shaders, low render scale); HIGH/ULTRA add shadows, MSAA, soft filtering and heavier shader paths.

const NAMES := ["LOW", "MEDIUM", "HIGH", "ULTRA"]

const TABLE := [
	{ # LOW: must run smoothly on weak/old phones
		"msaa": Viewport.MSAA_DISABLED, "shadows": false, "shadow_size": 1024, "shadow_splits": 1, "shadow_dist": 60.0, "shadow_filter": 0,
		"shadow_blur": 0.0, "tree_dist": 140.0, "bld_dist": 420.0, "prop_dist": 100.0, "traffic": 4,
		"ped": 0, "glow": false, "terrain_levels": 4, "road_cells": 2, "road_dist": 1500.0, "side_dist": 260.0, "terrain_grid": 64, "terrain_cell": 4.0, "clouds": false, "rain_particles": 250,
		"car_detail": 0, "reflections": false, "grass": 0, "fps_cap": 30, "aa_fxaa": false, "scale": 0.6, "budget_h": 620.0, "phys_hz": 60, "car_shadow": false,
		"aniso": 0, "lod": 10.0, "shader": 0, "sky_steps": 0, "bots": 3,
	},
	{ # MEDIUM
		"msaa": Viewport.MSAA_DISABLED, "shadows": true, "shadow_size": 1024, "shadow_splits": 1, "shadow_dist": 70.0, "shadow_filter": 0,
		"shadow_blur": 0.0, "tree_dist": 240.0, "bld_dist": 650.0, "prop_dist": 160.0, "traffic": 8,
		"ped": 0, "glow": false, "terrain_levels": 5, "road_cells": 3, "road_dist": 2200.0, "side_dist": 450.0, "terrain_grid": 80, "terrain_cell": 3.5, "clouds": true, "rain_particles": 700,
		"car_detail": 1, "reflections": false, "grass": 0, "fps_cap": 60, "aa_fxaa": true, "scale": 0.75, "budget_h": 800.0, "phys_hz": 60, "car_shadow": true,
		"aniso": 1, "lod": 5.0, "shader": 1, "sky_steps": 2, "bots": 4,
	},
	{ # HIGH
		"msaa": Viewport.MSAA_2X, "shadows": true, "shadow_size": 2048, "shadow_splits": 2, "shadow_dist": 140.0, "shadow_filter": 1,
		"shadow_blur": 0.5, "tree_dist": 380.0, "bld_dist": 1000.0, "prop_dist": 260.0, "traffic": 14,
		"ped": 12, "glow": true, "terrain_levels": 6, "road_cells": 4, "road_dist": 3200.0, "side_dist": 800.0, "terrain_grid": 96, "terrain_cell": 3.0, "clouds": true, "rain_particles": 1500,
		"car_detail": 2, "reflections": true, "grass": 1, "fps_cap": 60, "aa_fxaa": false, "scale": 0.9, "budget_h": 1080.0, "phys_hz": 60, "car_shadow": true,
		"aniso": 2, "lod": 2.5, "shader": 2, "sky_steps": 4, "bots": 6,
	},
	{ # ULTRA ("extra"): flagship phones only
		"msaa": Viewport.MSAA_4X, "shadows": true, "shadow_size": 4096, "shadow_splits": 3, "shadow_dist": 260.0, "shadow_filter": 2,
		"shadow_blur": 1.0, "tree_dist": 600.0, "bld_dist": 1600.0, "prop_dist": 400.0, "traffic": 24,
		"ped": 30, "glow": true, "terrain_levels": 7, "road_cells": 4, "road_dist": 3200.0, "side_dist": 900.0, "terrain_grid": 96, "terrain_cell": 3.0, "clouds": true, "rain_particles": 3500,
		"car_detail": 3, "reflections": true, "grass": 2, "fps_cap": 60, "aa_fxaa": false, "scale": 1.0, "budget_h": 1500.0, "phys_hz": 60, "car_shadow": true,
		"aniso": 3, "lod": 1.0, "shader": 3, "sky_steps": 6, "bots": 8,
	},
]


static var _eff: Dictionary = {}
static var _eff_key := ""


## Level actually in use: the server can force a level or cap the player's choice (perf.force_quality / perf.max_quality).
static func level() -> int:
	var top := TABLE.size() - 1
	var f := int(R.cfg("perf.force_quality", -1))
	if f >= 0:
		return clampi(f, 0, top)
	return mini(clampi(G.quality, 0, top), clampi(int(R.cfg("perf.max_quality", top)), 0, top))


## The settings table of the effective level with the server's performance / density tunables folded in (cached).
static func cfg() -> Dictionary:
	var lv := level()
	var key := "%d|%d" % [lv, R.cfg_rev]
	if key != _eff_key:
		_eff = _derive(lv)
		_eff_key = key
	return _eff


static func _derive(lv: int) -> Dictionary:
	var c: Dictionary = (TABLE[lv] as Dictionary).duplicate()
	var dd := float(R.cfg("perf.draw_dist_mult", 1.0))
	if dd != 1.0:
		for k in ["tree_dist", "bld_dist", "prop_dist", "shadow_dist"]:
			c[k] = float(c[k]) * dd
	if not bool(R.cfg("perf.shadows", true)):
		c["shadows"] = false
		c["car_shadow"] = false
	c["scale"] = minf(float(c["scale"]), float(R.cfg("perf.render_scale_max", 1.0)))
	var fc := int(R.cfg("perf.fps_cap", 0))
	c["fps_forced"] = fc > 0
	if fc > 0:
		c["fps_cap"] = fc
	var hz := int(R.cfg("perf.phys_hz", 0))
	if hz > 0:
		c["phys_hz"] = hz
	var tr := int(roundf(float(c["traffic"]) * float(R.cfg("game.traffic_mult", 1.0))))
	var mt := int(R.cfg("perf.max_traffic", -1))
	if mt >= 0:
		tr = mini(tr, mt)
	c["traffic"] = tr
	c["ped"] = int(roundf(float(c["ped"]) * float(R.cfg("game.ped_mult", 1.0))))
	return c


## Render scale for the current level, additionally capped so the 3D resolution never exceeds the level's pixel-height budget.
static func base_scale() -> float:
	var sh := float(maxi(DisplayServer.window_get_size().y, 1))
	return clampf(minf(float(cfg()["scale"]), float(cfg()["budget_h"]) / sh), 0.35, 1.0)


static func get_v(key: String) -> Variant:
	return cfg()[key]


## Push the current level into every global setting (viewport, shadow atlas, shader globals).
static func apply(vp: Viewport) -> void:
	var c := cfg()
	if vp:
		vp.msaa_3d = c["msaa"]
		vp.scaling_3d_scale = G.res_scale if G.dyn_res else base_scale()
		vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
		vp.use_taa = false
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if c["aa_fxaa"] else Viewport.SCREEN_SPACE_AA_DISABLED
		vp.set("anisotropic_filtering_level", int(c["aniso"]))
		vp.set("mesh_lod_threshold", float(c["lod"]))
	RenderingServer.directional_shadow_atlas_set_size(c["shadow_size"], true)
	var sf: int = [RenderingServer.SHADOW_QUALITY_HARD, RenderingServer.SHADOW_QUALITY_SOFT_LOW, RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM, RenderingServer.SHADOW_QUALITY_SOFT_HIGH][clampi(int(c["shadow_filter"]), 0, 3)]
	RenderingServer.directional_soft_shadow_filter_set_quality(sf)
	RenderingServer.global_shader_parameter_set("quality", float(level()))
	Engine.physics_ticks_per_second = int(c["phys_hz"])
	Engine.max_physics_steps_per_frame = 2          # never let physics catch-up spiral on slow phones
	Engine.max_fps = int(c["fps_cap"]) if (G.fps_limit_enabled or bool(c["fps_forced"])) else 0
