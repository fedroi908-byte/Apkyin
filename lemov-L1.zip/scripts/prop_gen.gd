class_name PropGen
extends RefCounted

const T_LAMP := 0
const T_SIGNAL := 1
const T_BIN := 2
const T_HYDRANT := 3
const T_BOLLARD := 4
const T_SIGN := 5
const T_BENCH := 6
const T_MAILBOX := 7
const T_DUMPSTER := 8
const T_CONE := 9
const NT := 10

const H := [7.0, 5.6, 0.85, 0.6, 0.9, 2.5, 0.9, 1.1, 1.1, 0.7]
const MASS := [320.0, 450.0, 22.0, 200.0, 90.0, 40.0, 70.0, 85.0, 320.0, 3.0]
const BREAK_N := [70000.0, 80000.0, 0.0, 25000.0, 1.0e9, 8000.0, 30000.0, 45000.0, 0.0, 0.0]
const DIM := [Vector3(0.3, 7.0, 0.3), Vector3(0.3, 5.6, 0.3), Vector3(0.6, 0.85, 0.6), Vector3(0.36, 0.6, 0.36), Vector3(0.16, 0.9, 0.16), Vector3(0.12, 2.5, 0.12), Vector3(1.6, 0.9, 0.5), Vector3(0.5, 1.1, 0.45), Vector3(2.0, 1.1, 1.1), Vector3(0.4, 0.7, 0.4)]
const COM_Y := [2.8, 2.4, 0.42, 0.3, 0.45, 1.1, 0.4, 0.5, 0.5, 0.25]
const PR := [0.12, 0.13, 0.03, 0.02, 0.08, 0.06, 0.02, 0.02, 0.02, 0.02]
const REST := [0.15, 0.15, 0.35, 0.2, 0.15, 0.2, 0.2, 0.2, 0.15, 0.4]
const TEAR_N := [175000.0, 200000.0, 0.0, 25000.0, 1.0e9, 12000.0, 60000.0, 90000.0, 0.0, 0.0]
const KDMG := [0.7, 0.8, 0.12, 0.5, 1.0, 0.4, 0.4, 0.45, 0.6, 0.03]
const CIRC := [
	[[0.0, 0.0, 0.16]], [[0.0, 0.0, 0.18]], [[0.0, 0.0, 0.31]], [[0.0, 0.0, 0.18]], [[0.0, 0.0, 0.09]], [[0.0, 0.0, 0.07]],
	[[-0.55, 0.0, 0.3], [0.0, 0.0, 0.3], [0.55, 0.0, 0.3]], [[0.0, 0.0, 0.3]], [[-0.5, 0.0, 0.58], [0.0, 0.0, 0.58], [0.5, 0.0, 0.58]], [[0.0, 0.0, 0.2]]]


class Built:
	var recs := PackedFloat32Array()
	var alive := PackedByteArray()
	var hash := {}
	var subs := []


static func hash01(a: int, b: int, c: int) -> float:
	var h := (a * 73856093) ^ (b * 19349663) ^ (c * 83492791)
	h = (h ^ (h >> 13)) * 1274126177
	h = h ^ (h >> 16)
	return float(h & 0xffff) / 65535.0


static func bucket(x: float, z: float) -> int:
	return (int(floor(x / 8.0)) + 2048) * 4096 + int(floor(z / 8.0)) + 2048


static func sub_of(x: float, z: float, x0: float, z0: float) -> int:
	return clampi(int((x - x0) / 200.0), 0, 2) * 3 + clampi(int((z - z0) / 200.0), 0, 2)


static func samples(t: int) -> PackedVector3Array:
	var p := PackedVector3Array()
	match t:
		T_LAMP:
			for y in [0.1, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 6.9]:
				p.append(Vector3(0, y, 0))
			p.append(Vector3(0, 6.9, 2.2))
		T_SIGNAL:
			for y in [0.1, 1.0, 2.0, 3.0, 4.0, 5.0, 5.4]:
				p.append(Vector3(0, y, 0))
			p.append(Vector3(-3.4, 5.2, 0))
		T_SIGN:
			for y in [0.1, 0.9, 1.7, 2.4]:
				p.append(Vector3(0, y, 0))
		T_BIN:
			for y in [0.0, 0.43, 0.85]:
				for a in [Vector2(0.3, 0), Vector2(-0.3, 0), Vector2(0, 0.3), Vector2(0, -0.3)]:
					p.append(Vector3(a.x, y, a.y))
		T_HYDRANT:
			for y in [0.0, 0.3, 0.6]:
				for a in [Vector2(0.17, 0), Vector2(-0.17, 0), Vector2(0, 0.17), Vector2(0, -0.17)]:
					p.append(Vector3(a.x, y, a.y))
		T_BOLLARD:
			for y in [0.05, 0.45, 0.85]:
				p.append(Vector3(0, y, 0))
		T_CONE:
			for a in [Vector2(0.2, 0.2), Vector2(-0.2, 0.2), Vector2(0.2, -0.2), Vector2(-0.2, -0.2)]:
				p.append(Vector3(a.x, 0.0, a.y))
			p.append(Vector3(0, 0.7, 0))
			p.append(Vector3(0.1, 0.35, 0))
			p.append(Vector3(-0.1, 0.35, 0))
		_:
			var d: Vector3 = DIM[t]
			for y in [0.0, d.y]:
				for sx in [-0.5, 0.5]:
					for sz in [-0.5, 0.5]:
						p.append(Vector3(sx * d.x, y, sz * d.z))
			for y in [0.0, d.y * 0.5, d.y]:
				p.append(Vector3(d.x * 0.5, y, 0))
				p.append(Vector3(-d.x * 0.5, y, 0))
				p.append(Vector3(0, y, d.z * 0.5))
				p.append(Vector3(0, y, -d.z * 0.5))
	return p


static func _new() -> MeshUtil:
	var m := MeshUtil.new()
	m.with_uv2 = true
	return m


static func _tag(m: MeshUtil, from: int, ux: float, code: float, metal: float) -> void:
	for i in range(from, m.v.size()):
		m.uv[i] = Vector2(ux, code)
		m.uv2[i] = Vector2(metal, 0.0)


static func _box(m: MeshUtil, c: Vector3, s: Vector3, col: Color, metal: float = 0.0, code: float = 0.0, bottom: bool = false) -> void:
	var from := m.v.size()
	m.box(c, s, 0.0, col, 1.0, true, bottom)
	_tag(m, from, 0.0, code, metal)


static func _cyl(m: MeshUtil, y0: float, y1: float, r0: float, r1: float, seg: int, col: Color, metal: float = 0.0, ox: float = 0.0, oz: float = 0.0) -> void:
	var base := m.v.size()
	var sl := (r0 - r1) / maxf(y1 - y0, 0.001)
	for i in seg + 1:
		var a := TAU * float(i) / float(seg)
		var nrm := Vector3(cos(a), sl, sin(a)).normalized()
		m.add_vertex(Vector3(ox + cos(a) * r0, y0, oz + sin(a) * r0), nrm, Vector2.ZERO, col)
		m.add_vertex(Vector3(ox + cos(a) * r1, y1, oz + sin(a) * r1), nrm, Vector2.ZERO, col)
	for i in seg:
		var k := base + i * 2
		var am := TAU * (float(i) + 0.5) / float(seg)
		m.quad_auto(k, k + 2, k + 3, k + 1, Vector3(cos(am), 0.0, sin(am)))
	if r1 > 0.0:
		var c0 := m.add_vertex(Vector3(ox, y1, oz), Vector3.UP, Vector2.ZERO, col)
		for i in seg:
			var a0 := TAU * float(i) / float(seg)
			var a1 := TAU * float(i + 1) / float(seg)
			var p0 := m.add_vertex(Vector3(ox + cos(a0) * r1, y1, oz + sin(a0) * r1), Vector3.UP, Vector2.ZERO, col)
			var p1 := m.add_vertex(Vector3(ox + cos(a1) * r1, y1, oz + sin(a1) * r1), Vector3.UP, Vector2.ZERO, col)
			m.tri_auto(c0, p0, p1, Vector3.UP)
	_tag(m, base, 0.0, 0.0, metal)


static func _oct(m: MeshUtil, cy: float, r: float, col: Color, z: float, nz: float) -> void:
	var from := m.v.size()
	var c0 := m.add_vertex(Vector3(0, cy, z), Vector3(0, 0, nz), Vector2.ZERO, col)
	for i in 8:
		var a0 := TAU * (float(i) + 0.5) / 8.0
		var a1 := TAU * (float(i) + 1.5) / 8.0
		var p0 := m.add_vertex(Vector3(sin(a0) * r, cy + cos(a0) * r, z), Vector3(0, 0, nz), Vector2.ZERO, col)
		var p1 := m.add_vertex(Vector3(sin(a1) * r, cy + cos(a1) * r, z), Vector3(0, 0, nz), Vector2.ZERO, col)
		m.tri_auto(c0, p0, p1, Vector3(0, 0, nz))
	_tag(m, from, 0.0, 0.0, 0.3)


static func _glow(g: MeshUtil, c: Vector3, size: float, col: Color, code: float) -> void:
	var base := g.v.size()
	for i in 4:
		g.add_vertex(c, Vector3.UP, Vector2(0.0, code), col, Vector2(float(i), size))
	g.quad_auto(base, base + 1, base + 2, base + 3, Vector3.UP)


static func _pool(g: MeshUtil, c: Vector3, half: float, col: Color) -> void:
	var cs := [Vector2(-1, -1), Vector2(1, -1), Vector2(1, 1), Vector2(-1, 1)]
	var base := g.v.size()
	for i in 4:
		var q: Vector2 = cs[i]
		g.add_vertex(Vector3(c.x + q.x * half, c.y, c.z + q.y * half), Vector3.UP, Vector2(0.0, 0.0), col, Vector2(float(i), 0.0))
	g.quad_auto(base, base + 1, base + 2, base + 3, Vector3.UP)


static func _head(m: MeshUtil, g: MeshUtil, x: float, y: float, z: float) -> void:
	var dark := Color(0.08, 0.08, 0.09)
	_box(m, Vector3(x, y, z), Vector3(0.38, 1.1, 0.3), dark, 0.2)
	_box(m, Vector3(x, y, z - 0.18), Vector3(0.78, 1.45, 0.04), dark, 0.2)
	var cols := [Color(1.0, 0.1, 0.06), Color(1.0, 0.6, 0.04), Color(0.08, 1.0, 0.3)]
	for cl in 3:
		var ly := y + 0.34 - 0.34 * float(cl)
		_box(m, Vector3(x, ly, z + 0.16), Vector3(0.24, 0.24, 0.03), Color(0.3, 0.3, 0.3), 0.0, 10.0 + float(cl))
		_box(m, Vector3(x, ly + 0.15, z + 0.2), Vector3(0.3, 0.03, 0.12), dark, 0.2)
		_glow(g, Vector3(x, ly, z + 0.22), 0.5, cols[cl], 10.0 + float(cl))


static func templates() -> Array:
	var out := []
	var steel := Color(0.2, 0.22, 0.23)
	for t in NT:
		var m := _new()
		var g := _new()
		match t:
			T_LAMP:
				_box(m, Vector3(0, 0.05, 0), Vector3(0.34, 0.7, 0.34), Color(0.55, 0.55, 0.53))
				_cyl(m, 0.4, 6.7, 0.11, 0.065, 8, steel, 0.5)
				_box(m, Vector3(0, 6.85, 1.0), Vector3(0.07, 0.07, 2.1), steel, 0.5)
				_box(m, Vector3(0, 6.88, 2.0), Vector3(0.36, 0.12, 0.8), Color(0.3, 0.31, 0.32), 0.4)
				_box(m, Vector3(0, 6.81, 2.0), Vector3(0.3, 0.02, 0.66), Color(0.9, 0.85, 0.7), 0.0, 1.0, true)
				_glow(g, Vector3(0, 6.76, 2.0), 1.3, Color(1.0, 0.78, 0.45), 1.0)
				_pool(g, Vector3(0, 0.03, 2.0), 7.5, Color(1.0, 0.74, 0.42))
			T_SIGNAL:
				_cyl(m, 0.0, 5.3, 0.12, 0.085, 8, steel, 0.4)
				_box(m, Vector3(-1.7, 5.15, 0), Vector3(3.4, 0.12, 0.12), steel, 0.4)
				_head(m, g, -3.0, 4.55, 0.0)
				_head(m, g, 0.0, 3.3, 0.22)
			T_BIN:
				_cyl(m, 0.0, 0.8, 0.27, 0.3, 10, Color(0.12, 0.32, 0.22))
				_cyl(m, 0.8, 0.86, 0.32, 0.32, 10, Color(0.08, 0.08, 0.08))
			T_HYDRANT:
				var red := Color(0.75, 0.1, 0.08)
				_cyl(m, 0.0, 0.06, 0.17, 0.17, 8, red * 0.7, 0.3)
				_cyl(m, 0.06, 0.5, 0.11, 0.11, 8, red, 0.3)
				_cyl(m, 0.5, 0.62, 0.11, 0.05, 8, red, 0.3)
				_box(m, Vector3(0.15, 0.3, 0), Vector3(0.12, 0.08, 0.08), red, 0.3)
				_box(m, Vector3(-0.15, 0.3, 0), Vector3(0.12, 0.08, 0.08), red, 0.3)
				_box(m, Vector3(0, 0.28, 0.14), Vector3(0.1, 0.1, 0.12), Color(0.8, 0.65, 0.15), 0.5)
			T_BOLLARD:
				_cyl(m, 0.0, 0.85, 0.075, 0.075, 8, Color(0.35, 0.35, 0.37), 0.6)
				_cyl(m, 0.65, 0.73, 0.08, 0.08, 8, Color(0.9, 0.8, 0.1), 0.3)
			T_SIGN:
				_cyl(m, 0.0, 2.3, 0.035, 0.035, 6, Color(0.5, 0.5, 0.52), 0.6)
				_oct(m, 2.1, 0.3, Color(0.78, 0.07, 0.06), 0.045, 1.0)
				_oct(m, 2.1, 0.26, Color(0.9, 0.9, 0.88), 0.047, 1.0)
				_oct(m, 2.1, 0.22, Color(0.78, 0.07, 0.06), 0.049, 1.0)
				_oct(m, 2.1, 0.3, Color(0.45, 0.45, 0.47), 0.04, -1.0)
			T_BENCH:
				var wood := Color(0.45, 0.3, 0.15)
				_box(m, Vector3(0, 0.45, 0), Vector3(1.6, 0.06, 0.45), wood)
				_box(m, Vector3(0, 0.78, -0.2), Vector3(1.6, 0.34, 0.05), wood)
				_box(m, Vector3(0.7, 0.22, 0), Vector3(0.06, 0.44, 0.4), steel, 0.5)
				_box(m, Vector3(-0.7, 0.22, 0), Vector3(0.06, 0.44, 0.4), steel, 0.5)
			T_MAILBOX:
				_box(m, Vector3(0, 0.05, 0), Vector3(0.4, 0.1, 0.35), steel, 0.4)
				_box(m, Vector3(0, 0.55, 0), Vector3(0.5, 0.9, 0.45), Color(0.1, 0.2, 0.6), 0.3)
				_box(m, Vector3(0, 1.04, 0), Vector3(0.52, 0.12, 0.47), Color(0.06, 0.12, 0.4), 0.3)
			T_DUMPSTER:
				_box(m, Vector3(0, 0.55, 0), Vector3(2.0, 1.0, 1.1), Color(0.1, 0.32, 0.18), 0.2)
				_box(m, Vector3(0, 1.08, 0), Vector3(2.04, 0.08, 1.14), Color(0.05, 0.12, 0.08), 0.2)
				_box(m, Vector3(0.9, 0.1, 0.45), Vector3(0.12, 0.2, 0.12), steel)
				_box(m, Vector3(-0.9, 0.1, 0.45), Vector3(0.12, 0.2, 0.12), steel)
			T_CONE:
				_box(m, Vector3(0, 0.015, 0), Vector3(0.4, 0.03, 0.4), Color(0.1, 0.1, 0.1))
				_cyl(m, 0.03, 0.7, 0.18, 0.03, 8, Color(0.95, 0.38, 0.05))
				_cyl(m, 0.3, 0.4, 0.121, 0.099, 8, Color(0.95, 0.95, 0.92))
		out.append([m, g])
	return out


static func stamp(dst: MeshUtil, src: MeshUtil, org: Vector3, yaw: float, tint: float, ux: float, ax3: float, v2: float, glow: bool) -> void:
	var b := Basis(Vector3.UP, yaw)
	var o := dst.v.size()
	for i in src.v.size():
		dst.v.append(org + b * src.v[i])
		dst.n.append(b * src.n[i])
		var cc := src.col[i]
		dst.col.append(Color(cc.r * tint, cc.g * tint, cc.b * tint, cc.a))
		var uu := src.uv[i]
		var cd := uu.y + (ax3 if uu.y > 9.5 else 0.0)
		dst.uv.append(Vector2(ux if (glow or uu.y > 0.5) else uu.x, cd))
		var u2 := src.uv2[i]
		dst.uv2.append(u2 if glow else Vector2(u2.x, v2))
	for j in src.idx:
		dst.idx.append(j + o)


static func mesh_sub(recs: PackedFloat32Array, alive: PackedByteArray, tpl: Array, sub: int, x0: float, z0: float) -> Array:
	var s := _new()
	var g := _new()
	for i in recs.size() >> 3:
		if alive[i] == 0:
			continue
		var o := i * 8
		if sub_of(recs[o + 1], recs[o + 3], x0, z0) != sub:
			continue
		var t := int(recs[o])
		var org := Vector3(recs[o + 1], recs[o + 2], recs[o + 3])
		var yaw := recs[o + 4]
		var tint := 0.88 + 0.2 * hash01(i, t, 5)
		var ux := 0.0
		var ax3 := 0.0
		var v2 := 0.0
		if t == T_LAMP:
			ux = recs[o + 5]
			v2 = recs[o + 6]
		elif t == T_SIGNAL:
			ux = recs[o + 5]
			ax3 = 3.0 * recs[o + 6]
		stamp(s, tpl[t][0], org, yaw, tint, ux, ax3, v2, false)
		if not (t == T_LAMP and v2 > 1.5):
			stamp(g, tpl[t][1], org, yaw, 1.0, ux, ax3, 0.0, true)
	return [s, g]


static func actor_mesh(tpl: Array, t: int, mat: Material) -> ArrayMesh:
	var s := _new()
	stamp(s, tpl[t][0], Vector3.ZERO, 0.0, 1.0, 9.0 if t == T_LAMP else -1.0, 0.0, 2.0, false)
	return s.build(mat)


static func _add(o: Built, t: int, x: float, y: float, z: float, yaw: float, a: float, b: float, c: float) -> void:
	o.recs.append_array(PackedFloat32Array([float(t), x, y, z, yaw, a, b, c]))


static func _near_j(nj: PackedFloat32Array, x: float, z: float, extra: float) -> bool:
	for i in range(0, nj.size(), 3):
		var d := Vector2(x - nj[i], z - nj[i + 1]).length()
		if d < nj[i + 2] + extra:
			return true
	return false


static func generate(rb: RoadBuilder, id: int, tpl: Array, dead: PackedInt32Array) -> Built:
	var o := Built.new()
	var cx := id / 1000
	var cz := id % 1000
	var x0 := float(cx) * RoadBuilder.CELL - W.half
	var z0 := float(cz) * RoadBuilder.CELL - W.half
	var sx := rb._local_index(id)
	var runs: Array = rb.cell_runs.get(id, [])
	var city := false
	for run in runs:
		var c: String = W.roads[run[0]]["cls"]
		if c == "street" or c == "avenue":
			city = true
			break
	var nj := PackedFloat32Array()
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			for j in rb.cell_junctions.get(rb._cell_id(cx + dx, cz + dz), []):
				nj.append_array(PackedFloat32Array([j[0], j[1], (8.5 if j[3] > 0.5 else 5.5) + 3.0]))
	for run in runs:
		_road(rb, sx, run, city, nj, o)
	for j in rb.cell_junctions.get(id, []):
		_junction(rb, sx, j, o)
	pack(o, tpl, dead, x0, z0)
	return o


static func pack(o: Built, tpl: Array, dead: PackedInt32Array, x0: float, z0: float) -> void:
	var n := o.recs.size() >> 3
	o.alive.resize(n)
	o.alive.fill(1)
	for d in dead:
		if d < n:
			o.alive[d] = 0
	for i in n:
		var b := i * 8
		var key := bucket(o.recs[b + 1], o.recs[b + 3])
		if o.hash.has(key):
			o.hash[key].append(i)
		else:
			o.hash[key] = PackedInt32Array([i])
	for s in 9:
		o.subs.append(mesh_sub(o.recs, o.alive, tpl, s, x0, z0))


static func _road(rb: RoadBuilder, sx: RoadBuilder.SegIdx, run: Array, city: bool, nj: PackedFloat32Array, o: Built) -> void:
	var ri: int = run[0]
	var r: Dictionary = W.roads[ri]
	var cls: String = r["cls"]
	var side_ok := cls == "street" or cls == "avenue"
	if not side_ok and not (cls == "main" and city):
		return
	var pts: PackedVector3Array = r["pts"]
	var br: PackedByteArray = r["bridge"]
	var sa: PackedFloat32Array = rb.cum_s[ri]
	var hw := float(r["width"]) * 0.5
	var lift: float = RoadBuilder.LIFT.get(cls, 0.0)
	var g := 36.0 if cls == "street" else (21.0 if cls == "avenue" else 27.0)
	for i in range(run[1], run[2] + 1):
		if br[i] != 0:
			continue
		var s0 := sa[i]
		var s1 := sa[i + 1]
		if s1 - s0 < 0.05:
			continue
		var p := pts[i]
		var q := pts[i + 1]
		var t0 := rb._tangent_at(pts, i)
		var t1 := rb._tangent_at(pts, i + 1)
		for n in range(int(floor(s0 / g)) + 1, int(floor(s1 / g)) + 1):
			_station(rb, sx, ri, cls, n, (float(n) * g - s0) / (s1 - s0), p, q, t0, t1, hw, lift, nj, o, 0)
		if side_ok:
			for n in range(int(floor(s0 / 14.0)) + 1, int(floor(s1 / 14.0)) + 1):
				_station(rb, sx, ri, cls, n, (float(n) * 14.0 - s0) / (s1 - s0), p, q, t0, t1, hw, lift, nj, o, 1)


static func _station(rb: RoadBuilder, sx: RoadBuilder.SegIdx, ri: int, cls: String, n: int, f: float, p: Vector3, q: Vector3, t0: Vector3, t1: Vector3, hw: float, lift: float, nj: PackedFloat32Array, o: Built, kind: int) -> void:
	var side_ok := cls == "street" or cls == "avenue"
	var sides := [n & 1] if kind == 0 else [0, 1]
	for sd in sides:
		var e: Array = rb._sw_edges(p, q, t0, t1, f, sd, hw, 1.7, lift)
		if side_ok and not rb._sw_valid(sx, e, ri):
			continue
		var inner: Vector3 = e[0]
		var outv: Vector3 = e[3]
		var yaw := atan2(-outv.x, -outv.z)
		if kind == 0:
			var off := 0.55 if side_ok else 1.4
			var px := inner.x + outv.x * off
			var pz := inner.z + outv.z * off
			if _near_j(nj, px, pz, 2.0):
				continue
			var py := inner.y + 0.16 if side_ok else W.terrain_height(px, pz)
			var hh := hash01(ri, n, 93)
			_add(o, T_LAMP, px, py, pz, yaw, 0.04 + 0.3 * hash01(ri, n, 91), 1.0 if hh < 0.04 else (2.0 if hh < 0.07 else 0.0), 0.0)
			continue
		var h1 := hash01(ri, n, sd * 7 + 1)
		var t := -1
		var off2 := 1.0
		if h1 < 0.09:
			t = T_BIN
			off2 = 1.25
		elif h1 < 0.115:
			t = T_HYDRANT
			off2 = 0.5
		elif h1 < 0.14 and cls == "avenue":
			t = T_BENCH
			off2 = 1.3
		elif h1 < 0.165:
			t = T_MAILBOX
			off2 = 0.75
		elif h1 < 0.18 and cls == "street":
			t = T_DUMPSTER
			off2 = 1.05
		elif h1 < 0.2:
			t = T_BOLLARD
			off2 = 0.35
		elif h1 > 0.992 and cls == "avenue":
			t = T_CONE
			off2 = -1.0
		if t < 0:
			continue
		var qx := inner.x + outv.x * off2
		var qz := inner.z + outv.z * off2
		if _near_j(nj, qx, qz, 6.0):
			continue
		var qy := inner.y + (0.16 if off2 > 0.0 else 0.0)
		var tg := Vector3(outv.z, 0.0, -outv.x)
		if t == T_BOLLARD:
			for k in 3:
				_add(o, t, qx + tg.x * 1.4 * float(k - 1), qy, qz + tg.z * 1.4 * float(k - 1), yaw, 0.0, 0.0, 0.0)
		elif t == T_CONE:
			for k in 5:
				_add(o, t, qx + tg.x * 1.6 * float(k - 2), qy, qz + tg.z * 1.6 * float(k - 2), yaw, 0.0, 0.0, 0.0)
		else:
			_add(o, t, qx, qy, qz, yaw, 0.0, 0.0, 0.0)


static func _arms(rb: RoadBuilder, sx: RoadBuilder.SegIdx, cx: float, cz: float) -> Array:
	var seen := {}
	var arms := []
	for gx in range(int(floor((cx - 14.0) / 32.0)), int(floor((cx + 14.0) / 32.0)) + 1):
		for gz in range(int(floor((cz - 14.0) / 32.0)), int(floor((cz + 14.0) / 32.0)) + 1):
			var key := Vector2i(gx, gz)
			if not sx.g.has(key):
				continue
			for k in sx.g[key]:
				var ri := sx.ri[k]
				if seen.has(ri):
					continue
				var t := clampf(((cx - sx.ax[k]) * sx.abx[k] + (cz - sx.az[k]) * sx.abz[k]) / (sx.ln[k] * sx.ln[k]), 0.0, 1.0)
				var dx := cx - (sx.ax[k] + sx.abx[k] * t)
				var dz := cz - (sx.az[k] + sx.abz[k] * t)
				var lim := sx.hw[k] + 3.0
				if dx * dx + dz * dz > lim * lim:
					continue
				seen[ri] = true
				var r: Dictionary = W.roads[ri]
				var pts: PackedVector3Array = r["pts"]
				var i0: int = sx.seg[k]
				for dirn in [-1, 1]:
					var idx := i0 if dirn < 0 else i0 + 1
					var found := false
					var cnt := 0
					while idx >= 0 and idx < pts.size() and cnt < 40:
						if Vector2(pts[idx].x - cx, pts[idx].z - cz).length() >= 16.0:
							found = true
							break
						idx += dirn
						cnt += 1
					if not found:
						continue
					var pv := pts[idx]
					var dv := Vector2(pv.x - cx, pv.z - cz).normalized()
					var dup := false
					for a in arms:
						if (a[0] as Vector2).dot(dv) > 0.9:
							dup = true
							break
					if not dup:
						arms.append([dv, float(r["width"]) * 0.5, String(r["cls"]), pv.y])
	return arms


static func _junction(rb: RoadBuilder, sx: RoadBuilder.SegIdx, j: Array, o: Built) -> void:
	var cx: float = j[0]
	var cz: float = j[1]
	var ang: float = j[2]
	var big: bool = j[3] > 0.5
	var k := int(j[4])
	var jh := (8.5 if big else 5.5) + 3.0
	var arms := _arms(rb, sx, cx, cz)
	if arms.size() < 3:
		return
	for a in arms:
		var d: Vector2 = a[0]
		var half: float = a[1]
		var cls: String = a[2]
		var sw := cls == "street" or cls == "avenue"
		var pp := Vector2(cx, cz) + d * (jh + 0.6) + Vector2(d.y, -d.x) * (half + 0.9)
		var y: float = float(a[3]) + float(RoadBuilder.LIFT.get(cls, 0.0)) + (0.16 if sw else 0.0)
		var yaw := atan2(d.x, d.y)
		if big:
			_add(o, T_SIGNAL, pp.x, y, pp.y, yaw, float(k), float(TrafficSignals.axis_of(ang, d.x, d.y)), 0.0)
		elif cls == "street":
			_add(o, T_SIGN, pp.x, y, pp.y, yaw, 0.0, 0.0, 0.0)
