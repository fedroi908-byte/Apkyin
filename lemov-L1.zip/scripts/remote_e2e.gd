extends SceneTree
## End-to-end test of the live-ops client (autoload R) against tools/test_server.py.
## run through tools/e2e_remote.sh   (args after "--": <info.json> <online|offline>)
# autoload globals are not known when a --script main script is compiled: resolve them at run time
var R = null
var G = null
var fails := 0
var total := 0
var port := 0
var info: Dictionary = {}
var work := ""
var blocks: Array = []
var unblocked_n := 0
var deeplinks: Array = []
var applied_n := 0


func _chk(ok: bool, what: String) -> void:
	total += 1
	if OS.get_environment("E2E_VERBOSE") != "":
		print("check ", total, " ", "ok " if ok else "FAIL ", what)
	if not ok:
		fails += 1
		print("FAIL ", what)


func _initialize() -> void:
	_run()


func _get_json(path: String) -> Dictionary:
	var h := HTTPRequest.new()
	root.add_child(h)
	h.request("http://127.0.0.1:%d%s" % [port, path])
	var a: Array = await h.request_completed
	h.queue_free()
	var j: Variant = JSON.parse_string((a[3] as PackedByteArray).get_string_from_utf8())
	return j if j is Dictionary else {}


func _wait(cond: Callable, secs: float) -> bool:
	var t := 0.0
	while t < secs:
		if cond.call():
			return true
		await create_timer(0.1).timeout
		t += 0.1
	return cond.call()


func _check_now() -> void:
	R._last_check = -1.0
	R.check(true)
	await _wait(func(): return not R._checking, 20.0)


func _flush_now() -> void:
	await _wait(func(): return not R._tel_busy, 10.0)
	R.flush_telemetry(true)
	await create_timer(0.05).timeout
	await _wait(func(): return not R._tel_busy, 10.0)


func _idx(id: String) -> int:
	for i in G.cars.size():
		if G.cars[i]["id"] == id:
			return i
	return -1


func _drain_popups() -> Array:
	var out: Array = []
	while true:
		var p: Array = R.take_popup()
		if p.is_empty():
			break
		out.append(p)
	return out


func _run() -> void:
	var a := OS.get_cmdline_user_args()
	var ipath := String(a[0])
	var mode := String(a[1]) if a.size() > 1 else "online"
	work = ipath.get_base_dir()
	info = JSON.parse_string(FileAccess.get_file_as_string(ipath))
	port = int(info["port"])
	await process_frame
	await process_frame
	R = root.get_node("R")
	G = root.get_node("G")
	R._retry_scale = 0.02
	R.blocked.connect(func(k: String, m: String, u: String): blocks.append([k, m, u]))
	R.unblocked.connect(func(): unblocked_n += 1)
	R.deeplink.connect(func(k: String, arg: String): deeplinks.append([k, arg]))
	R.manifest_applied.connect(func(): applied_n += 1)
	if mode == "offline":
		await _run_offline()
	elif mode == "ui":
		await _run_ui()
	else:
		await _run_online()
	print("E2E_REMOTE ", mode, " total=", total, " fails=", fails)
	quit(1 if fails > 0 else 0)


func _run_online() -> void:
	_chk(R.enabled, "client enabled from server.json (vault opened)")
	_chk(await _wait(func(): return R.seq == 10, 25.0), "stage 1 manifest applied (seq 10)")
	_chk(R.build == 1 and R.ver != "", "build info loaded")
	_chk(R.iid.length() == 16, "install id is 16 hex")
	# ---- config / rules / features
	_chk(is_equal_approx(float(R.cfg("game.traffic_mult", 1.0)), 3.0), "cfg clamped to registry max (traffic 5 -> 3)")
	_chk(is_equal_approx(float(R.cfg("game.nitro_mult", 1.0)), 1.0), "cfg wrong type ignored")
	_chk(int(R.cfg("perf.fps_cap", 0)) == 45, "rule overrides (fps_cap 45; never/off rules ignored)")
	_chk(int(R.cfg("perf.max_quality", 3)) == 2, "rule sets perf.max_quality")
	_chk(is_equal_approx(float(R.cfg("game.grip_mult", 1.0)), 1.5), "rule value clamped (grip 9 -> 1.5)")
	_chk(String(R.cfg("ui.banner", "")) == "S1", "cfg string")
	_chk(int(R.cfg("net.check_interval_s", 600)) == 60, "cfg int")
	_chk(bool(R.cfg("perf.shadows", true)), "country rule (UZ) not active before the server told the country")
	_chk(R.feature("ads") and not R.feature("rewarded") and R.feature("never_heard_of_it"), "features / kill switches")
	# ---- news / links / update info
	_chk(R.all_news().size() == 2 and String(R.all_news()[0]["id"]) == "n2", "news sorted newest first")
	_chk(R.unseen_news().size() == 2, "2 unseen news")
	_chk(R.pinned_news().size() == 1 and String(R.pinned_news()[0]["id"]) == "n1", "pinned news")
	R.mark_news_seen("n2")
	_chk(R.unseen_news().size() == 1, "news marked seen")
	_chk(R.links().size() == 2, "javascript: link dropped")
	_chk(String(R.links()[1]["icon"]) == "web", "unknown icon -> web")
	var ui: Dictionary = R.update_info()
	_chk(bool(ui["available"]) and int(ui["build"]) == 99, "soft update available")
	_chk(R.block_kind() == "", "no blocking screen")
	_chk(R.text({"uz": "a", "en": "b"}) in ["a", "b"], "text() picks a language")
	# ---- gifts (type/amount protocol incl. arrays)
	var pops := _drain_popups()
	var joined := JSON.stringify(pops)
	_chk(pops.size() == 2, "2 gift popups (future + wrong-country gifts skipped), got %d" % pops.size())
	_chk(joined.contains("+1000 coins") and joined.contains("+120 XP"), "gift texts")
	var gd: Array = R.state["gifts_done"]
	_chk(gd.has("launch") and gd.has("multi") and not gd.has("future") and not gd.has("zz"), "gifts_done bookkeeping")
	_chk(G.owned_cars.has(String(info["gift_car"])), "gift car granted")
	# ---- catalogue
	var fi := _idx(String(info["first_car"]))
	_chk(fi >= 0 and String(G.cars[fi]["name"]) == "PATCHED NAME" and G.price_of(fi) == 617, "car patch (name, price x econ.price_mult)")
	var hi := _idx(String(info["hide_car"]))
	_chk(hi >= 0 and G.is_hidden(hi), "hide_cars hides the car")
	# ---- packs
	_chk(await _wait(func(): return not R._dl_running, 40.0), "download loop finished")
	var img: String = info["img"]
	var big: String = info["big"]
	var carp: String = info["car"]
	var bad: String = info["bad"]
	_chk(R.pack_path(img) != "" and FileAccess.get_sha256(R.pack_path(img)) == img, "image pack installed + sha ok")
	_chk(R.pack_path(big) != "" and FileAccess.get_sha256(R.pack_path(big)) == big, "5 MB pack (Range chunks) installed + sha ok")
	_chk(R.pack_path(bad) == "" and int(R._dl_fail.get(bad, 0)) >= 3, "tampered pack rejected after retries")
	_chk(FileAccess.file_exists("user://content/cars/%s/model.glb" % carp) and FileAccess.file_exists("user://content/cars/%s/car.json" % carp), "car pack unpacked")
	var ei := _idx("e2e_car")
	_chk(ei >= 0 and G.price_of(ei) == 2121 and String(G.cars[ei]["path"]).ends_with("/model.glb"), "remote car registered (price x0.5, path)")
	_chk(R.texture_of(img) != null, "texture_of() decodes the image pack")
	var rx := await _get_json("/__rx")
	_chk(int(rx["ranges"]) >= 3, "Range requests used (%d)" % int(rx["ranges"]))
	_chk(R.pending_downloads() == 0, "gave up on the bad pack (no endless retry this session)")
	# ---- ads
	var m1: Dictionary = R.ad_pick("menu")
	_chk(String(m1.get("id", "")) == "ad1" and String(m1["title"]) == "Join us" and m1["tex"] != null, "menu ad picked (image ready)")
	_chk(String(R.ad_pick("garage").get("id", "")) == "ad1", "garage ad")
	_chk(R.ad_pick("rewarded").is_empty(), "rewarded off by kill switch")
	_chk(R.ad_pick("splash").is_empty(), "splash off")
	_chk(R.ad_pick("race_end").is_empty(), "interstitial needs finished races")
	R.note_race_finished()
	var re: Dictionary = R.ad_pick("race_end")
	_chk(String(re.get("id", "")) == "ad1", "interstitial after a finished race")
	R.ad_shown(re, "race_end")
	_chk(R.ad_pick("race_end").is_empty(), "interstitial rate-limited right after")
	R.ad_close(re, "race_end")
	R.open_url("lemov://car/rosso")
	R.open_url("javascript:evil()")
	R.open_url("lemov://garage")
	_chk(deeplinks.size() == 2 and deeplinks[0] == ["car", "rosso"] and deeplinks[1] == ["garage", ""], "deep links (non https/lemov ignored)")
	R.hide_banners()
	_chk(R.ad_pick("menu").is_empty(), "banners hidden until next session")
	# ---- daily bonus + telemetry + inbox
	_chk(G.claim_daily() == 100 and G.claim_daily() == 0, "daily bonus once a day")
	R.track("purchase", {"car": "x", "price": 5})
	R.track("bad name!", {})
	R.crash("boom")
	await _ctl("inbox=1")
	var c0: int = G.credits
	var x0: int = G.xp
	await _flush_now()
	rx = await _get_json("/__rx")
	_chk(int(rx["tel_ok"]) >= 1 and int(rx["tel_bad"]) == 0, "telemetry HMAC accepted (ok=%d bad=%d)" % [int(rx["tel_ok"]), int(rx["tel_bad"])])
	var evs: Array = rx["events"]
	_chk(evs.has("ad_imp") and evs.has("ad_close") and evs.has("purchase") and evs.has("crash") and not evs.has("bad name!"), "events delivered, invalid name dropped")
	_chk(String(rx["last"]["iid"]) == String(R.iid) and int(rx["last"]["b"]) == 1, "iid/build in telemetry")
	_chk(G.credits == c0 + 320 and G.xp == x0 + 50, "inbox grants applied once (+320 coins, +50 xp), got %d/%d" % [G.credits - c0, G.xp - x0])
	var p2 := JSON.stringify(_drain_popups())
	_chk(p2.contains("Message body") and p2.contains("Bonus"), "inbox popups")
	_chk(R.cc == "UZ" and not bool(R.cfg("perf.shadows", true)), "country from the Worker re-evaluates the rules")
	await _flush_now()
	rx = await _get_json("/__rx")
	_chk((rx["ack"] as Array).has("m_1") and (rx["ack"] as Array).has("g_2"), "inbox ids acknowledged")
	await _flush_now()
	_chk(G.credits == c0 + 320, "inbox not re-applied")
	# ---- rollback / tamper
	await _ctl("stage=2")
	await _check_now()
	_chk(R.seq == 10 and String(R.cfg("ui.banner", "")) == "S1", "rollback (older signed manifest) rejected")
	await _ctl("stage=3")
	await _check_now()
	_chk(R.seq == 10 and String(R.cfg("ui.banner", "")) == "S1", "tampered manifest (bad signature) rejected")
	# ---- maintenance / forced update / unblock
	await _ctl("stage=4")
	await _check_now()
	_chk(R.seq == 11 and R.block_kind() == "maint" and blocks.size() >= 1 and blocks[blocks.size() - 1][0] == "maint", "maintenance blocks")
	_chk(R.ad_pick("menu").is_empty(), "no ads while blocked")
	await _ctl("stage=5")
	await _check_now()
	_chk(R.block_kind() == "update" and String(blocks[blocks.size() - 1][2]) == "https://example.com/Lemov.apk", "forced update blocks with the apk link")
	await _ctl("stage=6")
	await _check_now()
	_chk(R.block_kind() == "" and unblocked_n >= 1 and String(R.cfg("ui.banner", "")) == "S6", "unblocked again")
	# ---- primary source down -> mirror
	await _ctl("stage=7&down=1")
	await _check_now()
	_chk(R.seq == 14 and String(R.cfg("ui.banner", "")) == "S7", "mirror used when the primary source is down")
	await _ctl("stage=8&down=0")
	await _check_now()
	_chk(R.seq == 15 and R.feature("rewarded") and R.ad_reward_available(), "rewarded enabled")
	var rw: Dictionary = R.ad_pick("rewarded")
	_chk(int(rw.get("reward", 0)) == 321, "rewarded ad reward")
	var c1: int = G.credits
	R.ad_reward_done(rw)
	_chk(G.credits == c1 + 321, "reward paid")
	# ---- remote lock
	await _ctl("inbox=2")
	await _flush_now()
	_chk(R.block_kind() == "lock", "remote lock blocks the game")
	await _ctl("inbox=0")
	await _flush_now()
	_chk(R.block_kind() == "", "lock released")
	# ---- persisted files
	var mt := FileAccess.get_file_as_bytes("user://content/manifest.json")
	var sg := FileAccess.get_file_as_string("user://content/manifest.sig")
	_chk(R.verify_sig(mt, sg, R._key), "cached manifest + signature verify")
	R._save_state()
	var f := FileAccess.open(work + "/run1.json", FileAccess.WRITE)
	f.store_string(JSON.stringify({"iid": R.iid, "credits": G.credits, "seq": R.seq}))
	f.close()


func _ctl(q: String) -> void:
	await _get_json("/__ctl?" + q)


func _run_offline() -> void:
	var r1: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(work + "/run1.json"))
	_chk(R.enabled, "enabled (offline start)")
	_chk(await _wait(func(): return R.seq == 19, 10.0), "cached manifest applied without network (seq 19)")
	_chk(await _wait(func(): return not R._checking and R._boot_done, 20.0), "boot finished")
	_chk(not R.online, "offline detected, no crash")
	_chk(String(R.iid) == String(r1["iid"]), "install id persisted")
	_chk(String(R.cfg("ui.banner", "")) == "S12" and R.feature("rewarded"), "cached config/features")
	_chk(R.pack_path(String(info["img"])) != "" and R.texture_of(String(info["img"])) != null, "cached image pack usable offline")
	_chk(_idx("e2e_car") >= 0, "remote car restored from cache")
	_chk(_drain_popups().is_empty(), "gifts are not granted twice")
	_chk(R.block_kind() == "", "not blocked")
	_chk(not R.ad_pick("menu").is_empty() or R.banners_hidden(), "ads served from cache")
	_chk(R.verify_sig(FileAccess.get_file_as_bytes("user://content/manifest.json"), FileAccess.get_file_as_string("user://content/manifest.sig"), R._key), "cache re-verified")


func _press_first(n: Node) -> void:
	var bs := n.find_children("*", "Button", true, false)
	if not bs.is_empty():
		(bs[0] as Button).emit_signal("pressed")


func _run_ui() -> void:
	# class_name scripts use the autoloads, so they may only be compiled at run time (never named statically here)
	var S_RUI = load("res://scripts/remote_ui.gd")
	var S_NEWS = load("res://scripts/news_screen.gd")
	var S_SET = load("res://scripts/settings_screen.gd")
	var S_AD = load("res://scripts/ads_ui.gd")
	var S_RES = load("res://scripts/result_screen.gd")
	var S_MENU = load("res://scripts/main_menu.gd")
	_chk(await _wait(func(): return R.seq >= 15, 15.0), "cache loaded (ui)")
	await _ctl("stage=8&down=0&inbox=0")
	await _check_now()
	# background pack downloads emit R.progress too: let them finish so they cannot race the pill checks
	await _wait(func(): return not R._dl_running, 20.0)
	await create_timer(0.3).timeout
	# ---- overlays
	var rui = S_RUI.new()
	root.add_child(rui)
	_chk(await _wait(func(): return rui._popup != null, 3.0), "first-run statistics note shown")
	_chk(G.tel_note, "note flag saved")
	_press_first(rui._popup)
	await process_frame
	_chk(rui._popup == null, "note closed with OK")
	await create_timer(0.4).timeout
	_chk(rui._banner.visible and rui._banner_lbl.text.contains("9.9.9"), "soft update banner")
	R.progress.emit(50, 100, "x")
	await create_timer(0.4).timeout
	_chk(rui._dl.visible and rui._dl_lbl.text.contains("50"), "download pill")
	R.progress.emit(100, 100, "")
	await create_timer(0.4).timeout
	_chk(not rui._dl.visible, "download pill hides when done")
	await _ctl("stage=9")
	await _check_now()
	_chk(await _wait(func(): return rui._block != null, 3.0) and rui._block_kind == "maint", "maintenance overlay")
	_chk(not rui._banner.visible, "banner hidden while blocked")
	await _ctl("stage=10")
	await _check_now()
	_chk(await _wait(func(): return rui._block == null, 3.0), "overlay removed when unblocked")
	R.set_world(true)
	await _ctl("stage=11")
	await _check_now()
	await create_timer(0.6).timeout
	_chk(R.block_kind() == "update" and rui._block == null, "block waits while a race is running")
	R.set_world(false)
	_chk(await _wait(func(): return rui._block != null, 3.0) and rui._block_kind == "update", "update overlay appears back in the menu")
	await _ctl("stage=12")
	await _check_now()
	_chk(await _wait(func(): return rui._block == null, 3.0) and R.seq == 19, "final clean manifest")
	# ---- news
	var ns = S_NEWS.new()
	root.add_child(ns)
	await process_frame
	await process_frame
	_chk(R.unseen_news().size() == 0, "opening the news marks them read")
	_chk(ns.find_children("*", "Label", true, false).size() >= 6, "news cards built")
	ns.queue_free()
	# ---- settings
	var ss = S_SET.new()
	root.add_child(ss)
	await process_frame
	ss._show(4)
	await process_frame
	_chk(ss._tab_btns.size() == 5 and ss._body.get_child_count() >= 5, "settings ONLINE tab")
	ss.queue_free()
	# ---- banner card
	var card = S_AD.new("menu")
	root.add_child(card)
	await create_timer(1.3).timeout
	_chk(card.visible and String(card._ad.get("id", "")) == "ad1" and card._counted, "menu banner card + impression")
	card.queue_free()
	# ---- result screen with the interstitial
	var rs = S_RES.new()
	root.add_child(rs)
	rs.show_result({"mission": {"name": "T", "type": "race", "id": "t"}, "success": true, "stars": 2, "value": 61.2, "top": 180.0, "reward": 500})
	var fired := [false]
	rs.retry.connect(func(): fired[0] = true)
	R.note_race_finished()
	_press_first(rs)
	await process_frame
	var scr: Node = null
	for ch in rs.get_children():
		if ch.has_method("show_ad"):
			scr = ch
	_chk(scr != null and not fired[0], "interstitial shown before the action")
	if scr != null:
		scr._t = 99.0
		scr._process(0.0)
		_chk(scr._close.visible, "close button after the skip timer")
		scr._close.emit_signal("pressed")
		await process_frame
	_chk(fired[0], "action continues after the ad")
	rs.queue_free()
	# ---- rewarded screen
	var rw: Dictionary = R.ad_pick("rewarded")
	_chk(not rw.is_empty(), "rewarded ad available")
	if not rw.is_empty():
		var sc = S_AD.Screen.new()
		root.add_child(sc)
		var got := [false]
		sc.finished.connect(func(r: bool): got[0] = r)
		sc.show_ad(rw, "rewarded")
		var c0: int = G.credits
		sc._t = 99.0
		sc._process(0.0)
		_chk(sc._claim.visible, "claim button after the countdown")
		sc._claim.emit_signal("pressed")
		await process_frame
		_chk(got[0] and G.credits == c0 + int(rw["reward"]), "rewarded coins paid")
	# ---- main menu
	var mm = S_MENU.new()
	root.add_child(mm)
	for i in 4:
		await process_frame
	_chk(mm._online_box != null and mm._news_btn.visible and mm._news_btn.text.contains("NEWS"), "menu news button")
	_chk(mm._reward_btn.visible, "menu rewarded button")
	mm.route("garage", "")
	await process_frame
	_chk(mm._mode == "garage", "route garage")
	mm.route("car", String(info["first_car"]))
	await process_frame
	_chk(String(mm.car_data.get("id", "")) == String(info["first_car"]), "route car")
	mm._on_cars_changed()
	await process_frame
	_chk(mm._strip != null, "cars_changed keeps the garage alive")
	mm.route("news", "")
	await process_frame
	mm.queue_free()
	await process_frame
	var card2 = S_AD.new("menu")
	root.add_child(card2)
	await process_frame
	card2._x.emit_signal("pressed")
	await process_frame
	_chk(R.banners_hidden() and not card2.visible, "banner can be hidden for the session")
