class_name StreetProps
extends Node3D

class Cell:
	var b: PropGen.Built
	var node: Node3D
	var ms := []
	var mg := []
	var dirty := {}


class CI:
	var c: Vehicle
	var b := Basis.IDENTITY
	var inv := Basis.IDENTITY
	var o := Vector3.ZERO
	var v := Vector3.ZERO
	var w := Vector3.ZERO
	var f := Vector2.ZERO
	var rv := Vector2.ZERO
	var ctr := Vector2.ZERO
	var hl := 2.0
	var hw := 1.0
	var ylo := 0.0
	var yhi := 1.0
	var sp := 0.0
	var imc := 0.0005
	var hits := 0.0
	var hp := Vector3.ZERO
	var hn := Vector3.ZERO
	var ht := 0


var rb: RoadBuilder
var player: Vehicle
var audio: GameAudio
var atmo: Atmosphere
var tpl: Array
var mat_s: ShaderMaterial
var mat_g: ShaderMaterial
var cells := {}
var jobs := {}
var rjobs := []
var dead := {}
var ghash := {}
var reach := 220.0
var actors: Array = []
var cars: Array = []
var infos: Array = []
var cars_t := 0.0
var max_act := 16
var lamp_n := 2
var lights: Array = []
var light_t := 0.0
var geysers: Array = []
var marks: Array = []
var mark_life := PackedFloat32Array()
var mark_a := PackedFloat32Array()
var mark_i := 0
var puds: Array = []
var drops_max := 40
var dp := PackedVector3Array()
var dvel := PackedVector3Array()
var dlife := PackedFloat32Array()
var dn := 0
var mm: MultiMesh
var under_k := 0.0
var snd_under: AudioStreamPlayer
var rtex: GradientTexture2D
var meshes := {}
var shadows := true
var splash_t := 0.0


func _ready() -> void:
	var tier := Q.level()
	reach = float(Q.get_v("prop_dist")) + 60.0
	max_act = [10, 16, 24, 32][tier]
	lamp_n = [0, 2, 4, 6][tier]
	drops_max = [36, 60, 100, 150][tier]
	shadows = bool(Q.get_v("shadows"))
	tpl = PropGen.templates()
	mat_s = ShaderMaterial.new()
	mat_s.shader = load("res://shaders/street_prop.gdshader")
	mat_g = ShaderMaterial.new()
	mat_g.shader = load("res://shaders/street_glow.gdshader")
	rtex = radial_tex()
	for i in lamp_n:
		var l := OmniLight3D.new()
		l.omni_range = 17.0
		l.light_color = Color(1.0, 0.78, 0.5)
		l.light_energy = 0.0
		l.visible = false
		add_child(l)
		lights.append(l)
	mm = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.instance_count = drops_max
	var qm := QuadMesh.new()
	qm.size = Vector2(0.3, 0.3)
	mm.mesh = qm
	mm.visible_instance_count = 0
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = quad_mat(Color(0.82, 0.92, 1.0, 0.5), true)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.custom_aabb = AABB(Vector3(-6000, -200, -6000), Vector3(12000, 800, 12000))
	add_child(mi)
	dp.resize(drops_max)
	dvel.resize(drops_max)
	dlife.resize(drops_max)
	for i in 28:
		marks.append(mark_node(false))
	for i in 4:
		puds.append(mark_node(true))
	mark_life.resize(marks.size())
	mark_a.resize(marks.size())
	snd_under = AudioStreamPlayer.new()
	snd_under.stream = SoundBank.wav("rain_roof", true)
	snd_under.bus = "Fx"
	snd_under.volume_db = -60.0
	add_child(snd_under)


func radial_tex() -> GradientTexture2D:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.85), Color(1, 1, 1, 0)])
	var tx := GradientTexture2D.new()
	tx.gradient = g
	tx.fill = GradientTexture2D.FILL_RADIAL
	tx.fill_from = Vector2(0.5, 0.5)
	tx.fill_to = Vector2(1.0, 0.5)
	tx.width = 64
	tx.height = 64
	return tx


func quad_mat(col: Color, bill: bool) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = rtex
	m.albedo_color = col
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	if bill:
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	return m


func mark_node(pud: bool) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(1, 1)
	q.orientation = PlaneMesh.FACE_Y
	mi.mesh = q
	mi.material_override = quad_mat(Color(0.03, 0.05, 0.08, 0.0), false)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.visibility_range_end = 100.0
	mi.visible = false
	add_child(mi)
	return mi


func add_mark(p: Vector3, r: float, a: float, life: float) -> void:
	var i := mark_i % marks.size()
	mark_i += 1
	var mi: MeshInstance3D = marks[i]
	mi.global_transform = Transform3D(Basis(Vector3.UP, randf() * TAU).scaled(Vector3(r * 2.0, 1.0, r * 2.0)), Vector3(p.x, W.ground_height(p.x, p.z, p.y + 1.0) + 0.03, p.z))
	mi.visible = true
	mark_life[i] = life
	mark_a[i] = a


func update_marks(dt: float) -> void:
	for i in marks.size():
		if mark_life[i] > 0.0:
			mark_life[i] -= dt
			var mi: MeshInstance3D = marks[i]
			if mark_life[i] <= 0.0:
				mi.visible = false
			else:
				var m: StandardMaterial3D = mi.material_override
				m.albedo_color.a = mark_a[i] * clampf(mark_life[i] / 10.0, 0.0, 1.0)
	for g in geysers:
		var mi: MeshInstance3D = puds[g["pi"]]
		var gt: float = g["t"]
		var rad := 0.4 + 1.9 * (1.0 - exp(-gt / 9.0))
		var live: bool = gt < g["life"]
		var fade: float = 1.0 if live else clampf(1.0 - (gt - float(g["life"])) / 45.0, 0.0, 1.0)
		var p: Vector3 = g["p"]
		mi.global_transform = Transform3D(Basis.IDENTITY.scaled(Vector3(rad * 2.0, 1.0, rad * 2.0)), Vector3(p.x, W.ground_height(p.x, p.z, p.y + 1.0) + 0.028, p.z))
		mi.visible = fade > 0.0
		var m: StandardMaterial3D = mi.material_override
		m.albedo_color.a = 0.5 * fade


func _gen(id: int, out: Array, dl: PackedInt32Array) -> void:
	out.append(PropGen.generate(rb, id, tpl, dl))


func _rebuild(recs: PackedFloat32Array, alive: PackedByteArray, s: int, x0: float, z0: float, out: Array) -> void:
	out.append(PropGen.mesh_sub(recs, alive, tpl, s, x0, z0))


func _exit_tree() -> void:
	for id in jobs.keys():
		WorkerThreadPool.wait_for_task_completion(jobs[id][0])
	for j in rjobs:
		WorkerThreadPool.wait_for_task_completion(j[0])
	jobs.clear()
	rjobs.clear()


func cell_pos(id: int) -> Vector2:
	return Vector2((float(id / 1000) + 0.5) * RoadBuilder.CELL - W.half, (float(id % 1000) + 0.5) * RoadBuilder.CELL - W.half)


func focus(p: Vector3) -> void:
	var c := rb._cell_of(p.x, p.z)
	var lim := reach + 424.0
	var rc := int(ceil(lim / RoadBuilder.CELL))
	var pv := Vector2(p.x, p.z)
	for dx in range(-rc, rc + 1):
		for dz in range(-rc, rc + 1):
			if c.x + dx < 0 or c.y + dz < 0:
				continue
			var id := rb._cell_id(c.x + dx, c.y + dz)
			if cells.has(id) or jobs.has(id) or jobs.size() >= 2:
				continue
			if not (rb.cell_runs.has(id) or rb.cell_junctions.has(id)) or cell_pos(id).distance_to(pv) > lim:
				continue
			var out := []
			var dl: PackedInt32Array = dead.get(id, PackedInt32Array())
			jobs[id] = [WorkerThreadPool.add_task(_gen.bind(id, out, dl), false, "props"), out]
	for id in cells.keys():
		if cell_pos(id).distance_to(pv) > lim + 300.0:
			free_cell(id)


func build_all_near(p: Vector3, rc: int) -> void:
	var c := rb._cell_of(p.x, p.z)
	for dx in range(-rc, rc + 1):
		for dz in range(-rc, rc + 1):
			var id := rb._cell_id(c.x + dx, c.y + dz)
			if cells.has(id) or not (rb.cell_runs.has(id) or rb.cell_junctions.has(id)):
				continue
			var dl: PackedInt32Array = dead.get(id, PackedInt32Array())
			finish_cell(id, PropGen.generate(rb, id, tpl, dl))


func poll_jobs() -> void:
	for id in jobs.keys():
		var j: Array = jobs[id]
		if WorkerThreadPool.is_task_completed(j[0]):
			WorkerThreadPool.wait_for_task_completion(j[0])
			jobs.erase(id)
			if j[1].size() > 0 and not cells.has(id):
				finish_cell(id, j[1][0])
			return


func mk_mesh(parent: Node3D, m: MeshUtil, mat: Material, shadow: bool) -> MeshInstance3D:
	if m.vertex_count() == 0:
		return null
	var mi := MeshInstance3D.new()
	mi.mesh = m.build(mat)
	mi.visibility_range_end = reach
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if (shadow and shadows) else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func finish_cell(id: int, b: PropGen.Built) -> void:
	var cl := Cell.new()
	cl.b = b
	cl.node = Node3D.new()
	add_child(cl.node)
	for s in 9:
		var pr: Array = b.subs[s]
		cl.ms.append(mk_mesh(cl.node, pr[0], mat_s, true))
		cl.mg.append(mk_mesh(cl.node, pr[1], mat_g, false))
	b.subs = []
	cells[id] = cl
	for key in b.hash.keys():
		var lst: PackedInt32Array = b.hash[key]
		var g: PackedInt64Array = ghash.get(key, PackedInt64Array())
		for i in lst:
			g.append(id * 100000 + i)
		ghash[key] = g


func free_cell(id: int) -> void:
	var cl: Cell = cells[id]
	for key in cl.b.hash.keys():
		var g: PackedInt64Array = ghash.get(key, PackedInt64Array())
		var n := PackedInt64Array()
		for v in g:
			if v / 100000 != id:
				n.append(v)
		if n.is_empty():
			ghash.erase(key)
		else:
			ghash[key] = n
	cl.node.queue_free()
	cells.erase(id)


func remove_prop(cid: int, idx: int) -> void:
	var cl: Cell = cells[cid]
	cl.b.alive[idx] = 0
	var d: PackedInt32Array = dead.get(cid, PackedInt32Array())
	d.append(idx)
	dead[cid] = d
	var o := idx * 8
	var s := PropGen.sub_of(cl.b.recs[o + 1], cl.b.recs[o + 3], float(cid / 1000) * RoadBuilder.CELL - W.half, float(cid % 1000) * RoadBuilder.CELL - W.half)
	cl.dirty[s] = int(cl.dirty.get(s, 0)) + 1


func pump_rebuilds() -> void:
	for j in rjobs.duplicate():
		if WorkerThreadPool.is_task_completed(j[0]):
			WorkerThreadPool.wait_for_task_completion(j[0])
			rjobs.erase(j)
			var cid: int = j[1]
			var s: int = j[2]
			if not cells.has(cid):
				continue
			var cl: Cell = cells[cid]
			var pr: Array = j[4][0]
			apply_sub(cl, cl.ms, s, pr[0], mat_s, true)
			apply_sub(cl, cl.mg, s, pr[1], mat_g, false)
			if int(cl.dirty.get(s, 0)) == int(j[3]):
				cl.dirty.erase(s)
			return
	if rjobs.size() >= 2:
		return
	for cid in cells.keys():
		var cl: Cell = cells[cid]
		for s in cl.dirty.keys():
			var busy := false
			for j in rjobs:
				if j[1] == cid and j[2] == s:
					busy = true
			if busy:
				continue
			var out := []
			var x0 := float(cid / 1000) * RoadBuilder.CELL - W.half
			var z0 := float(cid % 1000) * RoadBuilder.CELL - W.half
			rjobs.append([WorkerThreadPool.add_task(_rebuild.bind(cl.b.recs, cl.b.alive.duplicate(), s, x0, z0, out), false, "props rebuild"), cid, s, int(cl.dirty[s]), out])
			return


func apply_sub(cl: Cell, lst: Array, s: int, m: MeshUtil, mat: Material, shadow: bool) -> void:
	var cur: MeshInstance3D = lst[s]
	if m.vertex_count() == 0:
		if cur != null:
			cur.queue_free()
		lst[s] = null
	elif cur != null:
		cur.mesh = m.build(mat)
	else:
		lst[s] = mk_mesh(cl.node, m, mat, shadow)


func _process(dt: float) -> void:
	if player == null or rb == null:
		return
	var p := player.global_position
	poll_jobs()
	pump_rebuilds()
	focus(p)
	cars_t -= dt
	if cars_t <= 0.0:
		cars_t = 0.5
		cars = [player]
		for b in get_tree().get_nodes_in_group("audio_cars"):
			if b != player and b is Vehicle and (b as Vehicle).global_position.distance_to(p) < 160.0:
				cars.append(b)
	light_t -= dt
	if light_t <= 0.0:
		light_t = 0.3
		update_lights(p)
	update_marks(dt)
	mm.visible_instance_count = dn
	for i in dn:
		mm.set_instance_transform(i, Transform3D(Basis.IDENTITY, dp[i]))


func update_lights(p: Vector3) -> void:
	if lamp_n == 0 or atmo == null:
		return
	var nk := smoothstep(-0.05, -0.32, atmo.elevation)
	if nk < 0.12:
		for l in lights:
			l.visible = false
		return
	var cand: Array = []
	var gx0 := int(floor(p.x / 8.0))
	var gz0 := int(floor(p.z / 8.0))
	for gx in range(gx0 - 9, gx0 + 10):
		for gz in range(gz0 - 9, gz0 + 10):
			var key := (gx + 2048) * 4096 + gz + 2048
			if not ghash.has(key):
				continue
			for v in ghash[key]:
				var cid := int(v / 100000)
				if not cells.has(cid):
					continue
				var cl: Cell = cells[cid]
				var idx := int(v % 100000)
				var o := idx * 8
				var r := cl.b.recs
				if cl.b.alive[idx] == 0 or int(r[o]) != PropGen.T_LAMP or r[o + 6] > 1.5 or nk < r[o + 5]:
					continue
				var yaw := r[o + 4]
				var hp := Vector3(r[o + 1] + sin(yaw) * 2.0, r[o + 2] + 6.6, r[o + 3] + cos(yaw) * 2.0)
				cand.append([hp.distance_squared_to(p), hp])
	cand.sort_custom(func(x, y): return x[0] < y[0])
	for i in lights.size():
		var l: OmniLight3D = lights[i]
		if i < cand.size():
			l.global_position = cand[i][1]
			l.light_energy = 1.7 * nk
			l.visible = true
		else:
			l.visible = false


func build_infos() -> void:
	infos.clear()
	for c in cars:
		if not is_instance_valid(c):
			continue
		var ci := CI.new()
		var xf: Transform3D = c.global_transform
		ci.c = c
		ci.b = xf.basis
		ci.inv = xf.basis.inverse()
		ci.o = xf.origin
		ci.v = c.linear_velocity
		ci.w = c.angular_velocity
		ci.f = Vector2(xf.basis.z.x, xf.basis.z.z).normalized()
		ci.rv = Vector2(ci.f.y, -ci.f.x)
		ci.ctr = Vector2(xf.origin.x, xf.origin.z)
		ci.hl = c._hull_base.z * 0.5
		ci.hw = c._hull_base.x * 0.5
		ci.ylo = xf.origin.y + 0.1
		ci.yhi = xf.origin.y + 1.25
		ci.sp = Vector2(ci.v.x, ci.v.z).length()
		ci.imc = 1.0 / c.car_mass
		infos.append(ci)


func _physics_process(dt: float) -> void:
	TrafficSignals.clock += dt
	RenderingServer.global_shader_parameter_set("sig_time", fposmod(TrafficSignals.clock, TrafficSignals.CYCLE))
	if player == null or rb == null:
		return
	build_infos()
	for ci in infos:
		if ci.sp > 0.3:
			scan_car(ci)
	if not actors.is_empty():
		step_actors(dt)
	if not geysers.is_empty() or dn > 0:
		water_step(dt)
	for ci in infos:
		if ci.hits > 2.0:
			ci.c.prop_hit(ci.hp, ci.hn, ci.hits, PropGen.KDMG[ci.ht])
			hit_sound(ci.ht, ci.hp, ci.hits)


func scan_car(ci: CI) -> void:
	var ext := ci.hl + 2.0
	var seen := {}
	for gx in range(int(floor((ci.ctr.x - ext) / 8.0)), int(floor((ci.ctr.x + ext) / 8.0)) + 1):
		for gz in range(int(floor((ci.ctr.y - ext) / 8.0)), int(floor((ci.ctr.y + ext) / 8.0)) + 1):
			var key := (gx + 2048) * 4096 + gz + 2048
			if not ghash.has(key):
				continue
			for v in ghash[key]:
				if seen.has(v):
					continue
				seen[v] = true
				var cid := int(v / 100000)
				if cells.has(cid):
					test_static(ci, cid, int(v % 100000))


func test_static(ci: CI, cid: int, idx: int) -> void:
	var cl: Cell = cells[cid]
	if cl.b.alive[idx] == 0:
		return
	var o := idx * 8
	var r := cl.b.recs
	var t := int(r[o])
	var py := r[o + 2]
	if py > ci.yhi or py + float(PropGen.H[t]) < ci.ylo:
		return
	var yaw := r[o + 4]
	var cs := cos(yaw)
	var sn := sin(yaw)
	for cc in PropGen.CIRC[t]:
		var cx: float = cc[0]
		var cz: float = cc[1]
		var cr: float = cc[2]
		var d := Vector2(r[o + 1] + cx * cs + cz * sn, r[o + 3] - cx * sn + cz * cs) - ci.ctr
		var lx := d.dot(ci.f)
		var lz := d.dot(ci.rv)
		var qx := clampf(lx, -ci.hl, ci.hl)
		var qz := clampf(lz, -ci.hw, ci.hw)
		var ex := lx - qx
		var ez := lz - qz
		var dist := sqrt(ex * ex + ez * ez)
		if dist >= cr + 0.03:
			continue
		var n2 := Vector2.ZERO
		if dist > 0.001:
			n2 = (ci.f * ex + ci.rv * ez) / dist
		elif ci.hl - absf(lx) < ci.hw - absf(lz):
			n2 = ci.f * (1.0 if lx >= 0.0 else -1.0)
		else:
			n2 = ci.rv * (1.0 if lz >= 0.0 else -1.0)
		var n := Vector3(n2.x, 0.0, n2.y)
		var cpv := ci.ctr + ci.f * qx + ci.rv * qz
		var cp := Vector3(cpv.x, clampf(py + 0.35, ci.ylo, ci.yhi), cpv.y)
		var vc := ci.v + ci.w.cross(cp - ci.o)
		var dv := vc.dot(n)
		if dv < 0.2:
			continue
		var bn: float = PropGen.BREAK_N[t]
		var cm: float = ci.c.car_mass
		var fk := cm * dv * dv / 0.6
		if bn > 0.0 and fk < bn:
			ci.c.apply_impulse(-n * cm * 1.25 * dv, cp - ci.o)
			ci.hits = maxf(ci.hits, dv)
			ci.hp = cp
			ci.hn = -n
			ci.ht = t
			return
		var tn: float = PropGen.TEAR_N[t]
		var shear := bn > 0.0 and fk >= tn
		if shear:
			var dvc := dv - sqrt(maxf(dv * dv - 0.6 * tn / cm, 0.0))
			ci.c.apply_impulse(-n * cm * dvc, cp - ci.o)
			ci.v -= n * dvc
		ci.hits = maxf(ci.hits, dv)
		ci.hp = cp
		ci.hn = -n
		ci.ht = t
		activate(cid, idx, shear)
		return


func activate(cid: int, idx: int, shear: bool = false) -> void:
	var cl: Cell = cells[cid]
	var o := idx * 8
	var r := cl.b.recs
	var t := int(r[o])
	var org := Vector3(r[o + 1], r[o + 2], r[o + 3])
	if actors.size() >= max_act:
		var old: RigidProp = actors[0]
		for a in actors:
			if a.asleep:
				old = a
				break
		free_actor(old)
	var lf := clampf(org.y - W.ground_height(org.x, org.z, org.y + 1.0), 0.0, 0.9)
	var a := RigidProp.make(t, org, r[o + 4], lf)
	if shear:
		a.anch = false
		a.torn = true
	if not a.anch:
		a.vel += Vector3(randf_range(-0.4, 0.4), 0.0, randf_range(-0.4, 0.4))
		a.w += Vector3(randf_range(-0.25, 0.25), randf_range(-0.25, 0.25), randf_range(-0.25, 0.25))
	if not meshes.has(t):
		meshes[t] = PropGen.actor_mesh(tpl, t, mat_s)
	var mi := MeshInstance3D.new()
	mi.mesh = meshes[t]
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	mi.global_transform = a.origin_xf()
	a.node = mi
	actors.append(a)
	remove_prop(cid, idx)


func free_actor(a: RigidProp) -> void:
	if a.node != null:
		a.node.queue_free()
	actors.erase(a)


func step_actors(dt: float) -> void:
	var h := dt * 0.5
	var pp := player.global_position
	for a in actors.duplicate():
		a.age += dt
		a.snd_t = maxf(a.snd_t - dt, 0.0)
		var rr := maxf(a.br, float(PropGen.H[a.t]) * 0.9) + 2.5
		var apos := Vector2(a.pos.x, a.pos.z)
		var near: Array = []
		for ci in infos:
			if ci.ctr.distance_to(apos) < ci.hl + rr:
				near.append(ci)
		if a.asleep:
			for ci in near:
				if ci.sp > 0.3:
					a.asleep = false
					a.rest_t = 0.0
			if a.asleep:
				if a.age > 40.0 and pp.distance_to(a.pos) > 90.0:
					free_actor(a)
				continue
		a.hit_v = 0.0
		a.slide = 0.0
		a.ground()
		for s in 2:
			a.integrate(h)
			var acc := 0.0
			for it in 3:
				a.ground_contacts()
				if a.anch:
					acc += a.solve_anchor(h)
				for ci in near:
					car_contact(a, ci)
			if a.anch and acc / h > a.tear_n:
				a.anch = false
				a.torn = true
			a.advance(h)
		a.node.global_transform = a.origin_xf()
		if a.vel.length_squared() < 0.03 and a.w.length_squared() < 0.05:
			a.rest_t += dt
			if a.rest_t > 0.7:
				a.asleep = true
		else:
			a.rest_t = 0.0
		if a.torn and not a.tdone:
			a.tdone = true
			on_torn(a)
		if a.hit_v > 1.0 and a.snd_t <= 0.0:
			a.snd_t = 0.14
			hit_sound(a.t, a.pos, a.hit_v)
			after_hit(a)
		if a.pos.y < W.terrain_height(a.pos.x, a.pos.z) - 8.0:
			free_actor(a)
	for i in actors.size():
		var a: RigidProp = actors[i]
		if a.t == PropGen.T_LAMP or a.t == PropGen.T_SIGNAL or a.t == PropGen.T_SIGN:
			continue
		for j in range(i + 1, actors.size()):
			var b: RigidProp = actors[j]
			if not (a.asleep and b.asleep) and a.pos.distance_squared_to(b.pos) < 9.0:
				a.pair(b)


func car_contact(a: RigidProp, ci: CI) -> void:
	var rp := a.pr
	var hw := ci.hw + rp
	var hl := ci.hl + rp
	var yl := 0.3 - rp
	var yh := 1.25 + rp
	for i in a.pts.size():
		var wp := a.point(i)
		var l := ci.inv * (wp - ci.o)
		if absf(l.x) >= hw or absf(l.z) >= hl or l.y <= yl or l.y >= yh:
			continue
		var dx := hw - absf(l.x)
		var dz := hl - absf(l.z)
		var dyt := (yh - l.y) * 3.0
		var dyb := (l.y - yl) * 3.0
		var ln := Vector3.ZERO
		var dep := 0.0
		var mu := 0.5
		if dyt <= dx and dyt <= dz and dyt <= dyb:
			ln = Vector3(0.25 * signf(l.x) + 0.2 * clampf(l.x / hw, -1.0, 1.0), 1.0, 0.0).normalized()
			dep = dyt / 3.0
			mu = 0.1
		elif dyb <= dx and dyb <= dz:
			ln = Vector3.DOWN
			dep = dyb / 3.0
		elif dz <= dx:
			ln = Vector3(0.0, 0.35 if l.y < 0.8 else 1.2, 1.0 if l.z >= 0.0 else -1.0).normalized()
			dep = dz
		else:
			ln = Vector3(1.0 if l.x >= 0.0 else -1.0, 0.0, 0.0)
			dep = dx
		var n := ci.b * ln
		var cp := wp - n * minf(dep, rp + 0.02)
		var vc := ci.v + ci.w.cross(cp - ci.o)
		var j := a.impulse(cp, n, vc, ci.imc, a.e * 0.5, mu)
		a.pos += n * minf(dep, 0.2) * 0.12
		if j > 0.0:
			ci.c.apply_impulse(-n * j, cp - ci.o)
			ci.v -= n * (j * ci.imc)
			a.asleep = false
			a.rest_t = 0.0
			var dvh := -a.last_vn
			if dvh > ci.hits:
				ci.hits = dvh
				ci.hp = cp
				ci.hn = -n
				ci.ht = a.t


func snd(name: String, pos: Vector3, db: float, pitch: float) -> void:
	if audio != null:
		audio.shot3d(name, pos, db, pitch)


func hit_sound(t: int, pos: Vector3, v: float) -> void:
	var db := clampf(-16.0 + v * 2.2, -16.0, 2.0)
	match t:
		PropGen.T_BIN:
			snd("plastic1", pos, db, randf_range(0.7, 0.9))
			if v > 3.0:
				snd("knock", pos, db - 4.0, randf_range(0.8, 1.0))
		PropGen.T_CONE:
			snd("plastic1", pos, db - 2.0, randf_range(1.3, 1.6))
		PropGen.T_BENCH:
			snd("knock", pos, db, randf_range(0.7, 0.9))
		PropGen.T_DUMPSTER:
			snd("metal_hit1", pos, db, randf_range(0.55, 0.7))
			snd("rattle", pos, db - 6.0, randf_range(0.8, 1.0))
		_:
			snd("metal_hit1" if randf() < 0.5 else "metal_hit2", pos, db, clampf(1.5 - float(PropGen.MASS[t]) * 0.0012, 0.55, 1.4) * randf_range(0.95, 1.05))


func after_hit(a: RigidProp) -> void:
	if a.fx != 0 or a.hit_v < 2.5:
		return
	if a.t == PropGen.T_BIN:
		a.fx = 1
		for i in 7:
			var col := Color(randf_range(0.5, 0.9), randf_range(0.5, 0.9), randf_range(0.4, 0.8))
			Debris.spawn(self, "dark", Vector3(randf_range(0.05, 0.12), 0.02, randf_range(0.05, 0.12)), col, a.pos + Vector3(0, 0.5, 0), Vector3(randf_range(-2.5, 2.5), randf_range(1.5, 4.0), randf_range(-2.5, 2.5)) + a.vel * 0.5, Vector3(randf_range(-6, 6), randf_range(-6, 6), randf_range(-6, 6)), 8.0)
	elif a.t == PropGen.T_LAMP and a.hit_v > 3.0:
		a.fx = 1
		var hp := a.pos + a.rot * (Vector3(0, 6.8, 2.0) - a.com)
		snd("glass1", hp, -2.0, randf_range(0.9, 1.1))
		for i in 6:
			Debris.spawn(self, "glass", Vector3(randf_range(0.03, 0.09), 0.01, randf_range(0.03, 0.09)), Color(0.85, 0.92, 1.0, 0.7), hp, Vector3(randf_range(-3, 3), randf_range(0.5, 3.0), randf_range(-3, 3)), Vector3(randf_range(-8, 8), randf_range(-8, 8), randf_range(-8, 8)), 5.0)


func on_torn(a: RigidProp) -> void:
	snd("metal_hit2", a.anch_w, 0.0, 0.7)
	if a.t == PropGen.T_HYDRANT:
		start_geyser(a.anch_w)


func start_geyser(p: Vector3) -> void:
	var s := AudioStreamPlayer3D.new()
	s.stream = SoundBank.wav("steam", true)
	s.volume_db = -4.0
	s.pitch_scale = 1.15
	s.max_distance = 90.0
	s.unit_size = 7.0
	s.bus = "Fx"
	add_child(s)
	s.global_position = p + Vector3(0, 1.0, 0)
	s.play()
	var pi := geysers.size() % puds.size()
	for g in geysers:
		if g["pi"] == pi:
			g["t"] = 1.0e9
	geysers.append({"p": p, "t": 0.0, "life": 50.0, "pi": pi, "snd": s})


func water_step(dt: float) -> void:
	for g in geysers.duplicate():
		g["t"] += dt
		var gt: float = g["t"]
		var gs: AudioStreamPlayer3D = g["snd"]
		if gt > float(g["life"]):
			gs.volume_db = lerpf(-4.0, -50.0, clampf((gt - float(g["life"])) / 3.0, 0.0, 1.0))
			if gt > float(g["life"]) + 3.0 and gs.playing:
				gs.stop()
				gs.queue_free()
			if gt > float(g["life"]) + 50.0:
				geysers.erase(g)
				(puds[g["pi"]] as MeshInstance3D).visible = false
			continue
		var gp: Vector3 = g["p"]
		var cnt := int(float(drops_max) * 0.9 * dt + randf())
		for k in cnt:
			if dn >= drops_max:
				break
			dp[dn] = gp + Vector3(randf_range(-0.05, 0.05), 0.2, randf_range(-0.05, 0.05))
			dvel[dn] = Vector3(randf_range(-1.1, 1.1), randf_range(9.0, 12.0), randf_range(-1.1, 1.1))
			dlife[dn] = 2.6
			dn += 1
	var hits := 0
	var i := 0
	while i < dn:
		dvel[i] += Vector3(0.0, -9.8 * dt, 0.0)
		dp[i] += dvel[i] * dt
		var q := dp[i]
		var kill := false
		for ci in infos:
			var l: Vector3 = ci.inv * (q - ci.o)
			if absf(l.x) < ci.hw + 0.05 and absf(l.z) < ci.hl + 0.05 and l.y > 0.3 and l.y < ci.yhi - ci.o.y:
				hits += 1
				if dvel[i].y < 0.0 and l.y > 0.9:
					kill = true
					continue
				var out: Vector3 = ci.b * Vector3(signf(l.x) * randf_range(0.5, 2.5), 0.0, signf(l.z) * randf_range(0.5, 2.5))
				dvel[i] = Vector3(out.x, randf_range(-1.5, 0.6), out.z) + ci.v * 0.3
				dp[i] = ci.o + ci.b * Vector3(l.x, 0.28, l.z)
				if randf() < 0.35:
					kill = true
		var gy := W.ground_height(q.x, q.z, q.y + 1.0)
		if q.y < gy:
			if dvel[i].y < -2.0 and dlife[i] > 0.0:
				splash_t -= 1.0
				if splash_t <= 0.0:
					splash_t = 5.0
					add_mark(q, randf_range(0.18, 0.45), 0.42, randf_range(20.0, 40.0))
			kill = true
		dlife[i] -= dt
		if kill or dlife[i] <= 0.0:
			dn -= 1
			dp[i] = dp[dn]
			dvel[i] = dvel[dn]
			dlife[i] = dlife[dn]
		else:
			i += 1
	under_k = lerpf(under_k, clampf(float(hits) / 2.5, 0.0, 1.0), 0.15)
	if under_k > 0.03:
		snd_under.volume_db = lerpf(-34.0, -3.0, under_k)
		snd_under.pitch_scale = 0.9 + 0.3 * under_k
		if not snd_under.playing:
			snd_under.play()
	elif snd_under.playing:
		snd_under.stop()
