extends Node3D
var frames := 0
var shots := []
var idx := 0
var cam: Camera3D
var kind := "hyper"
func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	kind = a[0] if a.size() > 0 else "hyper"
	var lod := a.size() > 1 and a[1] == "1"
	var pre: String = a[2] if a.size() > 2 else "/tmp/c"
	var at := Atmosphere.new()
	add_child(at)
	at.paused = true
	at.set_time(15.0)
	var floor_m := MeshInstance3D.new()
	var pm := PlaneMesh.new(); pm.size = Vector2(60, 60)
	floor_m.mesh = pm
	var fm := StandardMaterial3D.new(); fm.albedo_color = Color(0.32, 0.32, 0.34); fm.roughness = 0.5
	floor_m.material_override = fm
	add_child(floor_m)
	var c := CarBuilder.build(kind, Color(0.85, 0.08, 0.06), Color(0.05, 0.05, 0.06), lod)
	add_child(c["node"])
	if c["node"].has_meta("paints"):
		for pmat in c["node"].get_meta("paints"):
			(pmat as ShaderMaterial).set_shader_parameter("car_to_world", Transform3D.IDENTITY)
	cam = Camera3D.new()
	cam.fov = 38
	add_child(cam)
	shots = [[Vector3(5.5, 1.5, 6.5), pre + "_front.png"], [Vector3(-5.5, 1.6, -6.5), pre + "_rear.png"], [Vector3(7.5, 1.1, 0.5), pre + "_side.png"]]
func _process(_d: float) -> void:
	frames += 1
	if frames % 4 == 1 and idx < shots.size():
		cam.position = shots[idx][0]
		cam.look_at(Vector3(0, 0.7, 0))
	if frames % 4 == 0 and idx < shots.size():
		get_viewport().get_texture().get_image().save_png(shots[idx][1])
		idx += 1
		if idx >= shots.size():
			get_tree().quit()
