class_name TrafficSignals
extends RefCounted

const CYCLE := 50.0
static var clock := 0.0


static func offset(k: int) -> float:
	return fposmod(float(k) * 17.37, CYCLE)


static func phase(k: int, axis: int, t: float) -> float:
	return fposmod(t - offset(k) - float(axis) * 25.0, CYCLE)


static func state(k: int, axis: int, t: float) -> int:
	var u := phase(k, axis, t)
	if u < 20.0:
		return 2
	if u < 23.0:
		return 1
	return 0


static func time_left(k: int, axis: int, t: float) -> float:
	var u := phase(k, axis, t)
	if u < 20.0:
		return 20.0 - u
	if u < 23.0:
		return 23.0 - u
	return CYCLE - u


static func axis_of(ang: float, dx: float, dz: float) -> int:
	return 0 if absf(dx * cos(ang) + dz * sin(ang)) >= absf(dz * cos(ang) - dx * sin(ang)) else 1
