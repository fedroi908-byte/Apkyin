extends SceneTree
func _init() -> void:
	var f := FileAccess.open("res://data/races.json", FileAccess.READ)
	var d: Dictionary = JSON.parse_string(f.get_as_text())
	var M: GDScript = load("res://scripts/race_path.gd")
	for r in d["races"]:
		var a: Array = r["pts"]
		var b: Array = M.clean(a)
		print("DESPUR ", r["id"], " ", a.size(), " -> ", b.size())
	quit()
