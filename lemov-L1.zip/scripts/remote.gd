extends Node
## Live-ops client (autoload "R").
## Server content is DATA only (json + packs). It is accepted only when the manifest is signed with the owner's RSA key
## (RSASSA-PKCS1-v1_5 / SHA-256); the game never downloads or runs code. Transport (raw GitHub, CDN mirror) is untrusted.
## Failure policy: nothing in here may block, freeze or crash the game. Offline = last verified cached manifest, bad data = ignored.
## Inert (zero network, no popups) when data/server.json is missing, invalid or disabled.

signal manifest_applied
signal news_ready(items: Array)
signal progress(done: int, total: int, label: String)
signal cars_changed
signal blocked(kind: String, msg: String, url: String)     # kind: maint | update | lock
signal unblocked
signal inbox_ready
signal ads_changed
signal popup_requested(title: String, body: String)
signal deeplink(kind: String, arg: String)

const SALT_HEX := "76c9f7920cfadf7b0b05bf68c9affd1ce1e97b8a858eee19e3799a6e84a5f8c1"
const FX_FILE := "res://data/fx.bin"
const FX_TAG := "lemov-fx|1"
const DIR := "user://content"
const MAX_MANIFEST := 524288
const MAX_PACK := 262144000
const CHUNK := 2097152
const PHYS_OK := ["hyper", "super", "muscle", "coupe", "sedan", "hatch", "suv", "pickup", "van", "bus"]
const ICONS := ["telegram", "instagram", "youtube", "web", "discord", "x", "tiktok"]
const LANGS := ["uz", "ru", "en"]

var enabled := false
var online := false
var seq := 0
var build := 1
var ver := "1.0.0"
var iid := ""
var cc := ""
var cfg_rev := 0
var in_world := false           # GameWorld sets it: downloads pause and fps is sampled during a race / free roam
var menu_active := true         # Main sets it: popups and blocking screens wait for the menu
var man: Dictionary = {}        # last verified + sanitised manifest
var state: Dictionary = {}
var cellular_ok: bool:
	get:
		return bool(G.cellular_dl) if G != null else false

var _salt := PackedByteArray()
var _crypto := Crypto.new()
var _key: CryptoKey = null
var _src: Array = []
var _tel := ""
var _hk := ""
var _reg: Dictionary = {}
var _eff: Dictionary = {}                 # flat "a.b" -> value, from the matching rules (later rules win)
var _boot_done := false
var _checking := false
var _last_check := -1.0
var _t_tel := 0.0
var _t_save := 0.0
var _t_check := 0.0
var _tel_busy := false
var _tel_first := true
var _q: Array = []                        # pending telemetry events
var _q_dirty := false
var _dl_running := false
var _dl_total := 0
var _dl_done := 0
var _dl_fail: Dictionary = {}
var _dl_emit := 0.0
var _car_info: Dictionary = {}            # pack sha -> parsed car.json
var _cars_dirty := false
var _block_kind := ""
var _block_msg := ""
var _block_url := ""
var _lock: Variant = null
var _tex: Dictionary = {}
var _popups: Array = []
var _sess_full := 0
var _sess_counts: Dictionary = {}
var _last_ad_at: Dictionary = {}
var _splash_done := false
var _session_start := 0.0
var _banners_hidden := false
var _fps_hist := PackedInt32Array()
var _fps_frames := 0
var _fps_time := 0.0
var _sess_dur := 0.0
var _scene := "boot"
var _gc_done := false
var _paused_app := false
var _dev: Dictionary = {}
var _retry_scale := 1.0                   # tests shrink the download retry back-off


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_salt = SALT_HEX.hex_decode()
	_fps_hist.resize(256)
	_session_start = Time.get_ticks_msec() / 1000.0
	_load_build()
	_load_registry()
	DirAccess.make_dir_recursive_absolute(DIR + "/p")
	DirAccess.make_dir_recursive_absolute(DIR + "/cars")
	_load_state()
	_boot_server()
	if enabled:
		_late_boot.call_deferred()


# ============================================================ boot
func _load_build() -> void:
	var d: Variant = _read_json("res://data/build.json")
	if d is Dictionary:
		build = maxi(1, int((d as Dictionary).get("build", 1)))
		ver = String((d as Dictionary).get("ver", "1.0.%d" % build))


func _load_registry() -> void:
	var d: Variant = _read_json("res://data/registry.json")
	if d is Dictionary:
		for t in (d as Dictionary).get("tunables", []):
			if t is Dictionary and (t as Dictionary).has("key"):
				_reg[String(t["key"])] = t


func _boot_server() -> void:
	var path := "res://data/server.json"
	var test_ov := false
	if OS.has_feature("editor"):
		var ov := OS.get_environment("LEMOV_SERVER_JSON")      # headless tests only: the exported game ignores it
		if ov != "":
			path = ov
			test_ov = true
	var j: Variant = null
	if not test_ov and FileAccess.file_exists(FX_FILE):
		# the config that ships inside the game: server.json sealed once more with a constant key (nothing readable in the package)
		j = vault_open(FileAccess.get_file_as_string(FX_FILE).strip_edges(), sha256(FX_TAG.to_utf8_buffer()), _salt)
	if not (j is Dictionary) or (j as Dictionary).is_empty():
		j = _read_json(path)
	if not (j is Dictionary):
		return
	var sj: Dictionary = j
	if int(sj.get("v", 0)) != 2 or not bool(sj.get("enabled", false)):
		return
	var spki := Marshalls.base64_to_raw(String(sj.get("pub", "")))
	if spki.size() < 100:
		return
	var k := make_key(String(sj.get("pub", "")))
	if k == null:
		return
	var v := vault_open(String(sj.get("u", "")), spki, _salt)
	if v.is_empty():
		return
	var srcs: Array = []
	for s in v.get("src", []):
		var u := String(s)
		if _base_ok(u):
			srcs.append(u if u.ends_with("/") else u + "/")
	if srcs.is_empty():
		return
	_key = k
	_src = srcs
	var t := String(v.get("tel", "")).strip_edges()
	_tel = t.rstrip("/") if _base_ok(t) else ""
	_hk = String(v.get("hk", ""))
	enabled = true


func _base_ok(u: String) -> bool:
	if u.begins_with("https://"):
		return u.length() > 12
	return OS.has_feature("editor") and (u.begins_with("http://127.0.0.1") or u.begins_with("http://localhost"))


func _late_boot() -> void:
	await get_tree().process_frame
	_dev = _device_info()
	var cached := _load_cached_manifest()
	if cached:
		_apply(man, true)
	_boot_done = true
	var prev := int(state.get("last_build", build))
	if prev != build:
		track("update", {"from_build": prev, "seq": seq})
	state["last_build"] = build
	_unclean_check()
	_t_tel = -4.0                    # first telemetry flush ~5 s after boot
	await get_tree().create_timer(1.5).timeout
	check(true)


# ============================================================ crypto (public so tests can hit them with the golden vectors)
func make_key(spki_b64: String) -> CryptoKey:
	var pem := "-----BEGIN PUBLIC KEY-----\n"
	var i := 0
	while i < spki_b64.length():
		pem += spki_b64.substr(i, 64) + "\n"
		i += 64
	pem += "-----END PUBLIC KEY-----\n"
	var k := CryptoKey.new()
	if k.load_from_string(pem, true) != OK:
		return null
	return k


func sha256(b: PackedByteArray) -> PackedByteArray:
	var h := HashingContext.new()
	h.start(HashingContext.HASH_SHA256)
	h.update(b)
	return h.finish()


func _u32be(i: int) -> PackedByteArray:
	return PackedByteArray([(i >> 24) & 255, (i >> 16) & 255, (i >> 8) & 255, i & 255])


func hmac_hex(key: String, body: PackedByteArray) -> String:
	return _crypto.hmac_digest(HashingContext.HASH_SHA256, key.to_utf8_buffer(), body).hex_encode()


## Verifies tag, decrypts, returns the parsed JSON dictionary ({} on any failure).
func vault_open(u_b64: String, spki: PackedByteArray, salt: PackedByteArray) -> Dictionary:
	var blob := Marshalls.base64_to_raw(u_b64)
	if blob.size() < 12 + 16 + 2:
		return {}
	var key := sha256("lemov2|".to_utf8_buffer() + spki + salt)
	var nonce := blob.slice(0, 12)
	var tag := blob.slice(blob.size() - 16)
	var ct := blob.slice(12, blob.size() - 16)
	var mac := _crypto.hmac_digest(HashingContext.HASH_SHA256, key, "tag".to_utf8_buffer() + nonce + ct).slice(0, 16)
	var diff := 0
	for i in 16:
		diff |= int(mac[i]) ^ int(tag[i])
	if diff != 0:
		return {}
	var pt := PackedByteArray()
	pt.resize(ct.size())
	var pos := 0
	var blk := 0
	while pos < ct.size():
		var ks := _crypto.hmac_digest(HashingContext.HASH_SHA256, key, nonce + _u32be(blk))
		var j := 0
		while j < 32 and pos < ct.size():
			pt[pos] = int(ct[pos]) ^ int(ks[j])
			pos += 1
			j += 1
		blk += 1
	var parsed: Variant = SafeIO.parse(pt.get_string_from_utf8())
	return parsed if parsed is Dictionary else {}


func verify_sig(data: PackedByteArray, sig_b64: String, key: CryptoKey) -> bool:
	if key == null:
		return false
	var sig := Marshalls.base64_to_raw(sig_b64.strip_edges())
	if sig.size() != 256:
		return false
	return _crypto.verify(HashingContext.HASH_SHA256, sha256(data), sig, key)


func bucket_of(id: String) -> int:
	var h := id.sha256_buffer()
	return ((int(h[0]) << 24) | (int(h[1]) << 16) | (int(h[2]) << 8) | int(h[3])) % 100


# ============================================================ WHEN targeting + L10N (golden-vector tested)
static func _has(d: Dictionary, k: String) -> bool:
	return d.has(k) and d[k] != null


static func _in_nums(arr: Array, v: Variant) -> bool:
	if v == null:
		return false
	for x in arr:
		if (x is int or x is float) and absf(float(x) - float(v)) < 0.0001:
			return true
	return false


static func _any_sub(arr: Array, hay: Variant) -> bool:
	if hay == null or String(hay) == "":
		return false
	var h := String(hay).to_lower()
	for s in arr:
		if h.contains(String(s).to_lower()):
			return true
	return false


static func when_match(w: Variant, c: Dictionary) -> bool:
	if not (w is Dictionary) or (w as Dictionary).is_empty():
		return true
	var d: Dictionary = w
	if _has(d, "min_build") and not (c.get("build") != null and float(c["build"]) >= float(d["min_build"])):
		return false
	if _has(d, "max_build") and not (c.get("build") != null and float(c["build"]) <= float(d["max_build"])):
		return false
	if _has(d, "builds") and d["builds"] is Array and not (d["builds"] as Array).is_empty() and not _in_nums(d["builds"], c.get("build")):
		return false
	if _has(d, "countries") and d["countries"] is Array and not (d["countries"] as Array).is_empty():
		var cn := String(c.get("country", "")) if c.get("country") != null else ""
		var ok := false
		for x in d["countries"]:
			if cn != "" and String(x).to_upper() == cn.to_upper():
				ok = true
		if not ok:
			return false
	if _has(d, "langs") and d["langs"] is Array and not (d["langs"] as Array).is_empty():
		var lg := String(c.get("lang", "")) if c.get("lang") != null else ""
		var ok2 := false
		for x in d["langs"]:
			if lg != "" and String(x).to_lower() == lg.to_lower():
				ok2 = true
		if not ok2:
			return false
	if _has(d, "quality") and d["quality"] is Array and not (d["quality"] as Array).is_empty() and not _in_nums(d["quality"], c.get("quality")):
		return false
	if _has(d, "ram_min") and not (c.get("ram") != null and float(c["ram"]) >= float(d["ram_min"])):
		return false
	if _has(d, "ram_max") and not (c.get("ram") != null and float(c["ram"]) <= float(d["ram_max"])):
		return false
	if _has(d, "gpu") and d["gpu"] is Array and not (d["gpu"] as Array).is_empty() and not _any_sub(d["gpu"], c.get("gpu")):
		return false
	if _has(d, "dev") and d["dev"] is Array and not (d["dev"] as Array).is_empty() and not _any_sub(d["dev"], c.get("dev")):
		return false
	if _has(d, "pct") and d["pct"] is Array and (d["pct"] as Array).size() == 2:
		var b: Variant = c.get("bucket")
		if not (b != null and float(d["pct"][0]) <= float(b) and float(b) < float(d["pct"][1])):
			return false
	if _has(d, "days_min") and not (c.get("days") != null and float(c["days"]) >= float(d["days_min"])):
		return false
	if _has(d, "days_max") and not (c.get("days") != null and float(c["days"]) <= float(d["days_max"])):
		return false
	if _has(d, "lvl_min") and not (c.get("lvl") != null and float(c["lvl"]) >= float(d["lvl_min"])):
		return false
	if _has(d, "lvl_max") and not (c.get("lvl") != null and float(c["lvl"]) <= float(d["lvl_max"])):
		return false
	return true


static func l10n(v: Variant, lang: String) -> String:
	if v is String:
		return v
	if v is Dictionary:
		var d: Dictionary = v
		if d.has(lang) and String(d[lang]) != "":
			return String(d[lang])
		if d.has("en") and String(d["en"]) != "":
			return String(d["en"])
		for k in d:
			if String(d[k]) != "":
				return String(d[k])
	return ""


func text(v: Variant) -> String:
	return l10n(v, String(G.lang))


func ctx() -> Dictionary:
	var c := cc
	if c == "":
		var loc := OS.get_locale()
		c = loc.get_slice("_", 1).to_upper() if loc.contains("_") else ""
	return {"build": build, "country": c, "lang": String(G.lang), "quality": int(G.quality), "ram": _dev.get("ram", null), "gpu": _dev.get("gpu", null),
		"dev": _dev.get("dev", null), "bucket": bucket_of(iid), "days": maxi(0, (_now() - int(state.get("first_ts", _now()))) / 86400), "lvl": G.level()}


# ============================================================ state + files
func _now() -> int:
	return int(Time.get_unix_time_from_system()) + int(state.get("skew", 0))


func _read_json(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	return SafeIO.parse(FileAccess.get_file_as_string(path))


func _write_atomic(path: String, data: PackedByteArray) -> bool:
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return false
	f.store_buffer(data)
	f.close()
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)
	return DirAccess.rename_absolute(tmp, path) == OK


func _file_size(path: String) -> int:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return 0
	var n := f.get_length()
	f.close()
	return n


func _load_state() -> void:
	var d: Variant = _read_json(DIR + "/state.json")
	state = d if d is Dictionary else {}
	if not (state.get("seen_news") is Array): state["seen_news"] = []
	if not (state.get("gifts_done") is Array): state["gifts_done"] = []
	if not (state.get("inbox_done") is Array): state["inbox_done"] = []
	if not (state.get("ack") is Array): state["ack"] = []
	if not (state.get("ad") is Dictionary): state["ad"] = {}
	state["seq"] = int(state.get("seq", 0))
	seq = int(state["seq"])
	cc = String(state.get("cc", ""))
	iid = String(state.get("iid", ""))
	if iid.length() != 16 or not iid.is_valid_hex_number(false):
		iid = _crypto.generate_random_bytes(8).hex_encode()
		state["iid"] = iid
		state["first_ts"] = int(Time.get_unix_time_from_system())
		_q_push("install", {})
	if int(state.get("first_ts", 0)) <= 0:
		state["first_ts"] = int(Time.get_unix_time_from_system())
	_lock = state.get("lock", null)
	var qd: Variant = _read_json(DIR + "/q.json")
	if qd is Array:
		_q = (qd as Array).slice(maxi(0, (qd as Array).size() - 200))
	_save_state()


func _save_state() -> void:
	_write_atomic(DIR + "/state.json", JSON.stringify(state).to_utf8_buffer())
	if _q_dirty:
		_q_dirty = false
		_write_atomic(DIR + "/q.json", JSON.stringify(_q).to_utf8_buffer())


func _load_cached_manifest() -> bool:
	if not FileAccess.file_exists(DIR + "/manifest.json") or not FileAccess.file_exists(DIR + "/manifest.sig"):
		return false
	var data := FileAccess.get_file_as_bytes(DIR + "/manifest.json")
	if data.is_empty() or data.size() > MAX_MANIFEST:
		return false
	if not verify_sig(data, FileAccess.get_file_as_string(DIR + "/manifest.sig"), _key):      # re-verified on every start
		return false
	var m: Variant = SafeIO.parse(data.get_string_from_utf8())
	if not (m is Dictionary):
		return false
	man = _sanitize(m)
	return true


# ============================================================ network
func _hget(url: String, timeout: float, max_bytes: int, headers: PackedStringArray = PackedStringArray()) -> Dictionary:
	var h := HTTPRequest.new()
	h.timeout = timeout
	h.body_size_limit = max_bytes
	add_child(h)
	if h.request(url, headers) != OK:
		h.queue_free()
		return {"ok": false, "code": 0, "res": -1, "body": PackedByteArray()}
	var a: Array = await h.request_completed
	h.queue_free()
	var code: int = a[1]
	return {"ok": a[0] == HTTPRequest.RESULT_SUCCESS and code >= 200 and code < 300, "code": code, "res": a[0], "body": a[3], "headers": a[2]}


## Re-checks the server. force=true ignores the interval. Safe to call from anywhere, any time.
func check(force: bool = false) -> void:
	if not enabled or _checking:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if not force and _last_check >= 0.0 and now - _last_check < float(cfg("net.check_interval_s", 600)):
		return
	_checking = true
	_last_check = now
	var got := await _fetch_manifest()
	_checking = false
	online = got
	if got:
		state["last_ok_ts"] = _now()
		_save_state()


func _fetch_manifest() -> bool:
	for base in _src:
		var bust := "?v=%d" % randi()
		var r: Dictionary = await _hget(String(base) + "manifest.json" + bust, 8.0, MAX_MANIFEST)
		if not r["ok"]:
			continue
		var s: Dictionary = await _hget(String(base) + "manifest.sig" + bust, 8.0, 4096)
		if not s["ok"]:
			continue
		var data: PackedByteArray = r["body"]
		if not verify_sig(data, (s["body"] as PackedByteArray).get_string_from_ascii(), _key):
			push_warning("remote: manifest signature rejected (%s)" % base)
			continue
		var m: Variant = SafeIO.parse(data.get_string_from_utf8())
		if not (m is Dictionary):
			continue
		var mv := int((m as Dictionary).get("v", 0))
		if mv != 1 and mv != 2:
			continue
		var sq := int((m as Dictionary).get("seq", 0))
		if sq < int(state.get("seq", 0)):
			push_warning("remote: rollback rejected (seq %d < %d)" % [sq, int(state.get("seq", 0))])
			continue
		_write_atomic(DIR + "/manifest.json", data)
		_write_atomic(DIR + "/manifest.sig", (s["body"] as PackedByteArray))
		state["seq"] = sq
		var changed := sq != seq
		man = _sanitize(m)
		_apply(man, false)
		if changed:
			seq = sq
		return true
	return false


# ============================================================ sanitising the (already verified) manifest
static func _s(v: Variant, n: int = 200) -> String:
	return String(v).substr(0, n) if (v is String or v is int or v is float) else ""


static func _l10n_clean(v: Variant) -> Variant:
	if v is String:
		return (v as String).substr(0, 2000)
	var o := {}
	if v is Dictionary:
		for k in LANGS:
			if (v as Dictionary).has(k) and (v as Dictionary)[k] is String:
				o[k] = String((v as Dictionary)[k]).substr(0, 2000)
	return o


static func _id_ok(s: String) -> bool:
	if s.is_empty() or s.length() > 48:
		return false
	for ch in s:
		if not (ch.is_valid_identifier() or ch == "-" or ch == "." or ch == ":" or (ch >= "0" and ch <= "9")):
			return false
	return true


static func _url_ok(u: String, allow_lemov: bool = false) -> bool:
	return u.begins_with("https://") or (allow_lemov and u.begins_with("lemov://"))


static func _hex_ok(s: String, n: int = 64) -> bool:
	return s.length() == n and s.is_valid_hex_number(false) and s == s.to_lower()


static func _col(s: Variant, def: String) -> String:
	var t := String(s) if s is String else ""
	return t if t.length() == 7 and t.begins_with("#") and t.substr(1).is_valid_hex_number(false) else def


func _sanitize(m: Dictionary) -> Dictionary:
	var o: Dictionary = {"v": int(m.get("v", 2)), "seq": int(m.get("seq", 0)), "ts": int(m.get("ts", 0))}
	var a: Dictionary = m.get("app", {}) if m.get("app") is Dictionary else {}
	var apk: Dictionary = a.get("apk", {}) if a.get("apk") is Dictionary else {}
	o["app"] = {"latest_build": int(a.get("latest_build", 0)), "latest_ver": _s(a.get("latest_ver", ""), 24), "min_build": int(a.get("min_build", 0)),
		"apk": {"url": _s(apk.get("url", ""), 500) if _url_ok(_s(apk.get("url", ""), 500)) else "", "sha256": _s(apk.get("sha256", ""), 64), "size": int(apk.get("size", 0))},
		"notes": _l10n_clean(a.get("notes", {}))}
	var mt: Dictionary = m.get("maint", {}) if m.get("maint") is Dictionary else {}
	o["maint"] = {"on": bool(mt.get("on", false)), "msg": _l10n_clean(mt.get("msg", {})), "until": int(mt.get("until", 0))}
	var news: Array = []
	for n in (m.get("news", []) if m.get("news") is Array else []):
		if news.size() >= 50:
			break
		if n is Dictionary and _id_ok(_s(n.get("id", ""), 48)):
			var cars: Array = []
			for cid in (n.get("cars", []) if n.get("cars") is Array else []):
				if cars.size() < 8 and _id_ok(_s(cid, 48)):
					cars.append(_s(cid, 48))
			news.append({"id": _s(n["id"], 48), "ts": int(n.get("ts", 0)), "title": _l10n_clean(n.get("title", {})), "body": _l10n_clean(n.get("body", {})),
				"cars": cars, "img": _s(n.get("img", ""), 64) if _hex_ok(_s(n.get("img", ""), 64)) else "", "pin": bool(n.get("pin", false))})
	o["news"] = news
	var links: Array = []
	for l in (m.get("links", []) if m.get("links") is Array else []):
		if links.size() < 12 and l is Dictionary and _url_ok(_s(l.get("url", ""), 500)):
			links.append({"id": _s(l.get("id", ""), 48), "label": _l10n_clean(l.get("label", {})), "url": _s(l["url"], 500), "icon": _s(l.get("icon", "web"), 12) if ICONS.has(_s(l.get("icon", "web"), 12)) else "web"})
	o["links"] = links
	var feats := {}
	for k in (m.get("features", {}) if m.get("features") is Dictionary else {}):
		if m["features"][k] is bool:
			feats[String(k)] = m["features"][k]
	o["features"] = feats
	o["cfg"] = m.get("cfg", {}) if m.get("cfg") is Dictionary else {}
	var rules: Array = []
	for r in (m.get("rules", []) if m.get("rules") is Array else []):
		if rules.size() < 100 and r is Dictionary and r.get("set") is Dictionary:
			rules.append({"id": _s(r.get("id", ""), 48), "on": bool(r.get("on", true)), "when": r.get("when", {}) if r.get("when") is Dictionary else {}, "set": r["set"]})
	o["rules"] = rules
	var ad: Dictionary = m.get("ads", {}) if m.get("ads") is Dictionary else {}
	var items: Array = []
	for it in (ad.get("items", []) if ad.get("items") is Array else []):
		if items.size() < 50 and it is Dictionary and _id_ok(_s(it.get("id", ""), 48)):
			var places: Array = []
			for p in (it.get("place", []) if it.get("place") is Array else []):
				if ["menu", "garage", "race_end", "splash", "rewarded"].has(String(p)):
					places.append(String(p))
			var url := _s(it.get("url", ""), 500)
			var cap: Dictionary = it.get("cap", {}) if it.get("cap") is Dictionary else {}
			items.append({"id": _s(it["id"], 48), "name": _s(it.get("name", ""), 80), "on": bool(it.get("on", true)), "place": places,
				"title": _l10n_clean(it.get("title", {})), "body": _l10n_clean(it.get("body", {})), "cta": _l10n_clean(it.get("cta", {})),
				"url": url if _url_ok(url, true) else "", "img": _s(it.get("img", ""), 64) if _hex_ok(_s(it.get("img", ""), 64)) else "",
				"bg": _col(it.get("bg"), "#101018"), "fg": _col(it.get("fg"), "#ffffff"), "accent": _col(it.get("accent"), "#ff5a1f"),
				"from": int(it.get("from", 0)), "to": int(it.get("to", 0)), "w": clampf(float(it.get("w", 1)), 0.0, 100.0),
				"cap": {"session": int(cap.get("session", 0)), "day": int(cap.get("day", 0)), "gap_s": int(cap.get("gap_s", 0))},
				"dur": clampi(int(it.get("dur", 5)), 1, 30), "skip": clampi(int(it.get("skip", 3)), 0, 30), "reward": clampi(int(it.get("reward", 0)), 0, 100000),
				"when": it.get("when", {}) if it.get("when") is Dictionary else {}})
	var acfg: Dictionary = ad.get("cfg", {}) if ad.get("cfg") is Dictionary else {}
	o["ads"] = {"on": bool(ad.get("on", false)), "items": items, "cfg": {"every": maxi(1, int(acfg.get("every", 3))), "first_after_s": maxi(0, int(acfg.get("first_after_s", 120))),
		"gap_s": maxi(0, int(acfg.get("gap_s", 150))), "max_session": maxi(0, int(acfg.get("max_session", 6))), "reward_coins": clampi(int(acfg.get("reward_coins", 250)), 0, 100000),
		"reward_day_cap": maxi(0, int(acfg.get("reward_day_cap", 5))), "menu_rotate_s": clampi(int(acfg.get("menu_rotate_s", 8)), 3, 120), "splash": bool(acfg.get("splash", false))}}
	var gifts: Array = []
	for g in (m.get("gifts", []) if m.get("gifts") is Array else []):
		if gifts.size() < 30 and g is Dictionary and _id_ok(_s(g.get("id", ""), 48)):
			var msg: Dictionary = g.get("msg", {}) if g.get("msg") is Dictionary else {}
			gifts.append({"id": _s(g["id"], 48), "name": _s(g.get("name", ""), 80), "from": int(g.get("from", 0)), "to": int(g.get("to", 0)),
				"when": g.get("when", {}) if g.get("when") is Dictionary else {}, "grant": g.get("grant", null), "msg": {"title": _l10n_clean(msg.get("title", {})), "body": _l10n_clean(msg.get("body", {}))}})
	o["gifts"] = gifts
	var crow: Array = []
	for c in (m.get("cars", []) if m.get("cars") is Array else []):
		if crow.size() < 300 and c is Dictionary and _id_ok(_s(c.get("id", ""), 48)):
			crow.append(c)
	o["cars"] = crow
	var hide: Array = []
	for h in (m.get("hide_cars", []) if m.get("hide_cars") is Array else []):
		if hide.size() < 300 and _id_ok(_s(h, 48)):
			hide.append(_s(h, 48))
	o["hide_cars"] = hide
	var packs := {}
	for sha in (m.get("packs", {}) if m.get("packs") is Dictionary else {}):
		var p: Variant = m["packs"][sha]
		if _hex_ok(String(sha)) and p is Dictionary:
			var ext := _s(p.get("ext", "bin"), 8)
			var kind := _s(p.get("kind", "file"), 8)
			var size := int(p.get("size", 0))
			if size <= 0 or size > MAX_PACK or not ext.is_valid_identifier() or not ["car", "img", "map", "file"].has(kind):
				continue
			var urls: Array = []
			for u in (p.get("urls", []) if p.get("urls") is Array else []):
				if urls.size() < 4 and _url_ok(String(u)):
					urls.append(String(u))
			packs[String(sha)] = {"size": size, "ext": ext, "kind": kind, "urls": urls}
	o["packs"] = packs
	return o


# ============================================================ applying
func _apply(m: Dictionary, from_cache: bool) -> void:
	_eval_rules()
	_eval_block()
	_apply_gifts()
	_rebuild_cars()
	var un := unseen_news()
	_queue_packs()
	if not from_cache:
		if not _gc_done:
			_gc_done = true
			_gc_packs()
		manifest_applied.emit()
		ads_changed.emit()
		if not un.is_empty():
			news_ready.emit(un)
	else:
		manifest_applied.emit()


func _eval_rules() -> void:
	_eff.clear()
	var c := ctx()
	for r in man.get("rules", []):
		if bool(r["on"]) and when_match(r["when"], c):
			for k in (r["set"] as Dictionary):
				_eff[String(k)] = r["set"][k]
	cfg_rev += 1


## Re-evaluates the rules after something they target changed (quality level, language, ...).
func context_changed() -> void:
	if enabled:
		_eval_rules()


func _cfg_raw(path: String) -> Array:
	if _eff.has(path):
		return [true, _eff[path]]
	var node: Variant = man.get("cfg", {})
	for part in path.split("."):
		if node is Dictionary and (node as Dictionary).has(part):
			node = (node as Dictionary)[part]
		else:
			return [false, null]
	return [true, node]


## Effective value of a dotted path: matching rule > manifest cfg > default. Type-checked against the default and clamped by data/registry.json.
func cfg(path: String, def: Variant) -> Variant:
	if not enabled or man.is_empty():
		return def
	var raw := _cfg_raw(path)
	if not bool(raw[0]):
		return def
	var v: Variant = raw[1]
	var out: Variant = def
	match typeof(def):
		TYPE_INT:
			if v is int or v is float:
				out = int(roundf(float(v)))
			else:
				return def
		TYPE_FLOAT:
			if v is int or v is float:
				out = float(v)
			else:
				return def
		TYPE_BOOL:
			if v is bool:
				out = v
			else:
				return def
		TYPE_STRING:
			if v is String:
				out = v
			else:
				return def
		_:
			return def
	if _reg.has(path):
		var r: Dictionary = _reg[path]
		if out is int or out is float:
			if r.has("min") and r["min"] != null:
				out = maxf(float(out), float(r["min"])) if out is float else maxi(int(out), int(r["min"]))
			if r.has("max") and r["max"] != null:
				out = minf(float(out), float(r["max"])) if out is float else mini(int(out), int(r["max"]))
		elif out is String and r.has("max") and r["max"] != null:
			out = String(out).substr(0, int(r["max"]))
	return out


func feature(name: String, def: bool = true) -> bool:
	if not enabled:
		return def
	var f: Dictionary = man.get("features", {})
	return bool(f[name]) if f.has(name) else def


# ---- app / maintenance / lock
func update_info() -> Dictionary:
	var a: Dictionary = man.get("app", {})
	var lb := int(a.get("latest_build", 0))
	return {"available": lb > build, "build": lb, "ver": String(a.get("latest_ver", "")), "notes": text(a.get("notes", {})), "url": String((a.get("apk", {}) as Dictionary).get("url", ""))}


func _eval_block() -> void:
	var kind := ""
	var msg := ""
	var url := ""
	var a: Dictionary = man.get("app", {})
	var mt: Dictionary = man.get("maint", {})
	if _lock != null:
		kind = "lock"
		msg = text((_lock as Dictionary).get("msg", {})) if _lock is Dictionary else ""
	elif bool(mt.get("on", false)) and (int(mt.get("until", 0)) <= 0 or int(mt.get("until", 0)) > _now()):
		kind = "maint"
		msg = text(mt.get("msg", {}))
	elif int(a.get("min_build", 0)) > build:
		kind = "update"
		msg = text(a.get("notes", {}))
		url = String((a.get("apk", {}) as Dictionary).get("url", ""))
	_block_msg = msg
	_block_url = url
	if kind != _block_kind:
		_block_kind = kind
		if kind == "":
			unblocked.emit()
		else:
			blocked.emit(kind, msg, url)


func block_kind() -> String:
	return _block_kind


## [kind, message, url] of the active blocking screen ("" kind = none).
func block_info() -> Array:
	return [_block_kind, _block_msg, _block_url]


# ---- news / links
func unseen_news() -> Array:
	if not enabled or not feature("news"):
		return []
	var seen: Array = state["seen_news"]
	var out: Array = []
	for n in man.get("news", []):
		if not seen.has(String(n["id"])):
			out.append(n)
	out.sort_custom(func(x, y): return int(x["ts"]) > int(y["ts"]))
	return out


func all_news() -> Array:
	if not enabled or not feature("news"):
		return []
	var out: Array = (man.get("news", []) as Array).duplicate()
	out.sort_custom(func(x, y): return int(x["ts"]) > int(y["ts"]))
	return out


func pinned_news() -> Array:
	var out: Array = []
	for n in all_news():
		if bool(n["pin"]):
			out.append(n)
	return out


func mark_news_seen(id: String) -> void:
	var seen: Array = state["seen_news"]
	if not seen.has(id):
		seen.append(id)
		if seen.size() > 300:
			seen.remove_at(0)
		_save_state()


func links() -> Array:
	return (man.get("links", []) as Array) if enabled else []


func open_url(u: String) -> void:
	if u.begins_with("https://"):
		OS.shell_open(u)
	elif u.begins_with("lemov://"):
		var rest := u.substr(8)
		deeplink.emit(rest.get_slice("/", 0), rest.get_slice("/", 1) if rest.contains("/") else "")


# ============================================================ gifts / inbox
func _queue_popup(title: String, body: String) -> void:
	_popups.append([title, body])
	popup_requested.emit(title, body)


func take_popup() -> Array:
	return _popups.pop_front() if not _popups.is_empty() else []


func _apply_gifts() -> void:
	if not _boot_done and not enabled:
		return
	var now := _now()
	var c := ctx()
	var done: Array = state["gifts_done"]
	var changed := false
	for g in man.get("gifts", []):
		var id := String(g["id"])
		if done.has(id) or g["grant"] == null:
			continue
		if int(g["from"]) > 0 and now < int(g["from"]):
			continue
		if int(g["to"]) > 0 and now > int(g["to"]):
			continue
		if not when_match(g["when"], c):
			continue
		var desc: String = G.grant(g["grant"])
		done.append(id)
		changed = true
		var t := text(g["msg"]["title"])
		var b := text(g["msg"]["body"])
		_queue_popup(t if t != "" else "GIFT", (b + "\n" if b != "" else "") + desc)
	if changed:
		_save_state()


func _process_inbox(inbox: Dictionary) -> void:
	var done: Array = state["inbox_done"]
	var ack: Array = state["ack"]
	var any := false
	for m in (inbox.get("msgs", []) if inbox.get("msgs") is Array else []):
		if m is Dictionary and not done.has(String(m.get("id", ""))) and String(m.get("id", "")) != "":
			done.append(String(m["id"]))
			ack.append(String(m["id"]))
			_queue_popup(text(_l10n_clean(m.get("title", {}))), text(_l10n_clean(m.get("body", {}))))
			any = true
	for g in (inbox.get("grants", []) if inbox.get("grants") is Array else []):
		if g is Dictionary and not done.has(String(g.get("id", ""))) and String(g.get("id", "")) != "":
			done.append(String(g["id"]))
			ack.append(String(g["id"]))
			var desc: String = G.grant(g.get("grant"))
			var msg: Dictionary = g.get("msg", {}) if g.get("msg") is Dictionary else {}
			var t := text(_l10n_clean(msg.get("title", {})))
			var b := text(_l10n_clean(msg.get("body", {})))
			_queue_popup(t if t != "" else "GIFT", (b + "\n" if b != "" else "") + desc)
			any = true
	while done.size() > 400:
		done.remove_at(0)
	while ack.size() > 200:
		ack.remove_at(0)
	var lk: Variant = inbox.get("lock", null)
	var new_lock: Variant = null
	if lk is Dictionary:
		new_lock = {"msg": _l10n_clean((lk as Dictionary).get("msg", {}))}
	if JSON.stringify(new_lock) != JSON.stringify(_lock):
		_lock = new_lock
		state["lock"] = new_lock
		_eval_block()
	_save_state()
	if any:
		inbox_ready.emit()


# ============================================================ cars
func _rebuild_cars() -> void:
	if in_world:
		_cars_dirty = true
		return
	_cars_dirty = false
	var added: Array = []
	var patches: Array = []
	var remote_ok := feature("remote_cars")
	for row in man.get("cars", []):
		var id := String(row["id"])
		var pack := String(row.get("pack", ""))
		if pack != "":
			if not remote_ok:
				continue
			var info: Dictionary = _car_json(pack)
			if info.is_empty():
				continue
			var o: Dictionary = info.duplicate(true)
			_merge_row(o, row)
			o["id"] = id
			o["model"] = id
			o["path"] = "%s/cars/%s/model.glb" % [DIR, pack]
			if not PHYS_OK.has(String(o.get("phys", ""))):
				o["phys"] = "coupe"
			added.append(o)
		else:
			var p := {}
			_merge_row(p, row)
			p["id"] = id
			if p.has("phys") and not PHYS_OK.has(String(p["phys"])):
				p.erase("phys")
			patches.append(p)
	G.apply_remote_catalogue(patches, added, (man.get("hide_cars", []) as Array) if remote_ok else [])
	cars_changed.emit()


func _merge_row(o: Dictionary, row: Dictionary) -> void:
	for k in ["name", "brand", "tagline", "cls", "phys"]:
		if row.get(k) is String and String(row[k]) != "":
			o[k] = String(row[k]).substr(0, 60)
	for k in ["color", "accent"]:
		if row.get(k) is String and _col(row[k], "") != "":
			o[k] = String(row[k])
	var st: Dictionary = row.get("stats", {}) if row.get("stats") is Dictionary else {}
	for k in ["top_speed", "accel", "handling", "nitro"]:
		if st.get(k) is float or st.get(k) is int:
			o[k] = clampf(float(st[k]), 0.0, 1.0)
		elif row.get(k) is float or row.get(k) is int:
			o[k] = clampf(float(row[k]), 0.0, 1.0)
	if row.get("price") is float or row.get("price") is int:
		o["price"] = maxi(0, int(row["price"]))
	if not o.has("price"):
		o["price"] = 0


func _car_json(sha: String) -> Dictionary:
	if _car_info.has(sha):
		return _car_info[sha]
	var d: Variant = _read_json("%s/cars/%s/car.json" % [DIR, sha])
	if d is Dictionary and FileAccess.file_exists("%s/cars/%s/model.glb" % [DIR, sha]):
		var c: Dictionary = (d as Dictionary).duplicate(true)
		c.erase("path")
		c.erase("pack")
		_car_info[sha] = c
		return c
	return {}


func _install_car(sha: String) -> bool:
	var zp := pack_path(sha)
	var z := ZIPReader.new()
	if zp == "" or z.open(zp) != OK:
		return false
	var names := z.get_files()
	if not names.has("car.json") or not names.has("model.glb"):
		z.close()
		return false
	var cj: Variant = SafeIO.parse(z.read_file("car.json").get_string_from_utf8())
	var glb := z.read_file("model.glb")
	z.close()
	if not (cj is Dictionary) or glb.size() < 1024 or glb.slice(0, 4).get_string_from_ascii() != "glTF":
		return false
	var dir := "%s/cars/%s" % [DIR, sha]
	DirAccess.make_dir_recursive_absolute(dir)
	if not _write_atomic(dir + "/car.json", JSON.stringify(cj).to_utf8_buffer()) or not _write_atomic(dir + "/model.glb", glb):
		return false
	_car_info.erase(sha)
	return true


# ============================================================ packs
func pack_path(sha: String) -> String:
	var p: Dictionary = (man.get("packs", {}) as Dictionary).get(sha, {})
	if p.is_empty():
		return ""
	var path := "%s/p/%s.%s" % [DIR, sha, String(p["ext"])]
	return path if FileAccess.file_exists(path) else ""


func texture_of(sha: String) -> Texture2D:
	if sha == "":
		return null
	if _tex.has(sha):
		return _tex[sha]
	var path := pack_path(sha)
	if path == "":
		return null
	var img := Image.load_from_file(path)
	if img == null or img.is_empty():
		return null
	var t := ImageTexture.create_from_image(img)
	_tex[sha] = t
	return t


func pending_downloads() -> int:
	return _wanted().size()


func _wanted() -> Array:
	var out: Array = []
	var packs: Dictionary = man.get("packs", {})
	for kind in ["img", "car", "file", "map"]:
		for sha in packs:
			var p: Dictionary = packs[sha]
			if String(p["kind"]) != kind or FileAccess.file_exists("%s/p/%s.%s" % [DIR, sha, String(p["ext"])]):
				continue
			if kind == "car" and not feature("remote_cars"):
				continue
			if _dl_fail.get(sha, 0) >= 3:
				continue
			out.append(sha)
	return out


func _queue_packs() -> void:
	# installed car packs that were never unpacked (e.g. first run after an update)
	for sha in man.get("packs", {}):
		if String(man["packs"][sha]["kind"]) == "car" and pack_path(String(sha)) != "" and _car_json(String(sha)).is_empty():
			_install_car(String(sha))
	if _dl_running or not enabled:
		return
	if _wanted().is_empty():
		return
	_dl_running = true
	_download_loop()


func _on_wifi() -> bool:
	var other := false
	for itf in IP.get_local_interfaces():
		var nm := String(itf.get("name", "")).to_lower()
		var up := false
		for a in itf.get("addresses", []):
			var s := String(a)
			if not s.contains(":") and not s.begins_with("169.254.") and not s.begins_with("127."):
				up = true
		if not up:
			continue
		if nm.begins_with("wlan") or nm.begins_with("wifi") or nm.begins_with("eth") or nm.begins_with("en") or nm.begins_with("wl"):
			return true
		if nm.begins_with("rmnet") or nm.begins_with("ccmni") or nm.begins_with("pdp") or nm.begins_with("v4-") or nm.begins_with("usb"):
			other = true
	return not other


func _net_ok(size: int, kind: String) -> bool:
	if bool(cfg("net.cellular_ok", false)) or cellular_ok:
		return true
	if kind == "img" and size <= 524288:
		return true
	return _on_wifi()


func _download_loop() -> void:
	_dl_total = 0
	_dl_done = 0
	for sha in _wanted():
		_dl_total += int(man["packs"][sha]["size"])
	var installed_car := false
	while enabled:
		var todo := _wanted()
		if todo.is_empty():
			break
		var sha: String = todo[0]
		var p: Dictionary = man["packs"][sha]
		if in_world or not _net_ok(int(p["size"]), String(p["kind"])):
			await get_tree().create_timer(3.0).timeout
			if _wanted().is_empty() or not enabled:
				break
			continue
		var dsk := DirAccess.open("user://")
		if dsk != null and dsk.get_space_left() > 0 and dsk.get_space_left() < int(p["size"]) + 64 * 1048576:
			_dl_fail[sha] = 3
			push_warning("remote: not enough free space for pack %s" % sha)
			continue
		var ok := await _fetch_pack(sha)
		if ok:
			if String(p["kind"]) == "car":
				if _install_car(sha):
					installed_car = true
				else:
					_dl_fail[sha] = 3
					DirAccess.remove_absolute(pack_path(sha))
			elif String(p["kind"]) == "img":
				ads_changed.emit()
		else:
			_dl_fail[sha] = int(_dl_fail.get(sha, 0)) + 1
	_dl_running = false
	progress.emit(_dl_total, _dl_total, "")
	if installed_car:
		_rebuild_cars()


func _emit_progress(label: String) -> void:
	var now := Time.get_ticks_msec() / 1000.0
	if now - _dl_emit > 0.25:
		_dl_emit = now
		progress.emit(_dl_done, maxi(_dl_total, 1), label)


func _fetch_pack(sha: String) -> bool:
	var meta: Dictionary = man["packs"][sha]
	var size := int(meta["size"])
	var final_path := "%s/p/%s.%s" % [DIR, sha, String(meta["ext"])]
	var part := "%s/p/%s.part" % [DIR, sha]
	var urls: Array = (meta["urls"] as Array).duplicate()
	if urls.is_empty():
		for s in _src:
			urls.append("%sp/%s.%s" % [s, sha, String(meta["ext"])])
	var label := String(meta["kind"])
	for attempt in 3:
		for u in urls:
			if not enabled:
				return false
			if await _download_range(String(u), part, size, label):
				if await _hash_ok(part, sha):
					if FileAccess.file_exists(final_path):
						DirAccess.remove_absolute(final_path)
					return DirAccess.rename_absolute(part, final_path) == OK
				DirAccess.remove_absolute(part)          # corrupted / tampered: start over
		await get_tree().create_timer(2.0 * float(attempt + 1) * _retry_scale).timeout
	return false


func _download_range(url: String, part: String, size: int, label: String) -> bool:
	var have := _file_size(part)
	if have > size:
		DirAccess.remove_absolute(part)
		have = 0
	_dl_done += have
	while have < size:
		while in_world:
			await get_tree().create_timer(2.0).timeout
		var end := mini(have + CHUNK, size) - 1
		var r: Dictionary = await _hget(url, 25.0, CHUNK + 65536, PackedStringArray(["Range: bytes=%d-%d" % [have, end]]))
		var chunk := PackedByteArray()
		if r["ok"] and int(r["code"]) == 206:
			chunk = r["body"]
		elif (r["ok"] and int(r["code"]) == 200 and have == 0 and (r["body"] as PackedByteArray).size() == size):
			chunk = r["body"]
		elif int(r["res"]) == HTTPRequest.RESULT_BODY_SIZE_LIMIT_EXCEEDED or (r["ok"] and int(r["code"]) == 200):
			return await _download_stream(url, part, size, label)           # the host ignores Range: plain streaming download
		else:
			return false
		if chunk.is_empty() or chunk.size() > end - have + 1:
			return false
		var f := FileAccess.open(part, FileAccess.READ_WRITE if FileAccess.file_exists(part) else FileAccess.WRITE)
		if f == null:
			return false
		f.seek_end()
		f.store_buffer(chunk)
		f.close()
		have += chunk.size()
		_dl_done += chunk.size()
		_emit_progress(label)
		await get_tree().process_frame
	return have == size


func _download_stream(url: String, part: String, size: int, label: String) -> bool:
	if FileAccess.file_exists(part):
		DirAccess.remove_absolute(part)
	var h := HTTPRequest.new()
	h.download_file = part
	h.use_threads = true
	h.body_size_limit = size + 4096
	h.timeout = 0.0
	add_child(h)
	var st := [false, false]
	h.request_completed.connect(func(res: int, code: int, _hd: PackedStringArray, _bd: PackedByteArray):
		st[0] = true
		st[1] = res == HTTPRequest.RESULT_SUCCESS and code == 200)
	if h.request(url) != OK:
		h.queue_free()
		return false
	var last := 0
	var stall := 0.0
	var base := _dl_done
	while not st[0]:
		await get_tree().create_timer(0.5).timeout
		var b := h.get_downloaded_bytes()
		if b != last:
			last = b
			stall = 0.0
			_dl_done = base + b
			_emit_progress(label)
		else:
			stall += 0.5
		if stall > 30.0:
			h.cancel_request()
			break
	h.queue_free()
	return bool(st[1]) and _file_size(part) == size


func _hash_ok(path: String, want: String) -> bool:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return false
	var hc := HashingContext.new()
	hc.start(HashingContext.HASH_SHA256)
	while not f.eof_reached():
		var buf := f.get_buffer(1048576)
		if buf.is_empty():
			break
		hc.update(buf)
		await get_tree().process_frame
	f.close()
	return hc.finish().hex_encode() == want


func _gc_packs() -> void:
	var keep := {}
	for sha in man.get("packs", {}):
		keep[String(sha)] = true
	var limit := 14 * 86400
	var now := int(Time.get_unix_time_from_system())
	var d := DirAccess.open(DIR + "/p")
	if d != null:
		for f in d.get_files():
			if not keep.has(f.get_slice(".", 0)) and now - FileAccess.get_modified_time(DIR + "/p/" + f) > limit:
				DirAccess.remove_absolute(DIR + "/p/" + f)
	var cd := DirAccess.open(DIR + "/cars")
	if cd != null:
		for sub in cd.get_directories():
			if not keep.has(sub) and now - FileAccess.get_modified_time(DIR + "/cars/" + sub + "/car.json") > limit:
				for f in (DirAccess.open(DIR + "/cars/" + sub) as DirAccess).get_files():
					DirAccess.remove_absolute(DIR + "/cars/" + sub + "/" + f)
				DirAccess.remove_absolute(DIR + "/cars/" + sub)


# ============================================================ ads
func _ads() -> Dictionary:
	return man.get("ads", {})


func _ads_cfg() -> Dictionary:
	return (_ads().get("cfg", {}) as Dictionary) if not _ads().is_empty() else {}


func _day_state() -> Dictionary:
	var ad: Dictionary = state["ad"]
	var day := Time.get_date_string_from_unix_time(_now())
	if String(ad.get("day", "")) != day:
		ad["day"] = day
		ad["counts"] = {}
		ad["reward_today"] = 0
	if not (ad.get("counts") is Dictionary):
		ad["counts"] = {}
	return ad


func ads_enabled() -> bool:
	return enabled and feature("ads") and bool(_ads().get("on", false))


func banners_hidden() -> bool:
	return _banners_hidden


## One value of the ad settings block (menu_rotate_s, reward_coins, ...).
func ad_cfg(key: String, def: Variant) -> Variant:
	return _ads_cfg().get(key, def)


func hide_banners() -> void:
	_banners_hidden = true
	ads_changed.emit()


func note_race_finished() -> void:
	var ad := _day_state()
	ad["races_since_ad"] = int(ad.get("races_since_ad", 0)) + 1
	_save_state()


func _ad_candidates(place: String) -> Array:
	var now := _now()
	var c := ctx()
	var ad := _day_state()
	var counts: Dictionary = ad["counts"]
	var out: Array = []
	for it in _ads().get("items", []):
		if not bool(it["on"]) or not (it["place"] as Array).has(place):
			continue
		if int(it["from"]) > 0 and now < int(it["from"]):
			continue
		if int(it["to"]) > 0 and now > int(it["to"]):
			continue
		if not when_match(it["when"], c):
			continue
		var id := String(it["id"])
		var cap: Dictionary = it["cap"]
		if int(cap["session"]) > 0 and int(_sess_counts.get(id, 0)) >= int(cap["session"]):
			continue
		if int(cap["day"]) > 0 and int(counts.get(id, 0)) >= int(cap["day"]):
			continue
		if int(cap["gap_s"]) > 0 and now - int(_last_ad_at.get(id, 0)) < int(cap["gap_s"]):
			continue
		if String(it["img"]) != "" and pack_path(String(it["img"])) == "":
			continue                                   # creative not downloaded yet
		out.append(it)
	return out


func _resolve_ad(it: Dictionary, place: String) -> Dictionary:
	var ac := _ads_cfg()
	return {"id": it["id"], "name": it["name"], "place": place, "title": text(it["title"]), "body": text(it["body"]), "cta": text(it["cta"]), "url": it["url"],
		"tex": texture_of(String(it["img"])), "bg": Color.html(String(it["bg"])), "fg": Color.html(String(it["fg"])), "accent": Color.html(String(it["accent"])),
		"dur": int(it["dur"]), "skip": int(it["skip"]), "reward": int(it["reward"]) if int(it["reward"]) > 0 else int(ac.get("reward_coins", 0))}


## Chooses the ad to show for a placement (empty dictionary = none). Full-screen placements are rate limited globally.
func ad_pick(place: String, avoid: String = "") -> Dictionary:
	if not ads_enabled() or _block_kind != "":
		return {}
	var ac := _ads_cfg()
	var ad := _day_state()
	var now := _now()
	match place:
		"menu", "garage":
			if _banners_hidden:
				return {}
		"race_end":
			var up := Time.get_ticks_msec() / 1000.0 - _session_start
			if int(ad.get("races_since_ad", 0)) < int(ac.get("every", 3)) or up < float(ac.get("first_after_s", 120)) or now - int(ad.get("last_full_ts", 0)) < int(ac.get("gap_s", 150)) or _sess_full >= int(ac.get("max_session", 6)):
				return {}
		"splash":
			if not bool(ac.get("splash", false)) or _splash_done:
				return {}
		"rewarded":
			if not ad_reward_available():
				return {}
		_:
			return {}
	var cand := _ad_candidates(place)
	if cand.size() > 1 and avoid != "":
		var f: Array = []
		for it in cand:
			if String(it["id"]) != avoid:
				f.append(it)
		if not f.is_empty():
			cand = f
	if cand.is_empty():
		return {}
	var total := 0.0
	for it in cand:
		total += float(it["w"])
	var pick: Dictionary = cand[0]
	if total > 0.0:
		var x := randf() * total
		for it in cand:
			x -= float(it["w"])
			if x <= 0.0:
				pick = it
				break
	return _resolve_ad(pick, place)


func ad_shown(a: Dictionary, place: String) -> void:
	var id := String(a.get("id", ""))
	var ad := _day_state()
	var counts: Dictionary = ad["counts"]
	counts[id] = int(counts.get(id, 0)) + 1
	_sess_counts[id] = int(_sess_counts.get(id, 0)) + 1
	_last_ad_at[id] = _now()
	if place in ["race_end", "splash", "rewarded"]:
		ad["last_full_ts"] = _now()
		_sess_full += 1
		if place == "race_end":
			ad["races_since_ad"] = 0
		if place == "splash":
			_splash_done = true
	_save_state()
	track("ad_imp", {"ad": id, "p": place})


func ad_click(a: Dictionary, place: String) -> void:
	track("ad_click", {"ad": String(a.get("id", "")), "p": place})
	open_url(String(a.get("url", "")))


func ad_close(a: Dictionary, place: String) -> void:
	track("ad_close", {"ad": String(a.get("id", "")), "p": place})


func ad_reward_available() -> bool:
	if not ads_enabled() or not feature("rewarded"):
		return false
	var ac := _ads_cfg()
	if int(_day_state().get("reward_today", 0)) >= int(ac.get("reward_day_cap", 5)):
		return false
	return not _ad_candidates("rewarded").is_empty()


func ad_reward_done(a: Dictionary) -> void:
	var coins := int(a.get("reward", 0))
	var ad := _day_state()
	ad["reward_today"] = int(ad.get("reward_today", 0)) + 1
	if coins > 0:
		G.credits += coins
		G.save_game()
	_save_state()
	track("ad_reward", {"ad": String(a.get("id", "")), "coins": coins})


# ============================================================ telemetry
func track(ev: String, data: Dictionary = {}) -> void:
	if not enabled or _tel == "" or _hk == "" or not G.telemetry or not feature("telemetry"):
		return
	if ev == "crash" and not feature("crash_reports"):
		return
	_q_push(ev, data)


func crash(txt: String) -> void:
	track("crash", {"text": txt.substr(0, 3800)})


static func _ev_ok(s: String) -> bool:
	for ch in s:
		if not ((ch >= "a" and ch <= "z") or (ch >= "0" and ch <= "9") or ch == "_"):
			return false
	return true


func _q_push(ev: String, data: Dictionary) -> void:
	if ev.length() < 1 or ev.length() > 24 or not _ev_ok(ev):
		return
	var lim := 4096 if ev == "crash" else 1024
	if JSON.stringify(data).length() > lim:
		return
	_q.append({"n": ev, "t": _now(), "d": data})
	while _q.size() > 200:
		_q.remove_at(0)
	_q_dirty = true


func _device_info() -> Dictionary:
	var ram := 0
	if OS.has_method("get_memory_info"):
		ram = int(int((OS.get_memory_info() as Dictionary).get("physical", 0)) / 1048576)
	var ws := DisplayServer.window_get_size()
	return {"os": "%s %s" % [OS.get_name(), OS.get_version()], "dev": OS.get_model_name(), "gpu": RenderingServer.get_video_adapter_name(), "ram": ram if ram > 0 else null, "scr": "%dx%d" % [ws.x, ws.y]}


func _sample_stats() -> Dictionary:
	if _fps_frames < 30 or _fps_time <= 0.0:
		return {}
	var need := int(ceil(float(_fps_frames) * 0.01))
	var acc := 0
	var ms := 1
	for i in range(255, 0, -1):
		acc += _fps_hist[i]
		if acc >= need:
			ms = i
			break
	return {"avg": float(_fps_frames) / _fps_time, "p1": 1000.0 / float(maxi(ms, 1))}


func _reset_fps() -> void:
	_fps_hist.fill(0)
	_fps_frames = 0
	_fps_time = 0.0


func _flush_session() -> void:
	if _sess_dur >= 20.0:
		var d := {"dur_s": int(_sess_dur), "q": int(G.quality), "car": String(G.cars[clampi(G.selected_car, 0, G.cars.size() - 1)]["id"]) if not G.cars.is_empty() else ""}
		var s := _sample_stats()
		if not s.is_empty():
			d["avg_fps"] = int(roundf(float(s["avg"])))
			d["p1_fps"] = int(roundf(float(s["p1"])))
		track("session", d)
		_sess_dur = 0.0
		_reset_fps()


## Sends queued events (and receives the inbox). Never blocks: the HTTP request runs in the background.
func flush_telemetry(force: bool = false) -> void:
	if not enabled or _tel == "" or _hk == "" or _tel_busy or not G.telemetry or not feature("telemetry"):
		return
	if not force and not _tel_first and _q.is_empty() and (state["ack"] as Array).is_empty() and _t_tel < float(cfg("net.tel_interval_s", 60)) * 3.0:
		return
	_tel_busy = true
	_flush_session()
	var batch: Array = []
	var body := ""
	var ack: Array = (state["ack"] as Array).duplicate()
	var prof: Dictionary = G.profile()
	var base := {"iid": iid, "b": build, "v": ver, "os": String(_dev.get("os", "")), "dev": String(_dev.get("dev", "")), "gpu": String(_dev.get("gpu", "")), "q": int(G.quality),
		"lang": String(G.lang), "scr": String(_dev.get("scr", "")), "ts": _now(), "prof": prof}
	if _dev.get("ram") != null:
		base["ram"] = int(_dev["ram"])
	if not ack.is_empty():
		base["ack"] = ack.slice(0, 40)
	for ev in _q:
		if batch.size() >= 40:
			break
		batch.append(ev)
		base["ev"] = batch
		if JSON.stringify(base).length() > 15500:
			batch.pop_back()
			base["ev"] = batch
			break
	base["ev"] = batch
	body = JSON.stringify(base)
	var raw := body.to_utf8_buffer()
	var h := HTTPRequest.new()
	h.timeout = 8.0
	h.body_size_limit = 262144
	add_child(h)
	var headers := PackedStringArray(["Content-Type: application/json", "X-S: " + hmac_hex(_hk, raw)])
	if h.request_raw(_tel + "/e", headers, HTTPClient.METHOD_POST, raw) != OK:
		h.queue_free()
		_tel_busy = false
		return
	_t_tel = 0.0
	_tel_first = false
	var a: Array = await h.request_completed
	h.queue_free()
	_tel_busy = false
	if a[0] != HTTPRequest.RESULT_SUCCESS or int(a[1]) != 200:
		if int(a[1]) == 400 and not batch.is_empty():
			_q = _q.slice(batch.size())                   # a poisoned batch must not block the queue forever
			_q_dirty = true
		return
	var j: Variant = SafeIO.parse((a[3] as PackedByteArray).get_string_from_utf8())
	if not (j is Dictionary) or not bool((j as Dictionary).get("ok", false)):
		return
	_q = _q.slice(batch.size())
	_q_dirty = true
	for id in ack:
		(state["ack"] as Array).erase(id)
	if (j as Dictionary).get("t") is float or (j as Dictionary).get("t") is int:
		state["skew"] = int((j as Dictionary)["t"]) - int(Time.get_unix_time_from_system())
	var ncc := String((j as Dictionary).get("cc", ""))
	if ncc.length() == 2 and ncc != cc:
		cc = ncc.to_upper()
		state["cc"] = cc
		context_changed()
	if (j as Dictionary).get("inbox") is Dictionary:
		_process_inbox((j as Dictionary)["inbox"])
	_save_state()


# ============================================================ lifecycle
func set_scene(name: String) -> void:
	_scene = name
	_unclean_mark()


func set_world(on: bool) -> void:
	if in_world == on:
		return
	in_world = on
	if not on:
		var s := _sample_stats()
		if not s.is_empty():
			track("perf", {"q": int(G.quality), "fps_avg": int(roundf(float(s["avg"]))), "fps_p1": int(roundf(float(s["p1"]))), "scale": snappedf(G.res_scale, 0.01)})
		if _cars_dirty:
			_rebuild_cars()
		_queue_packs()
	set_scene("world" if on else "menu")


func _unclean_check() -> void:
	var p := DIR + "/running.flag"
	if FileAccess.file_exists(p):
		var d: Variant = SafeIO.parse(FileAccess.get_file_as_string(p))
		if d is Dictionary:
			track("unclean", {"last_scene": String((d as Dictionary).get("s", "?")).substr(0, 24), "q": int((d as Dictionary).get("q", 0))})
	_unclean_mark()


func _unclean_mark() -> void:
	if not enabled or _paused_app:
		return
	var f := FileAccess.open(DIR + "/running.flag", FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify({"s": _scene, "q": int(G.quality)}))
		f.close()


func _unclean_clear() -> void:
	if FileAccess.file_exists(DIR + "/running.flag"):
		DirAccess.remove_absolute(DIR + "/running.flag")


func _notification(what: int) -> void:
	if not enabled:
		return
	match what:
		NOTIFICATION_APPLICATION_PAUSED:
			_paused_app = true
			_unclean_clear()
			_flush_session()
			_save_state()
			flush_telemetry(true)
		NOTIFICATION_APPLICATION_RESUMED:
			_paused_app = false
			_unclean_mark()
			check(false)
		NOTIFICATION_WM_CLOSE_REQUEST, NOTIFICATION_WM_GO_BACK_REQUEST:
			_unclean_clear()
			_flush_session()
			_save_state()
			flush_telemetry(true)


func _process(dt: float) -> void:
	if not enabled or not _boot_done:
		return
	dt = minf(dt, 1.0)
	_sess_dur += dt
	if in_world:
		_fps_frames += 1
		_fps_time += dt
		_fps_hist[clampi(int(dt * 1000.0), 0, 255)] += 1
	_t_tel += dt
	_t_save += dt
	_t_check += dt
	if _t_save > 15.0:
		_t_save = 0.0
		if _q_dirty:
			_write_atomic(DIR + "/q.json", JSON.stringify(_q).to_utf8_buffer())
			_q_dirty = false
	var gap := 60.0 if _block_kind == "maint" else float(cfg("net.check_interval_s", 600))
	if _t_check > gap:
		_t_check = 0.0
		if menu_active and not in_world:
			check(true)
	if _t_tel >= float(cfg("net.tel_interval_s", 60)) and not _q.is_empty():
		flush_telemetry()
	elif _tel_first and _t_tel >= 0.0 and _boot_done:
		flush_telemetry(true)
