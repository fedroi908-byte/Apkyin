extends Node

var gw: GameWorld
var p: Vehicle
var cam: Camera3D
var mode := "day"
var out := "/home/claude/ps.png"
var frames := 0
var last := 40
var dbg := 0
var fwd := Vector3.FORWARD


func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	mode = a[0] if a.size() > 0 else "day"
	out = a[1] if a.size() > 1 else out
	G.mode = "free"
	G.start_hour = 21.0 if mode.begins_with("night") else 11.0
	G.dyn_res = false
	last = int(a[2]) if a.size() > 2 else 40
	if a.size() > 3:
		G.quality = int(a[3])
	dbg = int(a[4]) if a.size() > 4 else 0
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)


func _process(_dt: float) -> void:
	frames += 1
	if frames == 3:
		p = gw.player
		gw.props.build_all_near(p.global_position, 1)
		gw.blds.mat.set_shader_parameter("dbg", dbg)
		cam = Camera3D.new()
		cam.far = 3000.0
		cam.near = 0.2
		cam.fov = 70.0
		add_child(cam)
		cam.current = true
	if p == null:
		return
	p.in_gas = 0.0
	p.in_brake = 1.0
	fwd = p.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	if frames == 5 and mode.ends_with("geyser"):
		var gp := p.global_position + fwd * 9.0
		gp.y = W.ground_height(gp.x, gp.z, gp.y + 2.0)
		gw.props.start_geyser(gp)
	cam.global_position = p.global_position - fwd * 7.0 + Vector3(0.0, 3.2, 0.0)
	cam.look_at(p.global_position + fwd * 28.0 + Vector3(0.0, 1.5, 0.0), Vector3.UP)
	if frames == last:
		var img := get_viewport().get_texture().get_image()
		img.save_png(out)
		print("SHOT saved ", out, " ", img.get_size())
		get_tree().quit()
