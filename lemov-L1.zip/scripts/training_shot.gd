extends Node
## Developer tool: training hall screenshot. args: x y z yaw_deg pitch_deg out.png [station] [hour]
var gw: GameWorld
var cam: Camera3D
var frames := 0
var a: PackedStringArray


func _ready() -> void:
	a = OS.get_cmdline_user_args()
	G.mode = "free" if a.size() > 8 and a[8] == "free" else "training"
	G.start_hour = float(a[7]) if a.size() > 7 else 11.0
	G.dyn_res = false                                   # software GL is slow: the governor would drop the render scale to 55 % (blurry shots)
	if a.size() > 9:
		G.quality = int(a[9])
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)


func _process(_dt: float) -> void:
	frames += 1
	if frames == 3:
		if gw.hall:
			gw.hall.go_station(int(a[6]) if a.size() > 6 else 0)
	if frames == 8:
		cam = Camera3D.new()
		cam.far = 6000.0
		cam.near = 0.2
		cam.fov = 70.0
		add_child(cam)
		cam.global_position = Vector3(float(a[0]), float(a[1]), float(a[2]))
		cam.rotation = Vector3(deg_to_rad(float(a[4])), deg_to_rad(float(a[3])), 0.0)
		cam.current = true
		get_viewport().scaling_3d_scale = 1.0
	var rel := a.size() > 10 and a[10] == "rel"
	var relpos := a.size() > 10 and a[10] == "relpos"          # camera = player + (x,y,z), fixed yaw/pitch
	if relpos and frames >= 9 and frames < 60 and frames % 4 == 1:
		cam.global_position = gw.player.global_position + Vector3(float(a[0]), float(a[1]), float(a[2]))
		cam.rotation = Vector3(deg_to_rad(float(a[4])), deg_to_rad(float(a[3])), 0.0)
		cam.current = true
	if frames >= 9 and frames < 60 and frames % 4 == 1:
		var k := (frames - 9) / 4                                   # rel mode: 3 orbit views around the player (offset x z rotated by 120 deg)
		if rel:
			var pp := gw.player.global_position + Vector3(0, 0.8, 0)
			var off := Vector3(float(a[0]), float(a[1]), float(a[2])).rotated(Vector3.UP, k * TAU / 3.0)
			cam.global_position = pp + off
			cam.look_at(pp, Vector3.UP)
		elif not relpos:
			cam.global_position = Vector3(float(a[0]), float(a[1]), float(a[2]))
			cam.rotation = Vector3(deg_to_rad(float(a[4])), deg_to_rad(float(a[3])), 0.0)
		cam.current = true
	if rel and frames >= 12 and frames % 4 == 0 and frames <= 20:
		var k2 := (frames - 12) / 4
		get_viewport().get_texture().get_image().save_png(String(a[5]).replace(".png", "_%d.png" % k2))
		if frames == 20:
			print("SHOT saved ", a[5])
			get_tree().quit()
	if not rel and frames == 20:
		var img := get_viewport().get_texture().get_image()
		img.save_png(a[5])
		print("SHOT saved ", a[5])
		get_tree().quit()
