class_name TrainingHall
extends Node3D
## "Mashq zali" (training hall) on the airport runway. Everything faces east (+x); +z is the car's right-hand side.
## Stations: drag strip, slalom, brake test, jump ramp, drift circle. No physics bodies: the cones are tiny scripted
## bodies and the ramp is a height patch registered in W.ramps (the wheels read W.ground_height, not colliders).

const LANE_R := 2915.0
const LANE_C := 2900.0
const LANE_L := 2885.0
const DRAG_X := -3430.0
const DRAG_LEN := 1000.0
const SL_X := -3400.0
const SL_N := 14
const SL_GAP := 18.0
const SL_FIRST := 25.0
const BR_X := -3440.0
const BR_GATE := -2900.0
const BR_ZONE := 330.0
const RAMP_X := -2300.0
const RAMP_L := 14.0
const RAMP_W := 10.0
const RAMP_H := 2.3
const DR_C := Vector2(-1820.0, 2900.0)
const DR_IN := 8.0
const DR_OUT := 22.0
const DR_TIME := 60.0
const SAVE_PATH := "user://training.json"
const NAMES := ["DRAG", "SLALOM", "BRAKE", "JUMP", "DRIFT"]
const COLS := [Color(0.10, 0.82, 1.0), Color(0.30, 0.95, 0.45), Color(1.0, 0.35, 0.30), Color(1.0, 0.82, 0.25), Color(0.85, 0.45, 1.0)]

var gw: GameWorld
var ry := 19.89
var cur := 0
var best := {}
var head_l: Label
var body_l: Label
var big_l: Label
var _big_tw: Tween
var _ui_t := 0.0
var _sfx_t := 0.0
var _newrec := false
var _pp := Vector3.ZERO                 # car position one physics step ago (line-crossing tests)
var _st: SurfaceTool
# drag
var d_state := 0                        # 0 idle, 1 staged, 2 running, 3 finished
var d_t := 0.0
var d_x0 := 0.0
var d100 := -1.0
var d200 := -1.0
var d402 := -1.0
var v402 := 0.0
var d1000 := -1.0
var v1000 := 0.0
var d_msg := ""
# slalom
var s_state := 0                        # 0 ready, 1 running, 2 finished
var s_t := 0.0
var s_total := -1.0
var s_msg := ""
# brake
var b_state := 0                        # 0 waiting, 1 braking, 2 done
var b_v := 0.0
var b_d := -1.0
var b_g := 0.0
var b_msg := ""
# jump
var j_state := 0                        # 0 idle, 1 in the air, 2 landed
var j_from := Vector3.ZERO
var j_t := 0.0
var j_v := 0.0
var j_top := 0.0
var j_dist := -1.0
# drift
var f_state := 0                        # 0 idle, 1 running, 2 finished
var f_t := 0.0
var f_score := 0.0
var f_combo := 1.0
var f_hold := 0.0
var f_out := 0.0
var f_last := -1.0
# cones (parallel arrays)
var c_home := PackedVector3Array()
var c_pos := PackedVector3Array()
var c_vel := PackedVector3Array()
var c_spin := PackedVector3Array()
var c_bas: Array[Basis] = []
var c_state := PackedInt32Array()       # 0 standing, 1 flying, 2 lying
var c_grp := PackedInt32Array()         # 1 slalom, 2 drift pivot ring
var c_hit := PackedByteArray()
var mm_a: MultiMesh
var mm_b: MultiMesh
var mm_c: MultiMesh


static func spawn_of(i: int) -> Vector2:
	match i:
		0:
			return Vector2(DRAG_X - 2.0, LANE_R)
		1:
			return Vector2(SL_X - 40.0, LANE_L)
		2:
			return Vector2(BR_X, LANE_C)
		3:
			return Vector2(RAMP_X - 170.0, LANE_R)
	return Vector2(DR_C.x - 100.0, DR_C.y)


## Where the car appears when the hall opens (GameWorld asks before the car exists).
static func start_pos() -> Vector3:
	var s := spawn_of(0)
	return Vector3(s.x, W.ground_height(s.x, s.y) + 0.15, s.y)


func setup(g: GameWorld) -> void:
	gw = g
	ry = W.ground_height(DRAG_X, LANE_C)
	_load_best()
	W.ramps.clear()
	_st = SurfaceTool.new()
	_st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_marks_drag()
	_marks_slalom()
	_marks_brake()
	_marks_jump()
	_marks_drift()
	_commit_marks()
	_build_ramp()
	_build_cones()
	_build_ui()
	gw.atmo.set_weather(0.0)
	gw.audio.play_track("music_electro")
	_pp = gw.player.global_position
	_refresh()
	gw.hud.toast("TRAINING HALL")


func _exit_tree() -> void:
	W.ramps.clear()


# ------------------------------------------------------------------ saved bests
func _load_best() -> void:
	best = {}
	var j: Variant = SafeIO.read_json(SAVE_PATH)
	if j is Dictionary:
		best = j


func _save_best() -> void:
	SafeIO.write_json(SAVE_PATH, best)


## Stores a personal best; returns true when it is one.
func _rec(key: String, v: float, lower_better: bool) -> bool:
	var old := float(best.get(key, -1.0))
	var better := old < 0.0 or (v < old if lower_better else v > old)
	if better:
		best[key] = v
		_save_best()
		_newrec = true
	return better


# ------------------------------------------------------------------ painted marks (one unshaded mesh, one draw call)
func _q(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color) -> void:
	_st.set_color(col)
	_st.add_vertex(a)
	_st.add_vertex(b)
	_st.add_vertex(c)
	_st.add_vertex(a)
	_st.add_vertex(c)
	_st.add_vertex(d)


func _flat(x0: float, x1: float, z0: float, z1: float, col: Color) -> void:
	var y := ry + 0.06
	_q(Vector3(x0, y, z0), Vector3(x1, y, z0), Vector3(x1, y, z1), Vector3(x0, y, z1), col)


## Paint lying on the ramp slope.
func _slope(xa: float, xb: float, za: float, zb: float, col: Color) -> void:
	var ya := ry + RAMP_H * (xa - RAMP_X) / RAMP_L + 0.05
	var yb := ry + RAMP_H * (xb - RAMP_X) / RAMP_L + 0.05
	_q(Vector3(xa, ya, za), Vector3(xb, yb, za), Vector3(xb, yb, zb), Vector3(xa, ya, zb), col)


func _checker(x0: float, z0: float, nx: int, nz: int, s: float) -> void:
	for i in nx:
		for k in nz:
			var col := Color(0.95, 0.95, 0.95) if (i + k) % 2 == 0 else Color(0.05, 0.05, 0.05)
			_flat(x0 + float(i) * s, x0 + float(i + 1) * s, z0 + float(k) * s, z0 + float(k + 1) * s, col)


func _ring(r0: float, r1: float, col: Color, n: int, dashed: bool) -> void:
	var y := ry + 0.06
	for k in n:
		if dashed and k % 2 == 1:
			continue
		var a0 := TAU * float(k) / float(n)
		var a1 := TAU * float(k + 1) / float(n)
		var p0 := Vector3(DR_C.x + cos(a0) * r0, y, DR_C.y + sin(a0) * r0)
		var p1 := Vector3(DR_C.x + cos(a0) * r1, y, DR_C.y + sin(a0) * r1)
		var p2 := Vector3(DR_C.x + cos(a1) * r1, y, DR_C.y + sin(a1) * r1)
		var p3 := Vector3(DR_C.x + cos(a1) * r0, y, DR_C.y + sin(a1) * r0)
		_q(p0, p1, p2, p3, col)


func _sign(text: String, pos: Vector3, px: float, col: Color) -> void:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.font_size = 64
	l.pixel_size = px
	l.outline_size = 14
	l.modulate = col
	l.outline_modulate = Color(0, 0, 0, 0.9)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.shaded = false
	l.double_sided = true
	add_child(l)


func _marks_drag() -> void:
	var white := Color(0.92, 0.92, 0.92)
	var yel := Color(1.0, 0.82, 0.2)
	var z0 := LANE_R - 6.0
	var z1 := LANE_R + 6.0
	_flat(DRAG_X, DRAG_X + DRAG_LEN, z0 - 0.1, z0 + 0.1, white)
	_flat(DRAG_X, DRAG_X + DRAG_LEN, z1 - 0.1, z1 + 0.1, white)
	_flat(DRAG_X - 0.15, DRAG_X + 0.15, z0, z1, Color(0.2, 1.0, 0.4))
	_flat(DRAG_X - 2.4, DRAG_X - 2.1, z0, z1, white)
	for k in range(1, 10):
		var x := DRAG_X + 100.0 * float(k)
		_flat(x - 0.15, x + 0.15, z0, z1, yel)
		if k % 2 == 0 or k == 1:
			_sign("%d" % (k * 100), Vector3(x, ry + 3.0, z1 + 3.0), 0.02, yel)
	var q := DRAG_X + 402.3
	_flat(q - 0.3, q + 0.3, z0, z1, Color(1.0, 0.3, 0.25))
	_sign("1/4 MILE", Vector3(q, ry + 3.5, z1 + 3.0), 0.022, Color(1.0, 0.4, 0.35))
	_checker(DRAG_X + DRAG_LEN - 1.0, z0, 2, 12, 1.0)
	_sign("FINISH", Vector3(DRAG_X + DRAG_LEN, ry + 3.5, z1 + 3.0), 0.022, Color.WHITE)
	_sign("DRAG STRIP  1000 m", Vector3(DRAG_X + 6.0, ry + 7.0, LANE_R), 0.03, COLS[0])


func _marks_slalom() -> void:
	var white := Color(0.92, 0.92, 0.92)
	var fin := SL_X + SL_FIRST + SL_GAP * float(SL_N - 1) + 30.0
	var z0 := LANE_L - 8.0
	var z1 := LANE_L + 8.0
	_flat(SL_X - 40.0, fin + 10.0, z0 - 0.1, z0 + 0.1, white)
	_flat(SL_X - 40.0, fin + 10.0, z1 - 0.1, z1 + 0.1, white)
	_flat(SL_X - 0.2, SL_X + 0.2, z0, z1, Color(0.2, 1.0, 0.4))
	_checker(fin - 1.0, z0, 2, 16, 1.0)
	_sign("SLALOM", Vector3(SL_X + 6.0, ry + 7.0, LANE_L), 0.03, COLS[1])
	_sign("START", Vector3(SL_X, ry + 3.5, z0 - 3.0), 0.022, Color(0.3, 1.0, 0.45))
	_sign("FINISH", Vector3(fin, ry + 3.5, z0 - 3.0), 0.022, Color.WHITE)


func _marks_brake() -> void:
	var white := Color(0.92, 0.92, 0.92)
	var yel := Color(1.0, 0.82, 0.2)
	var z0 := LANE_C - 6.5
	var z1 := LANE_C + 6.5
	_flat(BR_X, BR_GATE + BR_ZONE, z0 - 0.1, z0 + 0.1, white)
	_flat(BR_X, BR_GATE + BR_ZONE, z1 - 0.1, z1 + 0.1, white)
	_checker(BR_GATE - 1.0, z0, 2, 13, 1.0)
	for k in range(1, 34):
		var x := BR_GATE + 10.0 * float(k)
		if k % 5 == 0:
			_flat(x - 0.15, x + 0.15, z0, z1, yel)
			_sign("%d m" % (k * 10), Vector3(x, ry + 3.0, z1 + 3.0), 0.02, yel)
		else:
			_flat(x - 0.08, x + 0.08, z0, z0 + 1.5, white)
			_flat(x - 0.08, x + 0.08, z1 - 1.5, z1, white)
	_sign("BRAKE GATE", Vector3(BR_GATE, ry + 5.0, LANE_C), 0.026, Color(1.0, 0.35, 0.3))
	_sign("BRAKE TEST", Vector3(BR_X + 6.0, ry + 7.0, LANE_C), 0.03, COLS[2])


func _marks_jump() -> void:
	var white := Color(0.92, 0.92, 0.92)
	var yel := Color(1.0, 0.82, 0.2)
	var z0 := LANE_R - 6.0
	var z1 := LANE_R + 6.0
	var lip := RAMP_X + RAMP_L
	_flat(RAMP_X - 175.0, lip + 150.0, z0 - 0.1, z0 + 0.1, white)
	_flat(RAMP_X - 175.0, lip + 150.0, z1 - 0.1, z1 + 0.1, white)
	for k in range(1, 15):
		var x := lip + 10.0 * float(k)
		if k % 5 == 0:
			_flat(x - 0.15, x + 0.15, z0, z1, yel)
		else:
			_flat(x - 0.08, x + 0.08, z0, z0 + 1.5, white)
			_flat(x - 0.08, x + 0.08, z1 - 1.5, z1, white)
		if k % 2 == 0:
			_sign("%d m" % (k * 10), Vector3(x, ry + 3.0, z1 + 3.0), 0.02, yel)
	var rz0 := LANE_R - RAMP_W * 0.5
	var rz1 := LANE_R + RAMP_W * 0.5
	_slope(RAMP_X, lip, rz0, rz0 + 0.35, yel)
	_slope(RAMP_X, lip, rz1 - 0.35, rz1, yel)
	for k in 6:
		var xa := RAMP_X + 1.5 + 2.2 * float(k)
		_slope(xa, xa + 0.9, rz0 + 0.35, rz1 - 0.35, yel)
	_slope(lip - 0.5, lip, rz0, rz1, Color(1.0, 1.0, 0.85))
	_sign("JUMP RAMP", Vector3(RAMP_X - 60.0, ry + 7.0, LANE_R), 0.03, COLS[3])


func _marks_drift() -> void:
	_ring(DR_IN - 0.12, DR_IN + 0.12, Color(1.0, 0.5, 0.1), 72, false)
	_ring(DR_OUT - 0.2, DR_OUT + 0.2, Color(0.2, 0.85, 1.0), 96, false)
	_ring(14.6, 15.0, Color(0.92, 0.92, 0.92), 96, true)
	_sign("DRIFT CIRCLE", Vector3(DR_C.x, ry + 9.0, DR_C.y), 0.03, COLS[4])


func _commit_marks() -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = _st.commit()
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


# ------------------------------------------------------------------ jump ramp (visual; the physics is W.ramps)
func _build_ramp() -> void:
	var x0 := RAMP_X
	var x1 := RAMP_X + RAMP_L
	var z0 := LANE_R - RAMP_W * 0.5
	var z1 := LANE_R + RAMP_W * 0.5
	W.ramps.append([x0, x1, z0, z1, RAMP_H])
	var a := Vector3(x0, ry, z0)
	var b := Vector3(x0, ry, z1)
	var c := Vector3(x1, ry + RAMP_H, z1)
	var d := Vector3(x1, ry + RAMP_H, z0)
	var e := Vector3(x1, ry, z0)
	var f := Vector3(x1, ry, z1)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_smooth_group(-1)
	for v in [a, c, d, a, b, c, a, d, e, b, f, c, e, c, f, e, d, c]:
		st.add_vertex(v)
	st.generate_normals()
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.46, 0.48, 0.52)
	m.roughness = 0.8
	m.metallic = 0.15
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = m
	add_child(mi)


# ------------------------------------------------------------------ cones
func _add_cone(x: float, z: float, grp: int) -> void:
	var p := Vector3(x, W.ground_height(x, z), z)
	c_home.append(p)
	c_pos.append(p)
	c_vel.append(Vector3.ZERO)
	c_spin.append(Vector3.ZERO)
	c_bas.append(Basis())
	c_state.append(0)
	c_grp.append(grp)
	c_hit.append(0)


func _mat(col: Color, emis: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.55
	m.emission_enabled = true
	m.emission = col
	m.emission_energy_multiplier = emis
	return m


func _mm(mesh: Mesh, mat: Material, n: int) -> MultiMesh:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = n
	mm.custom_aabb = AABB(Vector3(-3500.0, ry - 2.0, 2840.0), Vector3(2000.0, 14.0, 120.0))
	var inst := MultiMeshInstance3D.new()
	inst.multimesh = mm
	inst.material_override = mat
	inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(inst)
	return mm


func _build_cones() -> void:
	for i in SL_N:
		_add_cone(SL_X + SL_FIRST + SL_GAP * float(i), LANE_L, 1)
	for k in 12:
		var a := TAU * float(k) / 12.0
		_add_cone(DR_C.x + cos(a) * (DR_IN - 1.2), DR_C.y + sin(a) * (DR_IN - 1.2), 2)
	var body := CylinderMesh.new()
	body.top_radius = 0.03
	body.bottom_radius = 0.17
	body.height = 0.72
	body.radial_segments = 10
	body.rings = 1
	var band := CylinderMesh.new()
	band.top_radius = 0.100
	band.bottom_radius = 0.123
	band.height = 0.12
	band.radial_segments = 10
	band.rings = 1
	var base := BoxMesh.new()
	base.size = Vector3(0.44, 0.04, 0.44)
	var n := c_pos.size()
	mm_a = _mm(body, _mat(Color(1.0, 0.36, 0.04), 0.35), n)
	mm_b = _mm(band, _mat(Color(0.95, 0.95, 0.95), 0.3), n)
	mm_c = _mm(base, _mat(Color(0.12, 0.12, 0.13), 0.0), n)
	for i in n:
		_set_cone(i)


func _set_cone(i: int) -> void:
	var xf := Transform3D(c_bas[i], c_pos[i])
	mm_a.set_instance_transform(i, xf * Transform3D(Basis(), Vector3(0.0, 0.40, 0.0)))
	mm_b.set_instance_transform(i, xf * Transform3D(Basis(), Vector3(0.0, 0.36, 0.0)))
	mm_c.set_instance_transform(i, xf * Transform3D(Basis(), Vector3(0.0, 0.02, 0.0)))


func _reset_grp(g: int) -> void:
	for i in c_pos.size():
		if c_grp[i] == g:
			c_pos[i] = c_home[i]
			c_vel[i] = Vector3.ZERO
			c_spin[i] = Vector3.ZERO
			c_bas[i] = Basis()
			c_state[i] = 0
			c_hit[i] = 0
			_set_cone(i)


func _count_hits(g: int) -> int:
	var n := 0
	for i in c_pos.size():
		if c_grp[i] == g and c_hit[i] == 1:
			n += 1
	return n


func _cones_step(car: Vehicle, dt: float) -> void:
	var inv := car.global_transform.affine_inverse()
	var hx := 1.0
	var hz := 2.3
	if car._hull_pts.size() > 1:
		var hp: Vector3 = car._hull_pts[1]
		hx = hp.x + 0.15
		hz = hp.z + 0.15
	var cp := car.global_position
	for i in c_pos.size():
		var st := c_state[i]
		if st == 2:
			continue
		if st == 0:
			var p := c_pos[i]
			var dx := p.x - cp.x
			var dz := p.z - cp.z
			if dx * dx + dz * dz > 100.0:
				continue
			var l := inv * p
			if absf(l.x) < hx + 0.17 and absf(l.z) < hz + 0.17 and l.y > -0.3 and l.y < 1.6:
				_hit(i, car)
			else:
				continue
		_fly(i, dt)
		_set_cone(i)


func _hit(i: int, car: Vehicle) -> void:
	c_hit[i] = 1
	c_state[i] = 1
	var v := car.linear_velocity
	var sp := v.length()
	var dir := c_pos[i] - car.global_position
	dir.y = 0.0
	dir = dir.normalized() if dir.length() > 0.01 else car.flat_forward()
	c_vel[i] = (v * 0.55).limit_length(22.0) + dir * 1.5 + Vector3(0.0, 2.0 + minf(sp * 0.10, 5.0), 0.0)
	var ax := Vector3(randf_range(-1.0, 1.0), randf_range(-0.3, 0.3), randf_range(-1.0, 1.0))
	c_spin[i] = ax.normalized() * (3.0 + sp * 0.5)
	if _sfx_t <= 0.0:
		_sfx_t = 0.12
		gw.audio.one_shot("bump", -12.0, randf_range(1.3, 1.7))


func _fly(i: int, dt: float) -> void:
	var v := c_vel[i]
	var p := c_pos[i]
	var w := c_spin[i]
	var b := c_bas[i]
	v.y -= 9.8 * dt
	p += v * dt
	var wl := w.length()
	if wl > 0.01:
		b = (Basis(w / wl, wl * dt) * b).orthonormalized()
	var g := W.ground_height(p.x, p.z, p.y + 2.0)
	if p.y < g + 0.12:
		p.y = g + 0.12
		if v.y < 0.0:
			v.y = -v.y * 0.3 if v.y < -1.5 else 0.0
		var k := maxf(1.0 - 3.0 * dt, 0.0)
		v.x *= k
		v.z *= k
		w *= maxf(1.0 - 2.5 * dt, 0.0)
		if Vector2(v.x, v.z).length() < 0.4 and w.length() < 1.2 and absf(v.y) < 0.5:
			# comes to rest on its side
			var u := b.y
			var h := Vector3(u.x, 0.0, u.z)
			h = h.normalized() if h.length() > 0.05 else Vector3(1.0, 0.0, 0.0)
			b = Basis(Vector3.UP, h, Vector3.UP.cross(h))
			p.y = g + 0.16
			v = Vector3.ZERO
			w = Vector3.ZERO
			c_state[i] = 2
	c_vel[i] = v
	c_pos[i] = p
	c_spin[i] = w
	c_bas[i] = b


# ------------------------------------------------------------------ UI
func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 6
	add_child(layer)
	var ins := Ui.safe_insets(get_viewport())
	var pnl := Ui.panel(Color(0.03, 0.05, 0.09, 0.72), 16)
	pnl.position = Vector2(14.0 + ins.x, 52.0 + ins.y)
	pnl.custom_minimum_size = Vector2(470, 0)
	pnl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(pnl)
	var mc := MarginContainer.new()
	for k in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		mc.add_theme_constant_override(k, 14)
	pnl.add_child(mc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	mc.add_child(vb)
	head_l = Ui.label("", 32, Ui.ACCENT, true)
	vb.add_child(head_l)
	body_l = Ui.label("", 22, Color.WHITE, true)
	vb.add_child(body_l)
	var y := 340.0 + ins.y
	for i in NAMES.size():
		var b := Ui.button(NAMES[i], go_station.bind(i), COLS[i], 22, Vector2(150, 54))
		b.position = Vector2(14.0 + ins.x, y)
		layer.add_child(b)
		y += 62.0
	big_l = Ui.label("", 56, Color.WHITE, true)
	big_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_l.anchor_left = 0.5
	big_l.anchor_right = 0.5
	big_l.offset_left = -500.0
	big_l.offset_right = 500.0
	big_l.offset_top = 110.0
	big_l.offset_bottom = 190.0
	big_l.modulate.a = 0.0
	big_l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(big_l)


func _pop(t: String, col: Color) -> void:
	if big_l == null:
		return
	big_l.text = t
	big_l.add_theme_color_override("font_color", col)
	big_l.modulate.a = 1.0
	if _big_tw and _big_tw.is_valid():
		_big_tw.kill()
	_big_tw = create_tween()
	_big_tw.tween_interval(2.2)
	_big_tw.tween_property(big_l, "modulate:a", 0.0, 0.6)


## Result pop-up with the finish / new-best sound.
func _done(t: String, col: Color) -> void:
	if _newrec:
		_newrec = false
		G.ui("jingle_record", -3.0)
		_pop(t + "   NEW BEST!", Ui.GOLD)
	else:
		G.ui("finish", -4.0)
		_pop(t, col)


func _ts(v: float) -> String:
	return "--" if v < 0.0 else "%.2f s" % v


func _bs(key: String, f: String) -> String:
	return ("   best " + (f % float(best[key]))) if best.has(key) else ""


func _best_line(key: String, f: String) -> String:
	return "\nBEST  " + ((f % float(best[key])) if best.has(key) else "--")


func _refresh() -> void:
	if head_l == null or gw == null or gw.player == null:
		return
	var car := gw.player
	head_l.text = NAMES[cur]
	head_l.add_theme_color_override("font_color", COLS[cur])
	var s := ""
	match cur:
		0:
			if d_state == 1:
				s = "STAGED  -  GO!"
			elif d_state == 2:
				s = "%.2f s    %d km/h    %d m" % [d_t, int(car.kmh()), int(maxf(car.global_position.x + 2.0 - d_x0, 0.0))]
			elif d_state == 3:
				s = "FINISHED"
			else:
				s = d_msg if d_msg != "" else "Nose on the green line, stop, then floor it"
			s += "\n0-100 km/h   %s%s" % [_ts(d100), _bs("d100", "%.2f s")]
			s += "\n0-200 km/h   %s%s" % [_ts(d200), _bs("d200", "%.2f s")]
			s += "\n402 m   %s%s%s" % [_ts(d402), ("   %d km/h" % int(v402)) if d402 >= 0.0 else "", _bs("d402", "%.2f s")]
			s += "\n1000 m   %s%s%s" % [_ts(d1000), ("   %d km/h" % int(v1000)) if d1000 >= 0.0 else "", _bs("d1000", "%.2f s")]
		1:
			var hits := _count_hits(1)
			if s_state == 1:
				s = "%.1f s    cones %d  (+%.1f s)" % [s_t, hits, 0.5 * float(hits)]
			elif s_state == 2:
				s = "FINISHED  %.2f s   (%d cones)" % [s_total, hits]
			else:
				s = s_msg if s_msg != "" else "Weave through %d cones, +0.5 s per hit" % SL_N
			s += _best_line("slalom", "%.2f s")
		2:
			if b_state == 1:
				s = "BRAKE!   %d km/h   %d m" % [int(car.kmh()), int(maxf(car.global_position.x + 2.0 - BR_GATE, 0.0))]
			elif b_state == 2 and b_d > 0.0:
				s = "STOP  %.1f m   from %d km/h   %.2f g" % [b_d, int(b_v * 3.6), b_g]
			else:
				s = b_msg if b_msg != "" else "Reach speed, cross the red gate, then brake hard"
			s += _best_line("brake_g", "%.2f g")
		3:
			if j_state == 1:
				s = "AIR  %.1f s" % j_t
			elif j_state == 2:
				s = "%.1f m   %.1f s   from %d km/h   up %.1f m" % [j_dist, j_t, int(j_v), j_top - j_from.y]
			else:
				s = "Hit the ramp as fast as you dare"
			s += _best_line("jump", "%.1f m")
		_:
			if f_state == 1:
				s = "SCORE %d    x%.1f    %d s" % [int(f_score), f_combo, int(maxf(DR_TIME - f_t, 0.0))]
			elif f_state == 2:
				s = "TIME UP   %d pts" % int(f_last)
			else:
				s = "Drift between the orange and cyan rings"
			s += _best_line("drift", "%d pts")
	body_l.text = s


# ------------------------------------------------------------------ teleports
func go_station(i: int) -> void:
	if gw == null or gw.player == null:
		return
	cur = clampi(i, 0, NAMES.size() - 1)
	var s := spawn_of(cur)
	var pos := Vector3(s.x, W.ground_height(s.x, s.y) + 0.15, s.y)
	var far := gw.player.global_position.distance_to(pos) > 300.0
	gw.player.reset_to(pos, PI * 0.5)
	gw.cam_yaw = PI * 0.5
	_reset_runs()
	if far:
		gw._stream(true)
	gw._update_cam(1.0)
	_pp = pos
	_refresh()


func respawn() -> void:
	go_station(cur)


func _reset_runs() -> void:
	d_state = 0
	d_msg = ""
	d100 = -1.0
	d200 = -1.0
	d402 = -1.0
	d1000 = -1.0
	s_state = 0
	s_msg = ""
	s_total = -1.0
	b_state = 0
	b_msg = ""
	b_d = -1.0
	j_state = 0
	j_dist = -1.0
	f_state = 0
	f_last = -1.0
	_newrec = false
	_reset_grp(1)
	_reset_grp(2)


# ------------------------------------------------------------------ stations
func _process(dt: float) -> void:
	_ui_t += dt
	if _ui_t >= 0.1:
		_ui_t = 0.0
		_refresh()


func _physics_process(dt: float) -> void:
	if gw == null or gw.player == null:
		return
	var car := gw.player
	var p := car.global_position
	_sfx_t = maxf(_sfx_t - dt, 0.0)
	_cones_step(car, dt)
	_pick(p)
	_drag(car, p, dt)
	_slalom(car, p, dt)
	_brake(car, p, dt)
	_jump(car, p, dt)
	_drift(car, p, dt)
	_pp = p


## The panel follows the area the car is in.
func _pick(p: Vector3) -> void:
	var n := -1
	if Vector2(p.x - DR_C.x, p.z - DR_C.y).length() < 45.0:
		n = 4
	elif p.x > RAMP_X - 175.0 and p.x < RAMP_X + RAMP_L + 150.0 and absf(p.z - LANE_R) < 8.0 and d_state != 2:
		n = 3
	elif p.x > SL_X - 45.0 and p.x < SL_X + 300.0 and absf(p.z - LANE_L) < 9.0:
		n = 1
	elif p.x > DRAG_X - 10.0 and p.x < DRAG_X + DRAG_LEN + 10.0 and absf(p.z - LANE_R) < 8.0:
		n = 0
	elif p.x > BR_X - 5.0 and p.x < BR_GATE + BR_ZONE + 20.0 and absf(p.z - LANE_C) < 8.0:
		n = 2
	if n >= 0:
		cur = n


func _drag(car: Vehicle, p: Vector3, dt: float) -> void:
	var lane := absf(p.z - LANE_R)
	var nose := p.x + 2.0
	if d_state == 0 or d_state == 3:
		if lane < 5.0 and p.x > DRAG_X - 9.0 and p.x < DRAG_X + 1.5 and absf(car.speed) < 1.0:
			d_state = 1
			d_msg = ""
			d100 = -1.0
			d200 = -1.0
			d402 = -1.0
			d1000 = -1.0
	elif d_state == 1:
		if lane > 7.0 or p.x < DRAG_X - 14.0 or p.x > DRAG_X + 6.0:
			d_state = 0
		elif car.speed > 1.0:
			d_state = 2
			d_t = 0.0
			d_x0 = nose
			_pop("GO!", Ui.GOOD)
	else:
		d_t += dt
		var dist := nose - d_x0
		var kmh := car.kmh()
		if d100 < 0.0 and kmh >= 100.0:
			d100 = d_t
			_rec("d100", d100, true)
			G.ui("coin", -6.0)
		if d200 < 0.0 and kmh >= 200.0:
			d200 = d_t
			_rec("d200", d200, true)
			G.ui("coin", -6.0)
		if d402 < 0.0 and dist >= 402.3:
			d402 = d_t
			v402 = kmh
			_rec("d402", d402, true)
			G.ui("lap", -4.0)
		if dist >= DRAG_LEN:
			d1000 = d_t
			v1000 = kmh
			_rec("d1000", d1000, true)
			d_state = 3
			_done("%.2f s" % d1000, Ui.GOLD)
		elif lane > 9.0:
			d_state = 0
			d_msg = "OFF THE LANE - run cancelled"
		elif car.speed < -1.0 or (car.speed < 0.5 and d_t > 1.5):
			d_state = 0
			d_msg = "STOPPED - run cancelled"


func _slalom(car: Vehicle, p: Vector3, dt: float) -> void:
	var lane := absf(p.z - LANE_L)
	var fin := SL_X + SL_FIRST + SL_GAP * float(SL_N - 1) + 30.0
	if s_state != 1:
		if _pp.x < SL_X and p.x >= SL_X and lane < 9.0 and car.speed > 2.0:
			s_state = 1
			s_t = 0.0
			s_total = -1.0
			s_msg = ""
			_reset_grp(1)
			_pop("GO!", Ui.GOOD)
	else:
		s_t += dt
		if lane > 11.0 or p.x < SL_X - 8.0:
			s_state = 0
			s_msg = "OUT OF THE LANE - run cancelled"
		elif p.x >= fin:
			s_total = s_t + 0.5 * float(_count_hits(1))
			s_state = 2
			_rec("slalom", s_total, true)
			_done("%.2f s" % s_total, Ui.GOLD)


func _brake(car: Vehicle, p: Vector3, _dt: float) -> void:
	var lane := absf(p.z - LANE_C)
	var nose := p.x + 2.0
	var pn := _pp.x + 2.0
	if b_state != 1:
		if pn < BR_GATE and nose >= BR_GATE and lane < 7.5 and car.kmh() > 40.0:
			b_state = 1
			b_v = car.speed
			b_d = -1.0
			b_msg = ""
			_pop("BRAKE!", Ui.HOT)
	else:
		var d := nose - BR_GATE
		if car.speed < 0.4:
			b_d = maxf(d, 0.1)
			b_g = b_v * b_v / (2.0 * b_d) / 9.81
			b_state = 2
			_rec("brake_g", b_g, false)
			_done("%.1f m   %.2f g" % [b_d, b_g], Ui.GOLD)
		elif d > BR_ZONE or lane > 9.0:
			b_state = 2
			b_d = -1.0
			b_msg = "TOO LATE - rolled past the zone"
			_pop("TOO LATE", Ui.HOT)
		elif car.speed < -1.0:
			b_state = 0


func _jump(car: Vehicle, p: Vector3, dt: float) -> void:
	var lip := RAMP_X + RAMP_L
	if j_state != 1:
		if car.airborne and p.x > lip - 8.0 and p.x < lip + 25.0 and absf(p.z - LANE_R) < RAMP_W * 0.5 + 2.0 and car.speed > 8.0:
			j_state = 1
			j_from = p
			j_t = 0.0
			j_v = car.kmh()
			j_top = p.y
	else:
		j_t += dt
		j_top = maxf(j_top, p.y)
		if not car.airborne and j_t > 0.3:
			j_dist = Vector2(p.x - j_from.x, p.z - j_from.z).length()
			j_state = 2
			_rec("jump", j_dist, false)
			_done("%d m" % int(j_dist), Ui.GOLD)
		elif j_t > 10.0:
			j_state = 0


func _drift(car: Vehicle, p: Vector3, dt: float) -> void:
	var r := Vector2(p.x - DR_C.x, p.z - DR_C.y).length()
	var inside := r > DR_IN and r < DR_OUT
	var sliding := car.drifting and absf(car.speed) > 8.0 and not car.airborne
	if f_state != 1:
		if inside and sliding:
			f_state = 1
			f_t = 0.0
			f_score = 0.0
			f_combo = 1.0
			f_hold = 0.0
			f_out = 0.0
			_reset_grp(2)
			_pop("DRIFT!", COLS[4])
	else:
		f_t += dt
		if inside and sliding:
			f_hold = 2.0
			f_combo = minf(f_combo + dt * 0.5, 8.0)
			f_score += dt * absf(car.speed) * 2.2 * f_combo
		else:
			f_hold -= dt
			if f_hold <= 0.0:
				f_combo = 1.0
		f_out = 0.0 if inside else f_out + dt
		if f_t >= DR_TIME or f_out > 5.0:
			f_state = 2
			f_last = f_score
			_rec("drift", f_score, false)
			_done("%d pts" % int(f_score), COLS[4])
