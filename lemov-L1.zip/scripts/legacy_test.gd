extends SceneTree
## godot --headless --path . --script res://scripts/legacy_test.gd -- [kind...]   builds the cars both ways and prints size / triangle counts / wheels
func _tris(n: Node) -> int:
	var t := 0
	for c in n.find_children("*", "MeshInstance3D", true, false):
		var mi := c as MeshInstance3D
		if mi.mesh:
			for s in mi.mesh.get_surface_count():
				var a := mi.mesh.surface_get_arrays(s)
				var idx = a[Mesh.ARRAY_INDEX]
				t += (idx.size() if idx != null else (a[Mesh.ARRAY_VERTEX] as PackedVector3Array).size()) / 3
	return t
func _init() -> void:
	await process_frame
	var CB = load("res://scripts/car_builder.gd")
	var kinds: Array = ["ferrari", "porsche911", "concept"]
	var ua := OS.get_cmdline_user_args()
	if ua.size() > 0:
		kinds = Array(ua)
	for k in kinds:
		for lod in [true, false]:
			var t0 := Time.get_ticks_msec()
			var r: Dictionary = CB.build(k, Color(0.8, 0.05, 0.05), Color(0.05, 0.05, 0.06), lod)
			var n: Node3D = r["node"]
			var wt := 0
			for w in r["wheels"]:
				wt += _tris(w)
			var sp: Dictionary = r["spec"]
			print("LEG ", k, " lod=", lod, " ms=", Time.get_ticks_msec() - t0, " tris_total=", _tris(n), " wheels=", r["wheels"].size(), " wheel_tris=", wt, " len=%.2f wid=%.2f wr=%.3f wb=%.2f" % [sp["len"], sp["wid"], sp["wr"], sp["wb"]])
			n.free()
	quit()
