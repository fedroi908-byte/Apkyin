extends Node
## Root node: menu -> loading screen -> open world / mission, and back.

var current: Node = null
var loading: LoadingScreen
var remote_ui: RemoteUi


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	G.apply_quality(get_viewport())
	remote_ui = RemoteUi.new()
	add_child(remote_ui)
	remote_ui.route.connect(_on_route)
	show_menu()


## Deep links (lemov://garage, lemov://car/<id> ...) go to the menu that is currently shown.
func _on_route(kind: String, arg: String) -> void:
	if current != null and is_instance_valid(current) and current.has_method("route"):
		current.call("route", kind, arg)


func show_menu() -> void:
	get_tree().paused = false
	R.menu_active = true
	R.set_world(false)
	var m := MainMenu.new()
	m.play.connect(func(mode: String, id: String):
		G.mode = mode
		G.mission_id = id
		R.track("play", {"mode": mode, "id": id, "car": String(G.cars[G.selected_car]["id"])})
		start_world())
	m.quit_game.connect(func(): get_tree().quit())
	_swap(m)
	G.apply_quality(get_viewport())


func start_world() -> void:
	get_tree().paused = false
	R.menu_active = false
	loading = LoadingScreen.new()
	add_child(loading)
	loading.set_progress(0.1, "PREPARING...")
	if current and is_instance_valid(current):
		current.queue_free()
		current = null
	await get_tree().process_frame
	await get_tree().process_frame
	loading.set_progress(0.35, "BUILDING WORLD...")
	await get_tree().process_frame
	var gw := GameWorld.new()
	gw.process_mode = Node.PROCESS_MODE_PAUSABLE
	gw.exit_to_menu.connect(show_menu)
	gw.restart_world.connect(start_world)
	_swap(gw)
	R.set_world(true)
	await get_tree().process_frame
	loading.set_progress(1.0, "READY")
	await get_tree().create_timer(0.35).timeout
	loading.finish()


func _swap(node: Node) -> void:
	if current and is_instance_valid(current):
		current.queue_free()
	current = node
	if node:
		add_child(node)
