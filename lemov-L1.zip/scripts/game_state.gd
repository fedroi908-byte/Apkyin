extends Node
## Global game state (autoload "G"): settings, car/track catalogue, save data.

signal settings_changed

const SAVE_PATH := "user://lemov_save.json"

# ---------------------------------------------------------------- catalogue
# Stats are on a 0..1 scale and are mapped to physics values in vehicle.gd
## Car catalogue: built at start from res://data/cars.json (+ server overlay via add_remote_cars()).
var cars: Array[Dictionary] = []

func _load_cars() -> void:
	cars.clear()
	var d: Variant = SafeIO.parse(FileAccess.get_file_as_string("res://data/cars.json"))
	if d is Dictionary:
		for c in (d as Dictionary).get("cars", []):
			cars.append(_car_from_json(c))
	if cars.is_empty():      # the game must never break because of a bad catalogue
		cars.append(_car_from_json({"id": "rosso", "model": "ferrari", "name": "ROSSO 458", "tagline": "Mid-engine Italian V8 spider", "color": "#c70a0d",
			"accent": "#14141a", "top_speed": 0.8, "accel": 0.82, "handling": 0.8, "nitro": 0.6, "price": 0}))


func _car_from_json(c: Dictionary) -> Dictionary:
	var o: Dictionary = c.duplicate(true)
	o["color"] = Color.html(String(c.get("color", "#c70a0d")))
	o["accent"] = Color.html(String(c.get("accent", "#14141a")))
	return o


## Server-delivered cars (already verified by the updater). Existing ids are replaced, new ones appended.
func add_remote_cars(list: Array) -> void:
	for c in list:
		if not (c is Dictionary) or not (c as Dictionary).has("id"):
			continue
		var o := _car_from_json(c)
		var found := -1
		for i in cars.size():
			if cars[i]["id"] == o["id"]:
				found = i
		if found >= 0:
			cars[found] = o
		else:
			cars.append(o)
		if o.has("path"):
			CarBuilder.register_cfg(o)

const PAINTS: Array[Color] = [
	Color(0.78, 0.04, 0.05), Color(0.95, 0.42, 0.05), Color(0.96, 0.78, 0.08), Color(0.08, 0.55, 0.22),
	Color(0.05, 0.35, 0.9), Color(0.55, 0.20, 0.95), Color(0.93, 0.93, 0.95), Color(0.05, 0.05, 0.07),
]
const PAINT_NAMES := ["Rosso", "Arancio", "Giallo", "Verde", "Blu", "Viola", "Bianco", "Nero"]

const TRACKS: Array[Dictionary] = [
	{"id": "harbor", "name": "HARBOR SPRINT", "desc": "Sunset coastal circuit", "laps": 3, "theme": 0},
	{"id": "neon", "name": "NEON CITY", "desc": "Night street circuit", "laps": 3, "theme": 1},
	{"id": "alpine", "name": "ALPINE PASS", "desc": "Mountain hill climb loop", "laps": 3, "theme": 2},
]

# ---------------------------------------------------------------- settings
var res_scale: float = 1.0       # live render scale (dynamic resolution)
var dyn_res: bool = true
var quality: int = 1            # 0 low, 1 medium, 2 high, 3 ultra
var start_hour: float = 17.0
var fps_limit_enabled: bool = false     # no frame-rate cap by default (the display's vsync is the only limit)
var tilt_steering: bool = false
var steer_sensitivity: float = 1.0
var touch_scale: float = 1.0        # on-screen pad size (0.6 .. 1.6)
var touch_opacity: float = 0.6
var left_handed: bool = false      # mirror the on-screen pads
var master_volume: float = 0.9
var music_volume: float = 0.55
var sfx_volume: float = 1.0
var haptics: bool = true
var show_fps: bool = false
var telemetry: bool = true             # anonymous usage statistics (settings > online); nothing is sent when off
var tel_note: bool = false             # the one-time "anonymous statistics" note was shown
var cellular_dl: bool = false          # allow big content downloads on mobile data
var lang: String = "en"                # language of server texts (news, ads, messages): uz / ru / en

# ---------------------------------------------------------------- progress
var credits: int = 0
var owned_cars: Array = ["rosso"]
var car_paint: Dictionary = {}      # car id -> index into PAINTS
var mission_stars: Dictionary = {}  # mission id -> 0..3
var mission_best: Dictionary = {}   # mission id -> best time / score
var mode := "free"                  # hand-off menu -> world: "free", "mission" or "training"
var mission_id := ""
var weather_pref := 0               # 0 clear 1 cloudy 2 storm
var total_distance_km := 0.0
var selected_car: int = 0
var selected_track: int = 0
var best_laps: Dictionary = {}      # track id -> seconds
var best_races: Dictionary = {}     # track id -> seconds
var races_won: int = 0
var ai_difficulty: int = 1          # 0 easy, 1 normal, 2 hard
var xp: int = 0
var play_s: float = 0.0             # accumulated play time in races / free roam (seconds)
var races_total: int = 0
var last_daily := ""                # yyyy-mm-dd of the last daily bonus
var hidden_cars: Array = []         # ids the server hides from the garage (owned cars always stay visible)

# per-race hand-off (menu -> race)
var race_laps: int = 3
var race_ai_count: int = 5


func _ready() -> void:
	_load_cars()
	_register_inputs()
	lang = _locale_lang()
	if not FileAccess.file_exists(SAVE_PATH):
		quality = auto_quality()
	load_game()
	res_scale = Q.base_scale()
	apply_audio()


## First-launch quality pick: always safe. Phones start on LOW; only clearly flagship GPUs with lots of RAM start on MEDIUM.
## (HIGH/ULTRA are strictly opt-in from the settings screen.)
func auto_quality() -> int:
	if not OS.has_feature("mobile"):
		return 2
	var gpu := RenderingServer.get_video_adapter_name().to_lower()
	var n := _first_int(gpu)
	var strong := false
	if gpu.contains("adreno"):
		strong = n >= 730
	elif gpu.contains("immortalis") or gpu.contains("xclipse"):
		strong = true
	elif gpu.contains("mali"):
		var gi := gpu.find("-g")
		strong = gi >= 0 and _first_int(gpu.substr(gi + 2)) >= 710
	if strong and OS.has_method("get_memory_info"):
		var mi: Dictionary = OS.get_memory_info()
		strong = int(mi.get("physical", 0)) / 1048576 >= 7000
	return 1 if strong else 0


func _first_int(s: String) -> int:
	var cur := ""
	for ch in s:
		if ch >= "0" and ch <= "9":
			cur += ch
		elif cur != "":
			break
	return int(cur) if cur != "" else 0


func _locale_lang() -> String:
	var l := OS.get_locale_language()
	return l if l in ["uz", "ru"] else "en"


## Player level from xp (level 1 at 0 xp; every level needs a little more).
func level() -> int:
	return 1 + int(floor(sqrt(float(maxi(xp, 0)) / 120.0)))


func add_xp(n: int) -> void:
	xp = maxi(0, xp + n)


## Anonymous profile summary sent with telemetry (no names, no identifiers beyond the random install id).
func profile() -> Dictionary:
	return {"lvl": level(), "xp": xp, "coins": credits, "cars": owned_cars.slice(0, 60), "car": String(cars[clampi(selected_car, 0, cars.size() - 1)]["id"]) if not cars.is_empty() else "",
		"play_s": int(play_s), "races": races_total, "wins": races_won, "km": snappedf(total_distance_km, 0.1), "first": int(R.state.get("first_ts", 0))}


## Applies a server gift / grant ({coins, xp, car}); returns a short human readable line for the popup.
func grant(g: Variant) -> String:
	var parts: Array = []
	if g is Array:
		for x in (g as Array).slice(0, 8):
			parts.append_array(_grant_one(x))
	else:
		parts.append_array(_grant_one(g))
	if not parts.is_empty():
		save_game()
	return ", ".join(parts)


## One grant: {"type":"coins"|"xp","amount":n} / {"type":"car","car":id} (server protocol) or the flat {coins, xp, car} form.
func _grant_one(g: Variant) -> Array:
	var parts: Array = []
	if not (g is Dictionary):
		return parts
	var d: Dictionary = g
	var coins := 0
	var xps := 0
	var cid := ""
	match String(d.get("type", "")):
		"coins":
			coins = int(d.get("amount", 0))
		"xp":
			xps = int(d.get("amount", 0))
		"car":
			cid = String(d.get("car", ""))
		_:
			coins = int(d.get("coins", 0))
			xps = int(d.get("xp", 0))
			cid = String(d.get("car", ""))
	coins = clampi(coins, 0, 10000000)
	if coins > 0:
		credits += coins
		parts.append("+%d coins" % coins)
	xps = clampi(xps, 0, 1000000)
	if xps > 0:
		add_xp(xps)
		parts.append("+%d XP" % xps)
	if cid != "":
		if not owned_cars.has(cid):
			owned_cars.append(cid)
		var nm := cid.to_upper()
		for c in cars:
			if c["id"] == cid:
				nm = String(c["name"])
		parts.append("car: %s" % nm)
	return parts


## Daily bonus (server controlled, econ.daily_bonus): returns the coins granted today, 0 when none / already claimed.
func claim_daily() -> int:
	var amount := int(R.cfg("econ.daily_bonus", 0))
	if amount <= 0:
		return 0
	var today := Time.get_date_string_from_system(true)
	if last_daily == today:
		return 0
	last_daily = today
	credits += amount
	save_game()
	return amount


func price_of(idx: int) -> int:
	return maxi(0, int(round(float(cars[idx]["price"]) * float(R.cfg("econ.price_mult", 1.0)))))


func is_hidden(idx: int) -> bool:
	return hidden_cars.has(cars[idx]["id"]) and not owns(idx)


## Rebuilds the catalogue from the built-in list plus the verified server overlay (field patches, new cars, hidden ids).
func apply_remote_catalogue(patches: Array, added: Array, hide: Array) -> void:
	var cur_id := String(cars[clampi(selected_car, 0, cars.size() - 1)]["id"]) if not cars.is_empty() else ""
	_load_cars()
	for p in patches:
		for i in cars.size():
			if cars[i]["id"] == p["id"]:
				var o: Dictionary = cars[i]
				for k in p:
					if k == "id":
						continue
					o[k] = Color.html(String(p[k])) if (k == "color" or k == "accent") else p[k]
	add_remote_cars(added)
	hidden_cars = hide
	for i in cars.size():
		if cars[i]["id"] == cur_id:
			selected_car = i


func _register_inputs() -> void:
	var map := {
		"steer_left": [KEY_A, KEY_LEFT],
		"steer_right": [KEY_D, KEY_RIGHT],
		"accelerate": [KEY_W, KEY_UP],
		"brake": [KEY_S, KEY_DOWN],
		"nitro": [KEY_SHIFT, KEY_N],
		"drift": [KEY_SPACE],
		"camera": [KEY_C],
		"pause": [KEY_ESCAPE, KEY_P],
		"reset_car": [KEY_R],
		"horn": [KEY_H],
	}
	for action in map:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for k in map[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)


# ---------------------------------------------------------------- helpers
func car() -> Dictionary:
	var c: Dictionary = cars[clampi(selected_car, 0, cars.size() - 1)].duplicate()
	c["color"] = car_color(clampi(selected_car, 0, cars.size() - 1))
	return c


func car_color(idx: int) -> Color:
	var id: String = cars[idx]["id"]
	if car_paint.has(id):
		return PAINTS[clampi(int(car_paint[id]), 0, PAINTS.size() - 1)]
	return cars[idx]["color"]


func set_car_paint(idx: int, pi: int) -> void:
	car_paint[cars[idx]["id"]] = pi


func ui(sound: String, vol_db: float = -6.0) -> void:
	var st := load("res://assets/audio/%s.wav" % sound) as AudioStream
	if st == null:
		return
	var pl := AudioStreamPlayer.new()
	pl.stream = st
	pl.volume_db = vol_db + linear_to_db(maxf(sfx_volume, 0.001))
	pl.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(pl)
	pl.play()
	pl.finished.connect(pl.queue_free)


func track() -> Dictionary:
	return TRACKS[clampi(selected_track, 0, TRACKS.size() - 1)]


func owns(idx: int) -> bool:
	return owned_cars.has(cars[idx]["id"])


func buy_car(idx: int) -> bool:
	if owns(idx):
		return true
	var price := price_of(idx)
	if credits >= price:
		credits -= price
		owned_cars.append(cars[idx]["id"])
		save_game()
		R.track("purchase", {"car": String(cars[idx]["id"]), "price": price})
		return true
	return false


func record_lap(track_id: String, t: float) -> bool:
	var prev: float = best_laps.get(track_id, 1e9)
	if t < prev:
		best_laps[track_id] = t
		return true
	return false


func record_race(track_id: String, t: float) -> void:
	var prev: float = best_races.get(track_id, 1e9)
	if t < prev:
		best_races[track_id] = t


func format_time(t: float) -> String:
	if t >= 1e8 or t < 0.0:
		return "--:--.---"
	var m := int(t / 60.0)
	var s := int(t) % 60
	var ms := int(round((t - floor(t)) * 1000.0))
	if ms >= 1000:
		ms = 999
	return "%d:%02d.%03d" % [m, s, ms]


# ---------------------------------------------------------------- settings
func apply_audio() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(clampf(master_volume, 0.0001, 1.0)))


func apply_quality(vp: Viewport) -> void:
	Q.apply(vp)


func vibrate(ms: int) -> void:
	if haptics and OS.has_feature("mobile"):
		Input.vibrate_handheld(ms)


# ---------------------------------------------------------------- save/load
func save_game() -> void:
	var d := {
		"quality": quality, "tilt": tilt_steering, "sens": steer_sensitivity, "tscale": touch_scale, "topac": touch_opacity, "lefty": left_handed,
		"vol": master_volume, "music": music_volume, "sfx": sfx_volume,
		"haptics": haptics, "fps": show_fps, "fpscap2": fps_limit_enabled,
		"credits": credits, "owned": owned_cars, "car": selected_car, "car_id": String(cars[clampi(selected_car, 0, cars.size() - 1)]["id"]),
		"track": selected_track, "best_laps": best_laps, "best_races": best_races,
		"won": races_won, "diff": ai_difficulty, "paint": car_paint, "mstars": mission_stars, "mbest": mission_best, "weather": weather_pref, "start_hour": start_hour, "dist": total_distance_km, "dynres": dyn_res,
		"tel": telemetry, "telnote": tel_note, "cell": cellular_dl, "lang": lang, "xp": xp, "play_s": play_s, "races_total": races_total, "daily": last_daily,
	}
	SafeIO.write_json(SAVE_PATH, d)


func load_game() -> void:
	var parsed: Variant = SafeIO.read_json(SAVE_PATH)
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	var d: Dictionary = parsed
	quality = int(d.get("quality", quality))
	tilt_steering = bool(d.get("tilt", tilt_steering))
	steer_sensitivity = float(d.get("sens", steer_sensitivity))
	touch_scale = clampf(float(d.get("tscale", touch_scale)), 0.5, 1.8)
	touch_opacity = clampf(float(d.get("topac", touch_opacity)), 0.2, 1.0)
	left_handed = bool(d.get("lefty", left_handed))
	master_volume = float(d.get("vol", master_volume))
	music_volume = float(d.get("music", music_volume))
	sfx_volume = float(d.get("sfx", sfx_volume))
	haptics = bool(d.get("haptics", haptics))
	show_fps = bool(d.get("fps", show_fps))
	fps_limit_enabled = bool(d.get("fpscap2", fps_limit_enabled))
	credits = int(d.get("credits", credits))
	owned_cars = d.get("owned", owned_cars)
	selected_car = clampi(int(d.get("car", selected_car)), 0, cars.size() - 1)
	if d.has("car_id"):       # the catalogue order can change with updates, so the id wins over the index
		for i in cars.size():
			if cars[i]["id"] == String(d["car_id"]):
				selected_car = i
	selected_track = clampi(int(d.get("track", selected_track)), 0, TRACKS.size() - 1)
	best_laps = d.get("best_laps", best_laps)
	best_races = d.get("best_races", best_races)
	races_won = int(d.get("won", races_won))
	ai_difficulty = int(d.get("diff", ai_difficulty))
	car_paint = d.get("paint", car_paint)
	mission_stars = d.get("mstars", mission_stars)
	mission_best = d.get("mbest", mission_best)
	weather_pref = int(d.get("weather", weather_pref))
	start_hour = float(d.get("start_hour", start_hour))
	total_distance_km = float(d.get("dist", total_distance_km))
	dyn_res = bool(d.get("dynres", dyn_res))
	telemetry = bool(d.get("tel", telemetry))
	tel_note = bool(d.get("telnote", tel_note))
	cellular_dl = bool(d.get("cell", cellular_dl))
	lang = String(d.get("lang", lang)) if String(d.get("lang", lang)) in ["uz", "ru", "en"] else lang
	xp = maxi(0, int(d.get("xp", xp)))
	play_s = maxf(0.0, float(d.get("play_s", play_s)))
	races_total = maxi(0, int(d.get("races_total", races_total)))
	last_daily = String(d.get("daily", last_daily))
	if not owned_cars.has("rosso"):
		owned_cars.append("rosso")
