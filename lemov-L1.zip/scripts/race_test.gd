extends Node
## Headless race simulation: the player car is driven by a BotDriver autopilot so the whole race (intro skipped, bots, laps, finish) can be
## checked without a screen.   godot --headless --fixed-fps 60 --path . res://scenes/race_test.tscn -- <race id> <difficulty> <seconds> [quality]
var gw: GameWorld
var t := 0.0
var nxt := 3.0
var auto: BotDriver
var run_for := 90.0
var started := false
var done := false
var steer_test := 0.0
var steer_log := 0.0
var steer_speed := 0.0
var watch := ""
func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	G.start_hour = 11.0
	G.mode = "mission"
	G.mission_id = "race_" + (a[0] if a.size() > 0 else "downtown")
	G.ai_difficulty = int(a[1]) if a.size() > 1 else 1
	run_for = float(a[2]) if a.size() > 2 else 90.0
	if a.size() > 3:
		G.quality = int(a[3])
	steer_test = float(a[4]) if a.size() > 4 else 0.0
	steer_speed = float(a[5]) if a.size() > 5 else 0.0
	watch = String(a[6]).to_upper() if a.size() > 6 else ""
	if a.size() > 7:
		RaceDirector.force_bots = int(a[7])
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)
func _physics_process(dt: float) -> void:
	var rn = gw.runner
	if rn == null or rn.director == null:
		return
	var d: RaceDirector = rn.director
	if rn.state == "intro":
		rn._end_intro()
	if rn.state == "countdown" and rn.cd > 0.05:
		rn.cd = 0.05
	if not started and rn.state == "running":
		started = true
		auto = BotDriver.new()
		auto.setup(gw.player, d.path, d._pidx, d._plap, BotDriver.PERSONAS[0], 0.97, 99)
		auto.total_laps = d.laps
		auto.debug = true
		auto.tag = "YOU"
		for r in d.racers:
			if r["drv"]:
				r["drv"].debug = true
				r["drv"].tag = String(r["name"])
		if watch == "PATH":
			var pf := maxi(int(OS.get_environment("PFROM")), 0)
			for i in range(pf, mini(pf + maxi(int(OS.get_environment("PCNT")), 20), d.path.n)):
				print("  PATHPT i=", i, " p=", d.path.pts[i].snapped(Vector3(0.1, 0.1, 0.1)), " hd=", snappedf(d.path.hd[i], 0.001), " k=", snappedf(d.path.kappa[i], 0.0001), " off=", snappedf(d.path.off[i], 0.1), " lk=", snappedf(d.path.lkappa[i], 0.0001), " gy=", snappedf(W.ground_height(d.path.pts[i].x, d.path.pts[i].z, 90.0), 0.1))
		print("RACE start laps=", d.laps, " racers=", d.racers.size(), " len=", int(d.path.length), " half=", d.half_w, " lim=", snapped(d.path.lim, 0.1))
	if started and rn.state == "running" and absf(steer_test) > 0.001:
		gw.player.collision_mask = 0
		gw.player.in_gas = 1.0 if steer_speed <= 0.0 else clampf((steer_speed - gw.player.speed) * 0.4, 0.0, 1.0)
		gw.player.in_brake = 0.0
		gw.player.in_steer = steer_test
		steer_log += dt
		if steer_log > 0.0:
			steer_log = -0.5
			print("  STEERTEST in_steer=", steer_test, " yaw=", snappedf(gw.player.yaw, 0.001), " kmh=", int(gw.player.kmh()), " lat=", snappedf(gw.player.lateral, 0.01), " gear=", gw.player.gear, " slip=", snappedf(gw.player.slip, 0.01), " wy=", snappedf(gw.player.angular_velocity.y, 0.001), " steer=", snappedf(gw.player.steer, 0.001), " pos=", gw.player.global_position.snapped(Vector3(0.1, 0.1, 0.1)))
	elif started and rn.state == "running":
		var me: Dictionary = d._you
		auto.update(dt, d.racers, me, true)
		auto.wet = Vehicle.wetness
		# the runner finishes by checkpoints; keep the autopilot honest about the line
	t += dt
	if rn.state == "done" and not done:
		done = true
		var st := d.standings()
		print("FINISHED pos=", d.player_position(), " t=", snapped(rn.t, 0.1))
	if started and t < 14.0 and int(t * 60.0) % 30 == 0:
		print("  AUTO ", int(t * 10), " ", auto.dbg, " pos=", gw.player.global_position.snapped(Vector3(0.1, 0.1, 0.1)), " yaw=", snappedf(gw.player.yaw, 0.01), " vel=", gw.player.linear_velocity.snapped(Vector3(0.1, 0.1, 0.1)), " avel=", gw.player.angular_velocity.snapped(Vector3(0.1, 0.1, 0.1)))
		for b in gw.player.get_colliding_bodies():
			var desc := str(b.name) + ":" + str(b.collision_layer)
			if b is StaticBody3D:
				for ch in b.get_children():
					if ch is CollisionShape3D and ch.shape is BoxShape3D:
						var gp: Vector3 = ch.global_position
						if gp.distance_to(gw.player.global_position) < 40.0:
							desc += " box@" + str(gp.snapped(Vector3(0.1, 0.1, 0.1))) + " size=" + str((ch.shape as BoxShape3D).size.snapped(Vector3(0.1, 0.1, 0.1)))
			print("      TOUCH ", desc)
	if watch != "" and started:
		for r in d.racers:
			if String(r["name"]).to_upper().begins_with(watch):
				var cbs: Array = (r["car"] as Vehicle).get_colliding_bodies()
				if cbs.size() > 0 and t < 40.0:
					var ds := []
					for b in cbs:
						var nm := str(b.name)
						if b is Vehicle:
							for r2 in d.racers:
								if r2["car"] == b:
									nm = String(r2["name"])
						ds.append(nm + "@" + str((b as Node3D).global_position.snapped(Vector3(0.1, 0.1, 0.1))) + (" v=" + str(snappedf((b as Vehicle).speed, 0.1)) if b is Vehicle else ""))
					print("  CONTACT t=", snappedf(t, 0.01), " me=", (r["car"] as Vehicle).global_position.snapped(Vector3(0.1, 0.1, 0.1)), " v=", snappedf((r["car"] as Vehicle).speed, 0.1), " lv=", snappedf((r["car"] as Vehicle).lateral, 0.1), " with ", ds)
	if watch != "" and started and t > 15.7 and t < 16.15 and watch.length() > 0:
		for r in d.racers:
			var nmu := String(r["name"]).to_upper()
			if nmu.begins_with(watch) or nmu.begins_with("NITR"):
				var cc: Vehicle = r["car"]
				print("  TICK t=", snappedf(t, 0.001), " ", nmu.substr(0, 4), " pos=", cc.global_position.snapped(Vector3(0.01, 0.01, 0.01)), " vel=", cc.linear_velocity.snapped(Vector3(0.1, 0.1, 0.1)), " w=", cc.angular_velocity.snapped(Vector3(0.01, 0.01, 0.01)), " yaw=", snappedf(cc.yaw, 0.001), " in=", snappedf(cc.in_steer, 0.01), "/", snappedf(cc.in_gas, 0.01), "/", snappedf(cc.in_brake, 0.01))
	if watch == "ALL" and started and int(t * 60.0) % 60 == 0 and t < 14.0:
		var ln := "  ALL t=" + str(snappedf(t, 0.1)) + " "
		for r in d.racers:
			var dd: Dictionary = r["drv"].dbg if r["drv"] else (auto.dbg if auto else {})
			if r["drv"] == null and auto:
				dd = auto.dbg
			ln += String(r["name"]).substr(0, 4) + "[p" + str(int(r["prog"])) + " v" + str(snappedf((r["car"] as Vehicle).speed, 0.1)) + " vt" + str(snappedf(float(dd.get("vt", 0)), 0.1)) + " l" + str(snappedf(float(r["lat"]), 0.1)) + " ahd" + str(snappedf(minf(float(dd.get("ahd", 999)), 99.0), 0.1)) + "] "
		print(ln)
	if watch != "" and watch != "ALL" and started and int(t * 60.0) % 30 == 0:
		for r in d.racers:
			if String(r["name"]).to_upper().begins_with(watch) and r["drv"]:
				print("  WATCH t=", snappedf(t, 0.1), " ", r["drv"].state, " ", r["drv"].dbg)
	if t > nxt:
		nxt += 6.0
		var parts := []
		for r in d.racers:
			var dv: BotDriver = r["drv"]
			var car: Vehicle = r["car"]
			var s := "%s %dkmh L%d p%d" % [String(r["name"]).substr(0, 4), int(car.kmh()), d.lap_of(r), int(r["prog"])]
			if dv:
				s += " %s r%d e%d o%d" % [dv.state, dv.respawns, dv.errors, dv.overtakes]
			parts.append(s)
		print("T%d " % int(t), " | ".join(parts))
		for r in d.racers:
			var dv2: BotDriver = r["drv"] if r["drv"] else auto
			var c2: Vehicle = r["car"]
			if c2.kmh() < 12.0:
				var cb := []
				for b in c2.get_colliding_bodies():
					cb.append(str(b.name) + ":" + str(b.collision_layer))
				print("   SLOW ", r["name"], " ", dv2.dbg, " pos=", c2.global_position.snapped(Vector3(0.1,0.1,0.1)), " touching=", cb)
	if t > run_for:
		var rows := d.classification()
		for r in rows:
			print("  #", r["pos"], " ", r["name"], " ", snapped(float(r["time"]), 0.1), " est=", r["est"], " best=", snapped(float(r["best"]), 0.1))
		print("TAKEDOWNS ", d.takedowns, " auto respawns ", auto.respawns if auto else -1)
		get_tree().quit()
