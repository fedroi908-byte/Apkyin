class_name BotDriver
extends RefCounted
## One AI racer. It drives a Vehicle through the same inputs a player has (steer / gas / brake / handbrake / nitro):
##  - pure-pursuit steering along the racing line + a deviation it controls (lane changes), counter-steer when the tail slides
##  - per-point speed profile from the racing-line curvature, the car's grip + downforce, rain and damage, with braking zones
##  - tactics: overtake with a committed side (inside of the next corner preferred), slipstream, cover the line when attacked,
##    side-by-side clearance, no ramming from clean drivers / contact from aggressive ones, revenge after being hit
##  - human flaws: late braking, lock-ups, running wide (more often for weak drivers), reaction time at the start
##  - nitro strategy, launch control, recovery (stuck / wedged / flipped / off the road) and wrecks after a takedown

const STAB_K := 0.045                  # counter-steer per m/s of sideways speed (0 switches it off)

const PERSONAS := [
	{"id": "ace", "title": "ACE", "skill": 0.03, "aggr": 0.45, "defend": 0.70, "consist": 0.95, "risk": 1.00, "nitro": 0.90, "drift": false},
	{"id": "aggressor", "title": "AGGRESSOR", "skill": 0.00, "aggr": 0.95, "defend": 0.40, "consist": 0.70, "risk": 1.03, "nitro": 0.70, "drift": false},
	{"id": "defender", "title": "DEFENDER", "skill": 0.00, "aggr": 0.30, "defend": 0.95, "consist": 0.85, "risk": 0.99, "nitro": 0.60, "drift": false},
	{"id": "clean", "title": "CLEAN", "skill": 0.01, "aggr": 0.10, "defend": 0.30, "consist": 0.90, "risk": 0.98, "nitro": 0.60, "drift": false},
	{"id": "rookie", "title": "ROOKIE", "skill": -0.05, "aggr": 0.40, "defend": 0.20, "consist": 0.45, "risk": 1.00, "nitro": 0.30, "drift": false},
	{"id": "drifter", "title": "DRIFTER", "skill": -0.02, "aggr": 0.60, "defend": 0.30, "consist": 0.60, "risk": 1.04, "nitro": 0.50, "drift": true},
]

var car: Vehicle
var path: RacePath
var persona: Dictionary = {}
var rng := RandomNumberGenerator.new()
var idx := 0                            # nearest control point of the route
var trk: RacePath.Tracker
var lap := 0
var skill := 0.92                       # 0.8 .. 1.0
var mult := 1.0                         # rubber band from the director
var wet := 0.0                          # rain on the road 0..1 (director)
var total_laps := 1
var finished := false
var vmax := PackedFloat32Array()
var dev := 0.0                          # deviation from the racing line, + right
var grudge := 0.0                       # > 0 after the player hit this bot
var state := "line"                     # line / pass / follow / defend / back / wreck (for debugging and the HUD)
var respawns := 0
var overtakes := 0
var errors := 0
var debug := false
var dbg := {}
var tag := ""
var _hist: Array = []
var _hist_t := 0.0
var _exc_done := false

var _pv := -1
var _t := 0.0                           # seconds since GO
var _react := 0.3
var _pass_side := 0.0
var _pass_t := 0.0
var _pass_cd := 0.0
var _pass_slow := 0.0
var _st_i := 0.0                        # integral part of the yaw-rate loop
var _a_sign := 1.0
var _pass_o: Dictionary = {}              # the racer being overtaken (kept until we are clear of him)
var _def_t := 0.0
var _def_cd := 0.0
var _def_lat := 0.0
var _err_t := 0.0
var _err_type := 0
var _err_cd := 3.0
var _drift_t := 0.0
var _drift_cd := 2.0
var _nitro_on := false
var _nitro_off_t := 0.0
var _stuck := 0.0
var _wedge := 0.0
var _back := 0.0
var _back_dir := 1.0
var _flip := 0.0
var _wreck := 0.0
var _stuck_count := 0
var _facing_back := 0.0
var _squeezed := false


func setup(c: Vehicle, p: RacePath, start_idx: int, start_lap: int, pers: Dictionary, base_skill: float, seed_v: int) -> void:
	car = c
	path = p
	idx = start_idx
	lap = start_lap
	trk = RacePath.Tracker.new(p, start_idx, start_lap)
	persona = pers
	rng.seed = seed_v
	skill = clampf(base_skill + float(pers["skill"]), 0.78, 1.02)
	_react = lerpf(0.55, 0.12, clampf((skill - 0.8) / 0.2, 0.0, 1.0)) + rng.randf_range(0.0, 0.15)
	_build_profile()


func _build_profile() -> void:
	_pv = path.version
	var n := path.n
	vmax.resize(n)
	var mu := car.mu_tyre * (0.64 + 0.2 * skill)
	var m := car.car_mass
	var cl := car.clA
	for i in n:
		var den := m * path.lkappa[i] - 0.6 * mu * cl
		vmax[i] = minf(sqrt(mu * m * 9.81 / den), 120.0) if den > 0.02 else 120.0
	var ab := clampf(mu * 9.81 * 0.72, 5.0, 12.5)
	for _pass in (2 if path.loop else 1):
		for k in range(n - 1, -1, -1):
			if not path.loop and k == n - 1:
				continue
			var nx := path.wi(k + 1)
			vmax[k] = minf(vmax[k], sqrt(vmax[nx] * vmax[nx] + 2.0 * ab * maxf(path.lds[k], 1.0)))


func progress() -> float:
	return trk.progress()


func _aggr() -> float:
	return float(persona["aggr"])


func provoke(amount: float) -> void:
	grudge = minf(grudge + amount, 1.0)


func wreck(duration: float) -> void:
	_wreck = duration
	state = "wreck"


func is_wrecked() -> bool:
	return _wreck > 0.0


func _zero() -> void:
	car.in_gas = 0.0
	car.in_brake = 0.0
	car.in_steer = 0.0
	car.in_nitro = false
	car.in_handbrake = false


func _track(p: Vector3) -> void:
	trk.update(p, car.linear_velocity)
	idx = trk.near()
	lap = trk.lap


func update(dt: float, field: Array, me: Dictionary, go: bool) -> void:
	var p := car.global_position
	var f := car.flat_forward()
	var v := car.speed
	_track(p)
	if path.version != _pv:
		_build_profile()
	if _wreck > 0.0:
		_wreck -= dt
		_zero()
		if _wreck <= 0.0:
			respawn(16.0)
		return
	if not go:
		_zero()
		car.in_brake = 0.5
		car.in_handbrake = true
		return
	car.in_handbrake = false
	_t += dt
	_def_cd = maxf(_def_cd - dt, 0.0)
	_err_cd = maxf(_err_cd - dt, 0.0)
	_drift_cd = maxf(_drift_cd - dt, 0.0)
	grudge = maxf(grudge - dt * 0.03, 0.0)
	if _back > 0.0:
		_back -= dt
		state = "back"
		car.in_gas = 0.0
		car.in_brake = 1.0
		car.in_steer = _back_dir
		car.in_nitro = false
		return
	var my_prog := trk.progress()
	var my_lat := trk.lat
	var aggr := _aggr()
	var line_lat := path.off[idx] + dev
	# ---- who is around
	var ahead: Dictionary = {}
	var ahead_ds := 1e9
	var behind: Dictionary = {}
	var behind_ds := 1e9
	var lo := -path.lim_out
	var hi := path.lim_out
	var clear := 2.45 - 0.85 * aggr
	var player_near: Dictionary = {}
	for o in field:
		if o == me:
			continue
		var ds: float = float(o["prog"]) - my_prog
		var ol: float = float(o["lat"])
		if ds > 2.5 and ds < 45.0 and ds < ahead_ds and minf(absf(ol - line_lat), absf(ol - my_lat)) < 3.0:
			ahead = o
			ahead_ds = ds
		elif ds <= 0.0 and -ds < 30.0 and -ds < behind_ds and absf(ol - line_lat) < 6.0:
			behind = o
			behind_ds = -ds
		if absf(ds) < 5.6:
			var dl := ol - my_lat
			if dl > 0.0 and dl < 4.4:
				hi = minf(hi, ol - clear)
			elif dl < 0.0 and dl > -4.4:
				lo = maxf(lo, ol + clear)
			if bool(o["you"]):
				player_near = o
	# ---- the road ahead
	var turn := angle_difference(path.hd[idx], path.hd[path.wi(idx + int(80.0 / RacePath.STEP))])     # + : bending left
	var corner_ahead := path.lkappa[path.wi(idx + int(60.0 / RacePath.STEP))] > 0.008
	var straight_ahead := path.lkappa[path.wi(idx + int(70.0 / RacePath.STEP))] < 0.004 and path.lkappa[path.wi(idx + int(35.0 / RacePath.STEP))] < 0.004
	# ---- tactics -> goal lateral position (absolute, from the centre line)
	var goal := path.off[idx]
	var vt_cap := 1e9
	state = "line"
	_pass_cd = maxf(_pass_cd - dt, 0.0)
	if _pass_t > 0.0:
		_pass_t -= dt
		if _pass_t <= 0.0:
			_pass_o = {}
			_pass_cd = 1.5
	if _def_t > 0.0:
		_def_t -= dt
	if not finished:
		if _pass_t > 0.0 and not _pass_o.is_empty():
			var dst: float = float(_pass_o["prog"]) - my_prog
			var gp: float = float(_pass_o["lat"]) + _pass_side * 3.0
			if dst > 0.0 and v - float(_pass_o["spd"]) < -0.5:
				_pass_slow += dt                                  # he is faster: this pass is not going to work
			else:
				_pass_slow = maxf(_pass_slow - dt, 0.0)
			if dst < -8.0 or dst > 60.0 or bool(_pass_o["fin"]) or absf(gp) > path.lim_out + 1.5 or absf(my_lat) > path.half + 0.5 or _pass_slow > 1.2:
				_pass_o = {}                                      # clear of him (or no room left): back to the racing line
				_pass_t = 0.0
				_pass_cd = 1.5
			else:
				goal = gp
				state = "pass"
		if not ahead.is_empty():
			var aspd := float(ahead["spd"])
			var closing := v - aspd
			var al: float = float(ahead["lat"])
			var lgap := absf(al - my_lat)
			if lgap < 2.7 and ahead_ds < 30.0 and closing > 0.5 and aggr < 0.97:
				# do not run into his tail while the sideways move is still open: be there only when the gap is
				var ttc := maxf(ahead_ds - 4.6, 0.0) / closing
				if ttc < (2.7 - lgap) / 1.6 + 0.5:
					vt_cap = aspd + 0.3
			if state == "pass":
				pass
			elif ahead_ds < 32.0 and closing > 0.3 and _pass_cd <= 0.0 and absf(my_lat) < path.half:
				# pick a side: room, inside of the next corner, avoid the side that is occupied
				var cl := al - 3.0
				var cr := al + 3.0
				var s_l := 0.0
				var s_r := 0.0
				if cl < lo:
					s_l -= 9.0
				if cr > hi:
					s_r -= 9.0
				s_l += (cl + path.lim_out) * 0.15
				s_r += (path.lim_out - cr) * 0.15
				if absf(turn) > 0.12:
					if turn > 0.0:
						s_l += 1.5 + aggr
					else:
						s_r += 1.5 + aggr
				var cant := corner_ahead and ahead_ds > 14.0 and aggr < 0.7
				if (s_l > -5.0 or s_r > -5.0) and not cant:
					_pass_side = -1.0 if s_l > s_r else 1.0
					_pass_t = 8.0
					_pass_o = ahead
					_pass_slow = 0.0
					goal = al + _pass_side * 3.0
					state = "pass"
					overtakes += 1
					if debug and overtakes < 8:
						print("  PASSDBG ", tag, " t=", snappedf(_t, 0.01), " ahead_ds=", snappedf(ahead_ds, 0.1), " al=", snappedf(al, 0.1), " my_lat=", snappedf(my_lat, 0.1), " side=", _pass_side, " lo=", snappedf(lo, 0.1), " hi=", snappedf(hi, 0.1), " closing=", snappedf(closing, 0.1), " turn=", snappedf(turn, 0.01), " s_l=", snappedf(s_l, 0.1), " s_r=", snappedf(s_r, 0.1), " cant=", cant)
				else:
					# stay behind in the slipstream, do not ram (unless aggressive)
					goal = al
					state = "follow"
					if ahead_ds < 12.0:
						vt_cap = minf(vt_cap, aspd + 2.0 + 12.0 * aggr)
			elif ahead_ds < 45.0:
				goal = al
				state = "follow"
		if state == "line" and not behind.is_empty() and float(persona["defend"]) > 0.5 and _def_cd <= 0.0 and behind_ds < 15.0 and straight_ahead and v > 20.0:
			var bl: float = float(behind["lat"])
			if absf(bl - line_lat) < 3.6 and (v - float(behind["spd"])) < 5.0:
				_def_t = 1.8
				_def_cd = 7.0
				_def_lat = bl
		if _def_t > 0.0 and state == "line":
			goal = _def_lat
			state = "defend"
		if grudge > 0.2 and not player_near.is_empty() and absf(float(player_near["lat"]) - my_lat) < 4.4 and rng.randf() < grudge:
			goal = lerpf(goal, float(player_near["lat"]), 0.45 * grudge)         # squeeze him
	else:
		goal = 0.0
	# ---- mistakes
	_err_apply(dt, v, aggr)
	if _err_t > 0.0 and _err_type == 2:
		goal += signf(turn) * 2.6 if absf(turn) > 0.05 else 2.0          # run wide: to the outside of the bend
	goal = clampf(goal, minf(lo, hi), maxf(lo, hi)) if lo <= hi else my_lat
	_squeezed = lo > hi and absf(v) > 8.0
	var want_dev := goal - path.off[idx]
	var rate := clampf(5.0 - absf(v) * 0.09, 1.5, 4.5) * (0.85 + 0.3 * aggr)         # sideways speed the car can actually follow
	dev = move_toward(dev, clampf(want_dev, -path.lim_out - path.off[idx], path.lim_out - path.off[idx]), rate * dt)
	# ---- steering: pure pursuit on the racing line + deviation; the curvature it may ask for is limited to what the tyres can give
	var av := absf(v)
	var ld := clampf(5.0 + av * 0.75, 8.0, 45.0)
	if absf(my_lat) > path.half - 0.6:
		ld *= 0.8
	# tight bends: the target must not jump to the far leg of a hairpin (it would be behind the nose)
	var kk := maxf(path.lkappa[idx], path.lerp_at(path.lkappa, path.advance(trk.k, trk.t, ld * 0.5)))
	kk = maxf(kk, path.lerp_at(path.lkappa, path.advance(trk.k, trk.t, ld)))
	ld = minf(ld, maxf(4.5, 1.3 / maxf(kk, 0.01)))
	var tp := path.lane_at(path.advance(trk.k, trk.t, ld), dev)
	var to := tp - p
	to.y = 0.0
	var dist := maxf(to.length(), 0.01)
	var a := f.signed_angle_to(to / dist, Vector3.UP)          # + : the target is on the left
	if absf(a) > 2.4:
		a = 2.4 * _a_sign                                      # almost straight behind: keep turning the same way instead of flipping
	else:
		_a_sign = 1.0 if a >= 0.0 else -1.0
	var kpp := 2.0 * sin(a) / maxf(dist, 3.0)                  # curvature of the arc that reaches the target (+ left)
	var gmax := car.mu_tyre * (1.0 - 0.28 * wet) * 9.81 * 0.92
	gmax += car.mu_tyre * 0.55 * car.clA * v * v / car.car_mass
	var kmax := gmax / maxf(v * v, 25.0)
	var kcmd := clampf(kpp, -kmax, kmax)                       # curvature the tyres can follow
	var delta := atan(car.wheelbase * kcmd)
	var lim := maxf(car.max_steer / (1.0 + v * v * 0.0016), 0.05)
	var st := -delta / lim                                     # in_steer: + turns RIGHT (yaw decreases); a > 0 = the target is on the left
	if v > 6.0:
		# yaw-rate loop (P + I, scaled by the kinematic steering gain): whatever the car's understeer, the rotation it was asked for is what it gets
		var sc := car.wheelbase / (v * lim)
		var werr := v * kcmd - car.angular_velocity.y
		_st_i = clampf(_st_i - 1.4 * sc * werr * dt, -0.6, 0.6)
		st -= clampf(0.9 * sc * werr, -0.6, 0.6)
		st += _st_i
	else:
		_st_i = move_toward(_st_i, 0.0, dt * 2.0)
	if v > 8.0 and _drift_t <= 0.0:
		var sl := absf(car.lateral)
		if sl > 2.5:
			st -= signf(car.lateral) * minf((sl - 2.5) * STAB_K * 2.0, 0.3)       # real slide: steer into it
	car.in_steer = clampf(st, -1.0, 1.0)
	# ---- speed
	var gripf := 1.0 - 0.26 * wet
	var vkt := path.advance(trk.k, trk.t, 4.0 + absf(v) * (0.30 + 0.25 * wet))
	var vt := path.lerp_at(vmax, vkt) * mult * float(persona["risk"]) * sqrt(gripf) * (1.0 - 0.12 * wet)
	if _pass_t > 0.0 and aggr > 0.5:
		vt *= 1.0 + 0.04 * aggr
	if car.damage > 0.5:
		vt *= 1.0 - 0.25 * (car.damage - 0.5)
	if _err_t > 0.0 and _err_type == 0:
		vt *= 1.12
	if absf(my_lat) > path.half + 0.8:
		vt *= 0.6
	vt = minf(vt, sqrt(1.0 * gmax / maxf(absf(kpp), 0.0008)))         # never ask the tyres for more than they have
	if finished:
		vt = minf(vt, 18.0)
	vt = minf(vt, vt_cap)
	if _squeezed:
		vt = minf(vt, maxf(v - 2.0, 6.0))                           # no room beside the other car: back off instead of rubbing
	var gas := 0.0
	var brk := 0.0
	if v < vt - 0.5:
		gas = clampf((vt - v) * 0.5 + 0.25, 0.0, 1.0)
	elif v > vt + 0.8:
		brk = clampf((v - vt) * 0.20, 0.0, 1.0)
		brk *= clampf(1.0 - maxf(car.slip - 0.12, 0.0) * 3.0, 0.25, 1.0)      # no hard braking while the car is already sliding
		brk *= clampf(1.5 - v * v * absf(kcmd) / maxf(gmax, 1.0), 0.3, 1.0)   # traction circle: no full braking while cornering hard
	gas *= clampf(1.0 - absf(a) * 0.8, 0.3, 1.0)
	gas *= clampf(1.5 - v * v * absf(kcmd) / maxf(gmax, 1.0), 0.25, 1.0)      # traction circle: cornering takes grip away from the throttle
	if car.slip > 0.2 and v > 8.0 and _drift_t <= 0.0:
		gas *= 0.5
	if _err_t > 0.0 and _err_type == 1:
		gas = 0.0
		brk = minf(brk, 0.15)
	# launch control: reaction time, then ramp the throttle so the tyres do not just spin
	if _t < _react:
		gas = 0.0
	elif _t < _react + 0.7 and v < 18.0:
		gas = minf(gas, 0.55 + (_t - _react) * 0.65)
	if not ahead.is_empty() and ahead_ds < 6.0 and v - float(ahead["spd"]) > 3.0 and aggr < 0.7 and state != "pass":
		brk = maxf(brk, 0.5)
		gas = 0.0
	car.in_gas = gas
	car.in_brake = brk
	if debug:
		dbg = {"vt": snappedf(vt, 0.1), "v": snappedf(v, 0.1), "a": snappedf(a, 0.01), "st": snappedf(car.in_steer, 0.01), "goal": snappedf(goal, 0.1), "lat": snappedf(my_lat, 0.1), "lo": snappedf(lo, 0.1), "hi": snappedf(hi, 0.1), "gas": snappedf(gas, 0.01), "brk": snappedf(brk, 0.01), "ahd": snappedf(ahead_ds, 0.1), "mult": snappedf(mult, 0.01), "idx": idx, "slip": snappedf(car.slip, 0.01), "latv": snappedf(car.lateral, 0.1), "hd": snappedf(path.hd[idx], 0.001), "yaw": snappedf(car.yaw, 0.001), "vh": snappedf(atan2(car.linear_velocity.x, car.linear_velocity.z), 0.001), "kpp": snappedf(kpp, 0.0001), "ld": snappedf(ld, 0.1), "dist": snappedf(dist, 0.1), "off": snappedf(path.off[idx], 0.1), "dev": snappedf(dev, 0.1)}
		_hist_t += dt
		if _hist_t >= 0.12:
			_hist_t = 0.0
			_hist.append("t%.1f i%d v%.1f/%.1f a%.2f st%.2f lat%.1f k%.4f sl%.2f lv%.1f g%.1f b%.1f" % [_t, idx, v, vt, a, car.in_steer, my_lat, path.lkappa[idx], car.slip, car.lateral, gas, brk])
			if _hist.size() > 16:
				_hist.pop_front()
		if not _exc_done and absf(my_lat) > path.half + 1.5:
			_exc_done = true
			print("EXC ", tag, " lap", lap, " pos=", p.snapped(Vector3(0.1, 0.1, 0.1)), "\n   ", "\n   ".join(_hist))
	# ---- handbrake drifts for the show-offs
	_drift_apply(dt, v, a)
	# ---- nitro
	car.in_nitro = _nitro_decide(dt, v, gas, a, ahead_ds, straight_ahead)
	# ---- recovery
	_recover(dt, v, gas, a)


func _err_apply(dt: float, v: float, aggr: float) -> void:
	if _err_t > 0.0:
		_err_t -= dt
		return
	if _err_cd > 0.0 or v < 22.0:
		return
	var lk := path.lkappa[path.wi(idx + int(45.0 / RacePath.STEP))]
	if lk < 0.012:
		return
	_err_cd = 6.0
	var p_err := (1.0 - float(persona["consist"])) * 0.4 * (0.7 + 0.6 * aggr)
	if rng.randf() < p_err:
		errors += 1
		_err_type = rng.randi() % 3
		_err_t = 1.8 if _err_type != 1 else 0.7


func _drift_apply(dt: float, v: float, a: float) -> void:
	if not bool(persona["drift"]):
		return
	if _drift_t > 0.0:
		_drift_t -= dt
		car.in_handbrake = true
		car.in_gas = maxf(car.in_gas, 0.6)
		return
	if _drift_cd <= 0.0 and v > 20.0 and absf(a) > 0.14 and path.lkappa[path.wi(idx + int(20.0 / RacePath.STEP))] > 0.02:
		_drift_t = 0.35
		_drift_cd = 4.5


func _nitro_decide(dt: float, v: float, gas: float, a: float, ahead_ds: float, straight: bool) -> bool:
	if finished or car.nitro < 0.08:
		_nitro_on = false
		return false
	var ok := straight and gas > 0.9 and absf(a) < 0.05 and v > 22.0
	var thr := 0.30 + (1.0 - float(persona["nitro"])) * 0.45
	if lap >= total_laps - 1 and total_laps > 1:
		thr -= 0.15
	if ahead_ds < 38.0 or _pass_t > 0.0:
		thr -= 0.2
	if _nitro_on:
		if not ok:
			_nitro_off_t += dt
			if _nitro_off_t > 0.35:
				_nitro_on = false
		else:
			_nitro_off_t = 0.0
		return _nitro_on
	if ok and car.nitro > thr:
		_nitro_on = true
		_nitro_off_t = 0.0
	return _nitro_on


func _recover(dt: float, v: float, gas: float, a: float) -> void:
	if absf(v) < 1.5 and _t > 1.0:
		_stuck += dt
	else:
		_stuck = maxf(_stuck - dt * 2.0, 0.0)
	if gas > 0.6 and absf(v) < 2.5 and _t > 1.0:
		_wedge += dt
	else:
		_wedge = maxf(_wedge - dt * 2.0, 0.0)
	if _stuck > 2.2 or _wedge > 1.4:
		_stuck = 0.0
		_wedge = 0.0
		_back = 1.3
		_back_dir = signf(a) if absf(a) > 0.05 else 1.0           # reversing with the wheels turned right swings the nose to the left
		_stuck_count += 1
		if _stuck_count >= 3:
			_stuck_count = 0
			respawn(8.0)
	if absf(a) > 2.1 and absf(v) < 16.0 and _t > 1.0:
		_facing_back += dt                                       # pointing the wrong way after a spin
	else:
		_facing_back = maxf(_facing_back - dt * 2.0, 0.0)
	if _facing_back > 1.6:
		_facing_back = 0.0
		respawn(10.0)
	if car.global_transform.basis.y.y < 0.35:
		_flip += dt
	else:
		_flip = 0.0
	if _flip > 1.5:
		_flip = 0.0
		respawn(10.0)
	elif path.dist2d(car.global_position, idx) > 70.0:
		respawn(10.0)


func respawn(speed_ms: float) -> void:
	respawns += 1
	var i := path.wi(idx + 2)
	if path.loop and idx + 2 >= path.n:
		trk.lap += 1
		lap = trk.lap
	trk.reset(i)
	var d := path.dir_at(i)
	var pos := path.lane_point(i, 0.0)
	pos.y = W.ground_height(pos.x, pos.z, 80.0) + 0.5
	car.reset_to(pos, atan2(d.x, d.z))
	car.linear_velocity = d * speed_ms
	dev = 0.0
	_back = 0.0
	_stuck = 0.0
	_wedge = 0.0
	_flip = 0.0
	_wreck = 0.0
	_pass_t = 0.0
	_def_t = 0.0
	_err_t = 0.0
