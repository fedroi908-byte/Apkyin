extends Node
## Dev tool (headless): crash / flip behaviour on the flat runway. args = <wall|scrape|post|flip|roll> [kmh] [car index]
## wall: head-on into a wall (hold gas 3 s, then reverse 3 s); scrape: shallow angle along a long wall; post: offset hit on a narrow post;
## flip: car dropped upside down, full gas (must not drive); roll: side-roll test.
var gw: GameWorld
var p: Vehicle
var t := 0.0
var test := "wall"
var v0 := 120.0
var wall_face := 0.0
var t_hit := -1.0
var x0 := -3300.0
var zc := 2900.0
var ready_go := false
var shot_path := ""
var cam: Camera3D
var shot_n := 0


func _wall(pos: Vector3, size: Vector3) -> void:
	var b := StaticBody3D.new()
	b.collision_layer = 1
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	b.add_child(cs)
	gw.add_child(b)
	b.global_position = pos


func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	test = a[0] if a.size() > 0 else "wall"
	v0 = float(a[1]) if a.size() > 1 else 120.0
	if a.size() > 2:
		G.selected_car = int(a[2])
	G.start_hour = 11.0
	G.mode = "training"
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)
	await get_tree().process_frame
	await get_tree().process_frame
	p = gw.player
	var y := W.runway_y
	match test:
		"wall":
			wall_face = x0 + 70.0
			_wall(Vector3(wall_face + 0.5, y + 4.0, zc), Vector3(1.0, 8.0, 40.0))
			p.reset_to(Vector3(x0, y + 0.3, zc), PI * 0.5)
			p.linear_velocity = Vector3(v0 / 3.6, 0, 0)
		"scrape":
			_wall(Vector3(x0 + 120.0, y + 4.0, zc - 7.0), Vector3(240.0, 8.0, 1.0))
			p.reset_to(Vector3(x0, y + 0.3, zc), PI * 0.5 + 0.2)
			p.linear_velocity = Vector3(cos(0.2), 0, -sin(0.2)) * (v0 / 3.6)
		"post":
			wall_face = x0 + 70.0
			_wall(Vector3(wall_face + 0.5, y + 4.0, zc + 1.2), Vector3(1.0, 8.0, 1.0))
			p.reset_to(Vector3(x0, y + 0.3, zc), PI * 0.5)
			p.linear_velocity = Vector3(v0 / 3.6, 0, 0)
		"flip":
			p.reset_to(Vector3(x0, y + 1.1, zc), PI * 0.5)
			p.global_transform = Transform3D(p.global_transform.basis.rotated(p.global_transform.basis.z, PI), p.global_position)
		"roll", "brake", "drift":
			p.reset_to(Vector3(x0, y + 0.3, zc), PI * 0.5)
			p.linear_velocity = Vector3(v0 / 3.6, 0, 0)
	if OS.get_environment("DK") != "":
		p.drift_k = float(OS.get_environment("DK"))
	if OS.get_environment("DD") != "":
		p.drift_d = float(OS.get_environment("DD"))
	if a.size() > 3 and a[3] == "noabs":
		p.abs_on = false
	shot_path = OS.get_environment("CT_SHOT")
	ready_go = true
	print("CT ", test, " kmh=", v0, " car=", G.car()["id"], " mass=", p.car_mass)


func _physics_process(dt: float) -> void:
	if not ready_go:
		return
	t += dt
	p.in_brake = 0.0
	p.in_gas = 0.0
	p.in_steer = 0.0
	p.in_handbrake = false
	var up_y := p.global_transform.basis.y.y
	_shot_check()
	match test:
		"wall", "post":
			var gap := wall_face - (p.global_position.x + p.global_transform.basis.z.x * 2.1)
			if t < 3.0 + 1.0 or t_hit < 0.0:
				p.in_gas = 1.0 if p.kmh() < v0 else 0.35
			if gap < 0.6 and t_hit < 0.0:
				t_hit = t
			if t_hit > 0.0 and t > t_hit + 3.0:
				p.in_gas = 0.0
				p.in_brake = 1.0                                  # reverse
			elif t_hit > 0.0:
				p.in_gas = 1.0                                    # keep pushing into the wall
			if int(t * 60.0) % 12 == 0 or (t > 1.2 and t < 1.5):
				print("CT t=%.2f gap=%.2f kmh=%.1f vy=%.2f dmg=%.2f up=%.2f gr=%d ang=%.1f" % [t, gap, p.speed * 3.6, p.linear_velocity.y, p.damage, up_y, _gr(), p.angular_velocity.length()])
			if t > 11.0:
				_done()
		"scrape":
			p.in_gas = 1.0 if p.kmh() < v0 else 0.4
			if int(t * 60.0) % 18 == 0:
				print("CT t=%.2f x=%.1f z=%.2f kmh=%.1f dmg=%.2f up=%.2f yaw=%.2f" % [t, p.global_position.x - x0, p.global_position.z - zc, p.speed * 3.6, p.damage, up_y, p.yaw])
			if t > 8.0:
				_done()
		"flip":
			p.in_gas = 1.0
			p.in_steer = 0.5
			if int(t * 60.0) % 24 == 0:
				print("CT t=%.2f x=%.2f y=%.2f kmh=%.1f up=%.2f gr=%d rpm=%.2f" % [t, p.global_position.x - x0, p.global_position.y - W.runway_y, p.speed * 3.6, up_y, _gr(), p.rpm])
			if t > 6.0:
				_done()
		"brake":
			p.in_brake = 1.0 if t > 0.4 else 0.0
			p.in_gas = 0.0 if t > 0.4 else 0.5
			if int(t * 60.0) % 18 == 0:
				print("CT t=%.2f x=%.1f kmh=%.1f temp=%.2f up=%.2f ang=%.2f yaw=%.2f" % [t, p.global_position.x - x0, p.speed * 3.6, p.brake_temp, up_y, p.angular_velocity.length(), p.yaw])
			if t > 9.0 or (t > 1.0 and p.kmh() < 1.0):
				print("CT stop t=%.2f dist=%.1f m  temp=%.2f" % [t, p.global_position.x - x0, p.brake_temp])
				_done()
		"drift":
			p.in_gas = 1.0 if t > 0.5 else 0.4
			var dm := String(OS.get_cmdline_user_args()[3]) if OS.get_cmdline_user_args().size() > 3 else "release"
			if dm == "hold":
				p.in_steer = 1.0 if t > 0.5 else 0.0
			elif dm == "counter":
				p.in_steer = 1.0 if t > 0.5 and t < 1.6 else (-0.45 if t >= 1.6 and t < 3.5 else 0.0)
			else:
				p.in_steer = 1.0 if t > 0.5 and t < 1.6 else 0.0
			p.in_handbrake = t > 0.5 and t < 1.1
			if int(t * 60.0) % 12 == 0:
				print("CT t=%.2f kmh=%.1f beta=%.0f drift=%s yawrate=%.2f yaw=%.2f x=%.0f z=%.0f" % [t, p.speed * 3.6, rad_to_deg(atan2(p.lateral, maxf(p.speed, 1.0))), p.drifting, p.angular_velocity.y, p.yaw, p.global_position.x - x0, p.global_position.z - zc])
			if t > 6.0:
				_done()
		"roll":
			p.in_gas = 0.6
			p.in_steer = 1.0 if t > 0.5 and t < 2.0 else 0.0
			if int(t * 60.0) % 24 == 0:
				print("CT t=%.2f kmh=%.1f up=%.2f y=%.2f ang=%.1f" % [t, p.speed * 3.6, up_y, p.global_position.y - W.runway_y, p.angular_velocity.length()])
			if t > 8.0:
				_done()


func _shot_check() -> void:
	if shot_path == "" or t_hit < 0.0:
		return
	var dt_after := float(OS.get_environment("CT_SHOT_T")) if OS.get_environment("CT_SHOT_T") != "" else 4.2
	if t < t_hit + dt_after:
		return
	if cam == null:
		cam = Camera3D.new()
		cam.far = 3000.0
		cam.fov = 62.0
		add_child(cam)
		var pp := p.global_position
		var f := p.global_transform.basis.z
		var l := p.global_transform.basis.x
		var side := float(OS.get_environment("CT_SIDE")) if OS.get_environment("CT_SIDE") != "" else 1.0
		cam.global_position = pp + f * 1.4 + l * 5.2 * side + Vector3.UP * 1.7
		cam.look_at(pp + f * 1.2 + Vector3.UP * 0.65, Vector3.UP)
		cam.current = true
	shot_n += 1
	if shot_n == 6:
		get_viewport().get_texture().get_image().save_png(shot_path)
		print("CT shot saved ", shot_path)
		_done()


func _gr() -> int:
	var n := 0
	for g in p._grounded:
		if g:
			n += 1
	return n


func _done() -> void:
	var d := p.dmg
	print("CT dmg zones=%s eng=%.2f rad=%.2f glass=%.2f lampF=%.2f lampR=%.2f susp=%s tyre=%s det=%s overall=%.2f hits=%d" % [d.zone, d.engine, d.radiator, d.glass, d.lamp_f, d.lamp_r, d.susp, d.tyre, d.detached, d.overall(), d.hits])
	print("CT dent0=", p._dents[0], " dir0=", p._dent_dirs[0], " n=", p._dent_n)
	print("CT done")
	get_tree().quit()
