class_name RigidProp
extends RefCounted

var t := 0
var pos := Vector3.ZERO
var rot := Basis.IDENTITY
var iwm := Basis.IDENTITY
var vel := Vector3.ZERO
var w := Vector3.ZERO
var m := 1.0
var im := 1.0
var il := Vector3.ONE
var com := Vector3.ZERO
var pts := PackedVector3Array()
var gh := PackedFloat32Array()
var pr := 0.05
var e := 0.3
var mu := 0.55
var br := 0.5
var anch := false
var anch_w := Vector3.ZERO
var anch_l := Vector3.ZERO
var tear_n := 1.0e9
var torn := false
var node: MeshInstance3D
var rest_t := 0.0
var asleep := false
var age := 0.0
var lift := 0.0
var org := Vector3.ZERO
var snd_t := 0.0
var hit_v := 0.0
var slide := 0.0
var last_vn := 0.0
var tdone := false
var fx := 0


static func make(type: int, origin: Vector3, yaw: float, lf: float) -> RigidProp:
	var a := RigidProp.new()
	a.t = type
	a.m = PropGen.MASS[type]
	a.im = 1.0 / a.m
	var d: Vector3 = PropGen.DIM[type]
	a.il = Vector3(12.0 / (a.m * (d.y * d.y + d.z * d.z)), 12.0 / (a.m * (d.x * d.x + d.z * d.z)), 12.0 / (a.m * (d.x * d.x + d.y * d.y)))
	a.com = Vector3(0.0, PropGen.COM_Y[type], 0.0)
	a.pts = PropGen.samples(type)
	a.gh.resize(a.pts.size())
	a.pr = PropGen.PR[type]
	a.e = PropGen.REST[type]
	a.br = maxf(d.x, d.z) * 0.5 + 0.1
	a.rot = Basis(Vector3.UP, yaw)
	a.org = origin
	a.lift = lf
	a.pos = origin + a.rot * a.com
	a.anch = PropGen.BREAK_N[type] > 0.0
	a.anch_w = origin
	a.anch_l = -a.com
	a.tear_n = PropGen.TEAR_N[type] * 3.0
	a.iwm = a.rot * Basis.from_scale(a.il) * a.rot.transposed()
	return a


func origin_xf() -> Transform3D:
	return Transform3D(rot, pos - rot * com)


func point(i: int) -> Vector3:
	return pos + rot * (pts[i] - com)


func ground() -> void:
	for i in pts.size():
		var wp := point(i)
		var l := lift * (1.0 - smoothstep(1.4, 2.0, Vector2(wp.x - org.x, wp.z - org.z).length()))
		gh[i] = W.ground_height(wp.x, wp.z, wp.y + 1.5) + l


func integrate(h: float) -> void:
	vel.y -= 9.81 * h
	vel *= 1.0 - 0.03 * h
	w *= 1.0 - 0.12 * h


func impulse(wp: Vector3, n: Vector3, vo: Vector3, imo: float, ee: float, mm: float) -> float:
	var r := wp - pos
	var vp := vel + w.cross(r) - vo
	var vn := vp.dot(n)
	last_vn = vn
	if vn >= 0.0:
		return 0.0
	var rn := r.cross(n)
	var k := im + imo + rn.dot(iwm * rn)
	var j := -(1.0 + (ee if vn < -1.5 else 0.0)) * vn / k
	vel += n * (j * im)
	w += iwm * r.cross(n * j)
	var vt := vp - n * vn
	var vl := vt.length()
	if vl > 0.001:
		var td := vt / vl
		var rt := r.cross(td)
		var kt := im + imo + rt.dot(iwm * rt)
		var jt := minf(vl / kt, mm * j)
		vel -= td * (jt * im)
		w -= iwm * r.cross(td * jt)
	return j


func ground_contacts() -> void:
	var maxd := 0.0
	for i in pts.size():
		var wp := point(i)
		var d := gh[i] + pr - wp.y
		if d > 0.0:
			maxd = maxf(maxd, d)
			var j := impulse(Vector3(wp.x, wp.y - pr, wp.z), Vector3.UP, Vector3.ZERO, 0.0, e, mu)
			if j > 0.0:
				hit_v = maxf(hit_v, -last_vn)
				var vt := Vector2(vel.x, vel.z).length()
				slide = maxf(slide, vt)
				if vt > 0.05:
					w *= 0.995
	if maxd > 0.0:
		pos.y += minf(maxd, 0.25) * 0.4


func solve_anchor(h: float) -> float:
	var r := rot * anch_l
	var vp := vel + w.cross(r)
	var sk := Basis(Vector3(0.0, r.z, -r.y), Vector3(-r.z, 0.0, r.x), Vector3(r.y, -r.x, 0.0))
	var sis := sk * iwm * sk
	var k := Basis(Vector3(im, 0.0, 0.0) - sis.x, Vector3(0.0, im, 0.0) - sis.y, Vector3(0.0, 0.0, im) - sis.z)
	var bias := (anch_w - (pos + r)) * (0.25 / h)
	var j := k.inverse() * (bias - vp)
	vel += j * im
	w += iwm * r.cross(j)
	return j.length()


func advance(h: float) -> void:
	vel = vel.limit_length(60.0)
	w = w.limit_length(25.0)
	pos += vel * h
	var ang := w.length()
	if ang > 0.00001:
		rot = (Basis(w / ang, ang * h) * rot).orthonormalized()
	iwm = rot * Basis.from_scale(il) * rot.transposed()


func pair(o: RigidProp) -> void:
	var d := o.pos - pos
	var dl := d.length()
	var rr := br + o.br
	if dl >= rr or dl < 0.001:
		return
	var n := -d / dl
	var wp := pos + d * (br / rr)
	var vo := o.vel + o.w.cross(wp - o.pos)
	var j := impulse(wp, n, vo, o.im, minf(e, o.e), mu)
	if j > 0.0:
		o.vel -= n * (j * o.im)
		o.w -= o.iwm * (wp - o.pos).cross(n * j)
		o.asleep = false
	var push := (rr - dl) * 0.25
	pos += n * push
	o.pos -= n * push
