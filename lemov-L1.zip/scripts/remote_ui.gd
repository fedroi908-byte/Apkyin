class_name RemoteUi
extends CanvasLayer
## Overlays driven by the live-ops client (autoload R): blocking screens (maintenance / forced update / lock),
## the soft "new version" banner, message + gift pop-ups and the content download pill.
## Everything waits for the menu: a race or free roam is never interrupted.

signal route(kind: String, arg: String)

var _block: Control = null
var _block_kind := ""
var _retry_lbl: Label = null
var _retry_t := 0.0
var _popup: Control = null
var _banner: Control = null
var _banner_lbl: Label = null
var _banner_closed := false
var _dl: Control = null
var _dl_lbl: Label = null
var _dl_pct := -1
var _t := 0.0


func _ready() -> void:
	layer = 90
	process_mode = Node.PROCESS_MODE_ALWAYS
	R.progress.connect(_on_progress)
	R.deeplink.connect(_on_deeplink)
	_build_banner()
	_build_dl()


func _on_deeplink(kind: String, arg: String) -> void:
	if kind == "update":
		R.open_url(_update_url())
	else:
		route.emit(kind, arg)


func _update_url() -> String:
	return String(R.update_info().get("url", ""))


func _btn(text: String, cb: Callable, accent: Color) -> Button:
	var b := Ui.button(text, cb, accent, 28, Vector2(400, 68))
	b.alignment = HORIZONTAL_ALIGNMENT_CENTER
	return b


func _top_row(y: float) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.set_anchors_preset(Control.PRESET_TOP_WIDE)
	row.offset_top = y
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(row)
	return row


func _build_banner() -> void:
	var row := _top_row(8.0)
	var pn := Ui.panel(Color(0.04, 0.07, 0.12, 0.92), 22)
	pn.visible = false
	row.add_child(pn)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	pn.add_child(h)
	_banner_lbl = Ui.label("", 22, Ui.GOLD, true)
	_banner_lbl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(_banner_lbl)
	var up := Ui.button(Tx.t("update"), func(): R.open_url(_update_url()), Ui.GOOD, 22, Vector2(170, 46))
	up.alignment = HORIZONTAL_ALIGNMENT_CENTER
	h.add_child(up)
	var x := Ui.button("✕", func():
		_banner_closed = true
		pn.visible = false, Ui.DIM, 22, Vector2(56, 46))
	x.alignment = HORIZONTAL_ALIGNMENT_CENTER
	h.add_child(x)
	_banner = pn


func _build_dl() -> void:
	var row := _top_row(76.0)
	var pn := Ui.panel(Color(0.04, 0.07, 0.12, 0.85), 16)
	pn.visible = false
	row.add_child(pn)
	_dl_lbl = Ui.label("", 18, Ui.ACCENT)
	pn.add_child(_dl_lbl)
	_dl = pn


func _on_progress(done: int, total: int, _label: String) -> void:
	_dl_pct = int(100.0 * float(done) / float(total)) if total > 0 and done < total else -1


func _process(dt: float) -> void:
	if _retry_lbl != null and is_instance_valid(_retry_lbl):
		_retry_t -= dt
		if _retry_t <= 0.0:
			_retry_t = 20.0
			R.check(true)
		_retry_lbl.text = Tx.t("retry_in") % int(ceilf(_retry_t))
	_t += dt
	if _t < 0.25:
		return
	_t = 0.0
	var in_menu: bool = R.menu_active and not R.in_world
	var bi: Array = R.block_info()
	if String(bi[0]) == "":
		_hide_block()
	elif in_menu:
		_show_block(String(bi[0]), String(bi[1]), String(bi[2]))
	var blocked := _block != null
	var ui: Dictionary = R.update_info()
	_banner.visible = in_menu and not blocked and not _banner_closed and bool(ui["available"]) and String(ui["url"]) != ""
	if _banner.visible:
		_banner_lbl.text = Tx.t("new_ver") % String(ui["ver"])
	_dl.visible = in_menu and not blocked and _dl_pct >= 0
	if _dl.visible:
		_dl_lbl.text = "↓  " + Tx.t("dl") % _dl_pct
	_poll_popups(in_menu and not blocked)


# ------------------------------------------------------------------ blocking screens
func _show_block(kind: String, msg: String, url: String) -> void:
	if _block != null and is_instance_valid(_block) and _block_kind == kind and String(_block.get_meta("msg", "")) == msg and String(_block.get_meta("url", "")) == url:
		return
	_hide_block(true)
	_block_kind = kind
	var c := Control.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_STOP
	c.set_meta("msg", msg)
	c.set_meta("url", url)
	add_child(c)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.95)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.add_child(dim)
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.add_child(cc)
	var pn := Ui.panel(Color(0.04, 0.06, 0.1, 0.97), 24)
	pn.custom_minimum_size = Vector2(1000, 0)
	cc.add_child(pn)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 22)
	pn.add_child(v)
	var title := Tx.t("lock_t")
	var body := msg if msg != "" else Tx.t("lock_b")
	var accent := Color(1, 0.3, 0.25)
	if kind == "maint":
		title = Tx.t("maint_t")
		body = msg if msg != "" else Tx.t("maint_b")
		accent = Ui.HOT
	elif kind == "update":
		title = Tx.t("upd_t")
		body = (msg + "\n\n" if msg != "" else "") + Tx.t("upd_b")
		accent = Ui.ACCENT
	var h := Ui.label(title, 56, accent, true)
	h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(h)
	var b := Ui.label(body, 28, Color.WHITE)
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	b.custom_minimum_size = Vector2(920, 0)
	v.add_child(b)
	_retry_lbl = null
	if kind == "maint":
		_retry_lbl = Ui.label("", 20, Ui.DIM)
		_retry_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_retry_t = 20.0
		v.add_child(_retry_lbl)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 18)
	v.add_child(row)
	if kind == "update":
		if url != "":
			row.add_child(_btn(Tx.t("upd_btn"), func(): R.open_url(url), Ui.ACCENT))
	elif kind == "maint":
		row.add_child(_btn(Tx.t("retry"), func(): R.check(true), Ui.ACCENT))
	else:
		row.add_child(_btn(Tx.t("retry"), func(): R.flush_telemetry(true), Ui.ACCENT))
	row.add_child(_btn(Tx.t("quit"), func(): get_tree().quit(), Color(0.9, 0.25, 0.25)))
	c.modulate.a = 0.0
	c.create_tween().tween_property(c, "modulate:a", 1.0, 0.25)
	_block = c


func _hide_block(immediate: bool = false) -> void:
	_retry_lbl = null
	if _block == null:
		return
	var old := _block
	_block = null
	_block_kind = ""
	if not is_instance_valid(old):
		return
	if immediate:
		old.queue_free()
		return
	var t := old.create_tween()
	t.tween_property(old, "modulate:a", 0.0, 0.2)
	t.tween_callback(old.queue_free)


# ------------------------------------------------------------------ messages / gifts
func _poll_popups(ok: bool) -> void:
	if not ok or _popup != null:
		return
	if R.enabled and not G.tel_note:
		G.tel_note = true
		G.save_game()
		_show_popup(Tx.t("tel_t"), Tx.t("tel_b"))
		return
	var p: Array = R.take_popup()
	if not p.is_empty():
		_show_popup(String(p[0]), String(p[1]))


func _show_popup(title: String, body: String) -> void:
	var c := Control.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(c)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.add_child(dim)
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.add_child(cc)
	var pn := Ui.panel(Color(0.04, 0.06, 0.1, 0.97), 24)
	pn.custom_minimum_size = Vector2(900, 0)
	cc.add_child(pn)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 20)
	pn.add_child(v)
	var h := Ui.label(title, 44, Ui.GOLD, true)
	h.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	h.custom_minimum_size = Vector2(820, 0)
	v.add_child(h)
	if body != "":
		var b := Ui.label(body, 26, Color.WHITE)
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.custom_minimum_size = Vector2(820, 0)
		v.add_child(b)
	var ok := _btn(Tx.t("ok"), func():
		G.ui("ui_click")
		if _popup != null and is_instance_valid(_popup):
			_popup.queue_free()
		_popup = null, Ui.GOOD)
	ok.custom_minimum_size = Vector2(300, 66)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(ok)
	v.add_child(row)
	G.ui("win", -10.0)
	c.modulate.a = 0.0
	c.create_tween().tween_property(c, "modulate:a", 1.0, 0.2)
	_popup = c
