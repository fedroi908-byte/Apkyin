extends Node
## Mesh census of car models: user args <light 0/1> <first idx> <count>
func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	var light := (int(a[0]) if a.size() > 0 else 1) == 1
	var first := int(a[1]) if a.size() > 1 else 0
	var cnt := int(a[2]) if a.size() > 2 else 3
	for ci in range(first, mini(first + cnt, G.cars.size())):
		var car: Dictionary = G.cars[ci]
		var r: Dictionary = CarBuilder.build(String(car["model"]), Color(0.8, 0.1, 0.1), Color(0.05, 0.05, 0.06), light)
		var node: Node3D = r["node"]
		var surf := 0
		var verts := 0
		var meshes := 0
		var mats := {}
		for mi in node.find_children("*", "MeshInstance3D", true, false):
			var m: MeshInstance3D = mi
			if m.mesh == null:
				continue
			meshes += 1
			if cnt == 1:
				print("MESH ", m.name, " par ", m.get_parent().name, " surf ", m.mesh.get_surface_count(), " verts ", m.mesh.surface_get_array_len(0))
			for s in m.mesh.get_surface_count():
				surf += 1
				verts += m.mesh.surface_get_array_len(s)
				var mt: Material = m.material_override if m.material_override else m.mesh.surface_get_material(s)
				if cnt == 1 and m.name == "BodyMerged":
					var sm := mt as StandardMaterial3D
					if sm:
						print("  SURF ", s, " ", sm.resource_name, " col ", sm.albedo_color.to_html(true), " tex ", sm.albedo_texture != null, " met ", snappedf(sm.metallic, 0.01), " rgh ", snappedf(sm.roughness, 0.01), " tr ", sm.transparency, " em ", sm.emission_enabled, " ec ", sm.emission.to_html(false), " ee ", snappedf(sm.emission_energy_multiplier, 0.01), " ns ", sm.normal_enabled, " vc ", sm.vertex_color_use_as_albedo, " ds ", sm.cull_mode, " verts ", m.mesh.surface_get_array_len(s))
					else:
						print("  SURF ", s, " ", mt.get_class(), " ", mt.resource_name, " verts ", m.mesh.surface_get_array_len(s))
				mats[mt.get_instance_id() if mt else 0] = 1
		print("CARSTAT ", ci, " ", car["id"], " meshes ", meshes, " surfaces ", surf, " verts ", verts, " mats ", mats.size())
		node.free()
	get_tree().quit()
