class_name Debris
extends Node3D
## One loose crash fragment (body chunk, bumper, lamp / glass shard, wheel): ballistic flight, bounces on the virtual ground, shrinks away.
## A global cap keeps a pile-up cheap.

const MAX_ALIVE := 36
static var alive := 0
static var _mats := {}

var vel := Vector3.ZERO
var spin := Vector3.ZERO
var life := 6.0
var rest_h := 0.05
var bounce := 0.35
var roll := false                   # wheel: spins about its axle with the ground speed
var _life0 := 6.0


static func _mat(key: String, col: Color, metal: float, rough: float, alpha: bool = false, emit: float = 0.0) -> StandardMaterial3D:
	var m: StandardMaterial3D = _mats.get(key)
	if m == null:
		m = StandardMaterial3D.new()
		m.albedo_color = col
		m.metallic = metal
		m.roughness = rough
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		if alpha:
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		if emit > 0.0:
			m.emission_enabled = true
			m.emission = col
			m.emission_energy_multiplier = emit
		_mats[key] = m
	return m


## kind: "panel" (body colour), "dark" (plastic / trim), "glass", "lamp", "chrome"
static func spawn(parent: Node, kind: String, size: Vector3, col: Color, pos: Vector3, v: Vector3, w: Vector3, life_s: float = 6.0) -> Debris:
	if alive >= MAX_ALIVE or parent == null:
		return null
	var d := Debris.new()
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	match kind:
		"panel":
			mi.material_override = _mat("p%08x" % col.to_rgba32(), col, 0.6, 0.35)
		"glass":
			mi.material_override = _mat("glass", Color(0.7, 0.85, 0.95, 0.45), 0.0, 0.05, true)
		"lamp":
			mi.material_override = _mat("lamp", Color(1.0, 0.85, 0.6, 0.7), 0.0, 0.1, true, 0.6)
		"chrome":
			mi.material_override = _mat("chrome", Color(0.75, 0.76, 0.78), 1.0, 0.2)
		_:
			mi.material_override = _mat("dark", Color(0.06, 0.06, 0.065), 0.1, 0.8)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	d.add_child(mi)
	parent.add_child(d)
	d.global_position = pos
	d.rotation = Vector3(randf() * TAU, randf() * TAU, randf() * TAU)
	d.vel = v
	d.spin = w
	d.life = life_s
	d._life0 = life_s
	d.rest_h = minf(size.x, minf(size.y, size.z)) * 0.5
	alive += 1
	return d


## A wheel that came off: rolls away along the ground.
static func spawn_wheel(parent: Node, r: float, w: float, pos: Vector3, v: Vector3, yaw: float) -> Debris:
	if parent == null:
		return null
	var d := Debris.new()
	var tyre := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = w
	cm.radial_segments = 14
	cm.rings = 1
	tyre.mesh = cm
	tyre.material_override = _mat("dark", Color(0.06, 0.06, 0.065), 0.1, 0.8)
	tyre.rotation = Vector3(0, 0, PI * 0.5)
	tyre.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	d.add_child(tyre)
	var rim := MeshInstance3D.new()
	var rm := CylinderMesh.new()
	rm.top_radius = r * 0.62
	rm.bottom_radius = r * 0.62
	rm.height = w * 1.04
	rm.radial_segments = 10
	rm.rings = 1
	rim.mesh = rm
	rim.material_override = _mat("chrome", Color(0.75, 0.76, 0.78), 1.0, 0.2)
	rim.rotation = Vector3(0, 0, PI * 0.5)
	rim.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	d.add_child(rim)
	parent.add_child(d)
	d.global_position = pos
	d.rotation = Vector3(0, yaw, 0)
	d.vel = v
	d.rest_h = r
	d.life = 12.0
	d._life0 = 12.0
	d.roll = true
	d.bounce = 0.45
	alive += 1
	return d


func _exit_tree() -> void:
	alive = maxi(alive - 1, 0)


func _process(dt: float) -> void:
	life -= dt
	if life <= 0.0:
		queue_free()
		return
	vel.y -= 9.81 * dt
	var p := global_position + vel * dt
	var gy := W.ground_height(p.x, p.z, p.y + 1.0)
	if p.y - rest_h < gy:
		p.y = gy + rest_h
		if vel.y < 0.0:
			vel.y = -vel.y * bounce
			if vel.y < 0.9:
				vel.y = 0.0
		var f := clampf(1.0 - (0.5 if roll else 4.0) * dt, 0.0, 1.0)
		vel.x *= f
		vel.z *= f
		spin *= clampf(1.0 - 3.0 * dt, 0.0, 1.0)
	global_position = p
	if roll:
		var hs := Vector2(vel.x, vel.z).length()
		if hs > 0.3:
			rotation.y = lerp_angle(rotation.y, atan2(vel.x, vel.z), clampf(dt * 6.0, 0.0, 1.0))
		rotate_object_local(Vector3.RIGHT, hs / rest_h * dt)
	else:
		rotation += spin * dt
	if life < 0.8:
		scale = Vector3.ONE * clampf(life / 0.8, 0.02, 1.0)
