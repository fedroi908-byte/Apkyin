extends Node
## Dev tool: prints the real shadow setup of the running world. args: <quality> <hour>
var gw: GameWorld
var frames := 0


func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	G.mode = "free"
	G.quality = int(a[0]) if a.size() > 0 else 2
	G.start_hour = float(a[1]) if a.size() > 1 else 16.5
	gw = GameWorld.new()
	gw.autopilot = true
	add_child(gw)


func _process(_dt: float) -> void:
	frames += 1
	if frames == 30:
		var s: DirectionalLight3D = gw.atmo.sun
		print("PROBE q=", G.quality, " sun shadow=", s.shadow_enabled, " mode=", s.directional_shadow_mode, " maxd=", s.directional_shadow_max_distance, " energy=", s.light_energy, " ang=", s.light_angular_distance,
			" bias=", s.shadow_bias, " nbias=", s.shadow_normal_bias, " pancake=", s.directional_shadow_pancake_size, " blend=", s.directional_shadow_blend_splits, " opacity=", s.shadow_opacity)
		print("PROBE sun dir=", -s.global_transform.basis.z, " moon=", gw.atmo.moon.light_energy, " hour=", gw.atmo.get("hour"))
		var cnt := {}
		for mi in gw.player.find_children("*", "MeshInstance3D", true, false):
			var m: MeshInstance3D = mi
			cnt[m.cast_shadow] = int(cnt.get(m.cast_shadow, 0)) + 1
		print("PROBE player cast_shadow histogram ", cnt)
		var sc := {}
		for ch in gw.get_children():
			if ch is GeometryInstance3D:
				sc[ch.name] = (ch as GeometryInstance3D).cast_shadow
		print("PROBE world geometry children ", sc)
		var bc := {}
		for mi in gw.blds.find_children("*", "MeshInstance3D", true, false):
			var m2: MeshInstance3D = mi
			bc[m2.cast_shadow] = int(bc.get(m2.cast_shadow, 0)) + 1
		print("PROBE building cast_shadow histogram ", bc)
		var rc := {}
		for mi in gw.roads.find_children("*", "MeshInstance3D", true, false):
			var m3: MeshInstance3D = mi
			rc[m3.cast_shadow] = int(rc.get(m3.cast_shadow, 0)) + 1
		print("PROBE road cast_shadow histogram ", rc)
		get_tree().quit()
