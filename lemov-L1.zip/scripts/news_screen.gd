class_name NewsScreen
extends Control
## Server news (pinned first) and the community links. Opening it marks everything as read.

signal closed


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.78)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var pn := Ui.panel(Color(0.04, 0.06, 0.1, 0.95), 22)
	pn.custom_minimum_size = Vector2(1180, 780)
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(cc)
	cc.add_child(pn)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	pn.add_child(root)
	var head := HBoxContainer.new()
	root.add_child(head)
	var title := Ui.label(Tx.t("news"), 44, Color.WHITE, true)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	var back := Ui.button(Tx.t("back"), _close, Ui.HOT, 24, Vector2(220, 56))
	back.alignment = HORIZONTAL_ALIGNMENT_CENTER
	head.add_child(back)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(1120, 520)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 14)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(list)
	var seen: Array = R.state.get("seen_news", [])
	var items: Array = R.all_news()
	items.sort_custom(_news_before)
	if items.is_empty():
		list.add_child(Ui.label(Tx.t("no_news"), 26, Ui.DIM))
	for n in items:
		list.add_child(_card(n, not seen.has(String(n["id"]))))
	var links: Array = R.links()
	if not links.is_empty():
		var row := HFlowContainer.new()
		row.add_theme_constant_override("h_separation", 12)
		row.add_theme_constant_override("v_separation", 12)
		root.add_child(row)
		for l in links:
			var u := String(l["url"])
			var b := Ui.button("%s  %s" % [_icon(String(l["icon"])), R.text(l["label"])], func(): R.open_url(u), Ui.ACCENT, 22, Vector2(0, 56))
			b.alignment = HORIZONTAL_ALIGNMENT_CENTER
			row.add_child(b)
	for n in items:
		R.mark_news_seen(String(n["id"]))
	R.track("news_open", {"n": items.size()})
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.2)


static func _news_before(a: Dictionary, b: Dictionary) -> bool:
	if bool(a["pin"]) != bool(b["pin"]):
		return bool(a["pin"])
	return int(a["ts"]) > int(b["ts"])


func _icon(k: String) -> String:
	match k:
		"telegram":
			return "✈"
		"instagram":
			return "◎"
		"youtube":
			return "▶"
		"discord":
			return "☗"
		"mail":
			return "✉"
		_:
			return "↗"


func _card(n: Dictionary, fresh: bool) -> Control:
	var p := Ui.panel(Color(0.06, 0.09, 0.15, 0.92), 14)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 20)
	p.add_child(h)
	var tex: Texture2D = R.texture_of(String(n.get("img", "")))
	if tex != null:
		var im := TextureRect.new()
		im.texture = tex
		im.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		im.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		im.custom_minimum_size = Vector2(300, 170)
		h.add_child(im)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(v)
	var tr := HBoxContainer.new()
	tr.add_theme_constant_override("separation", 12)
	v.add_child(tr)
	if fresh:
		var tag := Ui.label(Tx.t("new_tag"), 18, Color(0.02, 0.04, 0.06), false)
		var tp := Ui.panel(Ui.GOOD, 8)
		tp.add_child(tag)
		tr.add_child(tp)
	var t := Ui.label(R.text(n["title"]), 30, Ui.GOLD if bool(n["pin"]) else Color.WHITE, true)
	t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tr.add_child(t)
	var d := Ui.label(Time.get_date_string_from_unix_time(int(n["ts"])), 16, Ui.DIM)
	v.add_child(d)
	var body := R.text(n["body"])
	if body != "":
		var b := Ui.label(body, 22, Color(0.9, 0.94, 1.0))
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.custom_minimum_size = Vector2(640, 0)
		v.add_child(b)
	for cid in n["cars"]:
		var id := String(cid)
		var nm := id.to_upper()
		for c in G.cars:
			if String(c["id"]) == id:
				nm = String(c["name"])
		var cb := Ui.button(Tx.t("see_car") % nm, func():
			closed.emit()
			queue_free()
			R.open_url("lemov://car/" + id), Ui.GOOD, 20, Vector2(0, 50))
		cb.alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(cb)
	return p


func _close() -> void:
	closed.emit()
	queue_free()
