shader_type spatial;
render_mode cull_disabled, diffuse_burley, specular_schlick_ggx;

global uniform float wetness;
global uniform float night;

uniform sampler2D heightmap : filter_nearest, repeat_disable;
uniform sampler2D splat : filter_linear, repeat_disable;
uniform float world_size = 10000.0;
uniform float hn = 2048.0;
uniform float hmin = -70.0;
uniform float hrange = 1000.0;
uniform float cell = 3.0;

uniform sampler2D grass_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D grass_n : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D rock_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D rock_n : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D sand_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D sand_n : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D pave_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D pave_n : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;

varying vec3 w_pos;
varying vec3 w_nrm;
varying float v_dist;

float hfetch(ivec2 c) {
	int m = int(hn) - 1;
	c = clamp(c, ivec2(0), ivec2(m));
	vec2 t = texelFetch(heightmap, c, 0).rg;
	return hmin + (t.r * 255.0 + t.g * 65280.0) / 65535.0 * hrange;
}

float H(vec2 xz) {
	vec2 u = (xz + world_size * 0.5) / world_size * hn - 0.5;
	ivec2 i = ivec2(floor(u));
	vec2 f = fract(u);
	float a = mix(hfetch(i), hfetch(i + ivec2(1, 0)), f.x);
	float b = mix(hfetch(i + ivec2(0, 1)), hfetch(i + ivec2(1, 1)), f.x);
	return mix(a, b, f.y);
}

void vertex() {
	vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float h = H(wp.xz);
	float c = max(cell, 4.0);
	float hx = H(wp.xz - vec2(c, 0.0)) - H(wp.xz + vec2(c, 0.0));
	float hz = H(wp.xz - vec2(0.0, c)) - H(wp.xz + vec2(0.0, c));
	w_nrm = normalize(vec3(hx, 2.0 * c, hz));
	wp.y = h - COLOR.r * cell * 5.0;
	w_pos = wp;
	v_dist = length((VIEW_MATRIX * vec4(wp, 1.0)).xyz);
	VERTEX = (inverse(MODEL_MATRIX) * vec4(wp, 1.0)).xyz;
	NORMAL = w_nrm;
}

vec3 world_detail_normal(vec4 nm, vec3 wn, float k) {
	vec3 t = normalize(cross(vec3(0.0, 0.0, 1.0), wn));
	vec3 b = cross(wn, t);
	vec3 d = nm.xyz * 2.0 - 1.0;
	return normalize(wn + (t * d.x + b * d.y) * k);
}

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

void fragment() {
	vec3 wn = normalize(w_nrm);
	vec2 uv = w_pos.xz;
	vec4 sp = texture(splat, uv / world_size + 0.5);
	float sum = max(sp.r + sp.g + sp.b + sp.a, 0.0001);
	sp /= sum;

	float far = smoothstep(120.0, 600.0, v_dist);
	float macro = texture(grass_a, uv * 0.0113).g;
	float macro2 = texture(rock_a, uv * 0.0071 + 0.37).g;

	vec3 grass = texture(grass_a, uv * 0.20).rgb;
	vec3 grass_far = texture(grass_a, uv * 0.031).rgb;
	grass = mix(grass, grass_far, 0.55) * (0.78 + 0.5 * macro);
	grass = mix(vec3(dot(grass, vec3(0.333))), grass, 0.7) * vec3(0.86, 0.9, 0.62);
	vec4 gn = texture(grass_n, uv * 0.20);

	vec3 forest = grass * vec3(0.52, 0.47, 0.34) * (0.8 + 0.4 * macro2);
	vec3 sand = texture(sand_a, uv * 0.11).rgb * (0.85 + 0.3 * macro);
	vec3 pave = texture(pave_a, uv * 0.13).rgb * (0.9 + 0.25 * macro2) * 0.85;
	float pl = dot(pave, vec3(0.333));
	pave = mix(vec3(pl), pave, 0.3) * vec3(1.18, 1.08, 0.92) * 1.15;
	pave = mix(pave, grass * 0.9, smoothstep(0.55, 0.75, macro2) * 0.6);
	vec4 sn = texture(sand_n, uv * 0.11);
	vec4 pn = texture(pave_n, uv * 0.13);

	vec3 alb = grass * sp.r + forest * sp.g + sand * sp.b + pave * sp.a;
	vec4 nm = gn * (sp.r + sp.g) + sn * sp.b + pn * sp.a;

	// rock on steep slopes + high altitude, triplanar
	float steep = smoothstep(0.90, 0.68, wn.y);
	float alt_rock = smoothstep(260.0, 480.0, w_pos.y + 60.0 * (macro - 0.5));
	float rock_w = clamp(max(steep, alt_rock * smoothstep(0.97, 0.80, wn.y + 0.2 * alt_rock)), 0.0, 1.0);
	vec3 rock = vec3(0.35);
	if (rock_w > 0.01) {
		vec3 bw = pow(abs(wn), vec3(4.0));
		bw /= bw.x + bw.y + bw.z;
		float s = 0.085;
		rock = texture(rock_a, w_pos.zy * s).rgb * bw.x + texture(rock_a, w_pos.xz * s).rgb * bw.y + texture(rock_a, w_pos.xy * s).rgb * bw.z;
		rock *= 0.8 + 0.5 * macro2;
		vec4 rn = texture(rock_n, w_pos.xz * s) * bw.y + texture(rock_n, w_pos.zy * s) * bw.x + texture(rock_n, w_pos.xy * s) * bw.z;
		nm = mix(nm, rn, rock_w);
	}
	alb = mix(alb, rock, rock_w * (1.0 - sp.a * 0.9));

	// snow
	float snow_line = 505.0 + 55.0 * (macro - 0.5) + 30.0 * (macro2 - 0.5);
	float snow = smoothstep(snow_line - 25.0, snow_line + 40.0, w_pos.y) * smoothstep(0.42, 0.78, wn.y + 0.22);
	alb = mix(alb, vec3(0.88, 0.91, 0.96), snow);

	// distant tint (aerial perspective hint on albedo only)
	alb = mix(alb, alb * vec3(0.92, 0.97, 1.02), far * 0.4);

	float wet = wetness;
	alb *= 1.0 - 0.28 * wet;
	vec3 dn = world_detail_normal(nm, wn, mix(0.9, 0.12, far) * (1.0 - snow * 0.7));
	NORMAL = normalize((VIEW_MATRIX * vec4(dn, 0.0)).xyz);
	ALBEDO = alb;
	ROUGHNESS = mix(0.93, 0.35, wet) * (1.0 - 0.3 * snow);
	SPECULAR = 0.25 + 0.4 * wet + 0.2 * snow;
}
