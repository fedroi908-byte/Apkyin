shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

global uniform float night;
global uniform float tod;
global uniform float wetness;
global uniform float quality;
global uniform vec3 sun_dir;

uniform sampler2D concrete_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D asph_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D grass_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;

// vertex data
//  COLOR.r  style / 32          (palette index)
//  COLOR.g  surface / 10        0 facade, 1 roof, 2 shopfront, 3 solid wall, 4 neon sign, 5 balcony facade,
//                               6 parking lot, 7 lawn/field, 8 aviation light, 9 glass curtain (full height)
//  COLOR.b  floor height / 8
//  COLOR.a  per-building random
//  UV       metres along wall, metres above base   (roof/ground: world xz)
//  UV2      x = bay width / 8, y = window fill (0..1)

varying vec3 w_pos;
varying vec3 w_nrm;
varying float v_dist;

void vertex() {
	w_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	w_nrm = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	v_dist = length((MODELVIEW_MATRIX * vec4(VERTEX, 1.0)).xyz);
}

float hash11(float p) {
	p = fract(p * 0.1031);
	p *= p + 33.33;
	p *= p + p;
	return fract(p);
}
float hash21(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

// box-filtered coverage (pixel footprint w, same units as the coordinate): thin frames / mullions fade out smoothly instead of becoming dashed aliasing lines
float cov_i(float x, float a, float b, float w) {
	w = max(w, 1e-4);
	return clamp(min(x + 0.5 * w, b) - max(x - 0.5 * w, a), 0.0, w) / w;
}
float band_cov(float d, float h, float w) {
	return cov_i(d, -h, h, w);
}
// box-filtered square wave (fract(u) < duty) averaged over a window of width w cycles
float sq_aa(float u, float duty, float w) {
	w = max(w, 1e-4);
	float a = u - 0.5 * w;
	float b = u + 0.5 * w;
	return ((floor(b) - floor(a)) * duty + min(fract(b), duty) - min(fract(a), duty)) / w;
}

// palette: wall colour, glass colour, window frame
void palette(int s, out vec3 wall, out vec3 glass, out vec3 frame, out float metal) {
	metal = 0.0;
	frame = vec3(0.07, 0.07, 0.08);
	glass = vec3(0.07, 0.12, 0.18);
	wall = vec3(0.6);
	if (s == 0) { wall = vec3(0.16, 0.30, 0.38); glass = vec3(0.09, 0.30, 0.42); metal = 1.0; }
	else if (s == 1) { wall = vec3(0.30, 0.22, 0.14); glass = vec3(0.30, 0.20, 0.10); metal = 1.0; }
	else if (s == 2) { wall = vec3(0.55, 0.60, 0.66); glass = vec3(0.30, 0.42, 0.55); metal = 1.0; }
	else if (s == 3) { wall = vec3(0.14, 0.28, 0.22); glass = vec3(0.10, 0.34, 0.26); metal = 1.0; }
	else if (s == 4) { wall = vec3(0.20, 0.22, 0.25); glass = vec3(0.12, 0.18, 0.24); metal = 1.0; }
	else if (s == 5) { wall = vec3(0.72, 0.74, 0.76); glass = vec3(0.18, 0.28, 0.38); metal = 0.7; }
	else if (s == 6) { wall = vec3(0.50, 0.20, 0.14); glass = vec3(0.08, 0.10, 0.14); }                // red brick
	else if (s == 7) { wall = vec3(0.62, 0.48, 0.32); glass = vec3(0.08, 0.10, 0.14); }                // tan brick
	else if (s == 8) { wall = vec3(0.55, 0.54, 0.52); glass = vec3(0.10, 0.13, 0.17); }                // concrete
	else if (s == 9) { wall = vec3(0.82, 0.76, 0.62); glass = vec3(0.09, 0.12, 0.16); }                // cream stucco
	else if (s == 10) { wall = vec3(0.74, 0.70, 0.60); glass = vec3(0.09, 0.12, 0.16); }               // limestone
	else if (s == 11) { wall = vec3(0.36, 0.25, 0.20); glass = vec3(0.08, 0.10, 0.13); }               // brownstone
	else if (s == 12) { wall = vec3(0.90, 0.89, 0.86); glass = vec3(0.10, 0.15, 0.20); }               // white
	else if (s == 13) { wall = vec3(0.80, 0.72, 0.56); glass = vec3(0.10, 0.14, 0.18); }               // beige
	else if (s == 14) { wall = vec3(0.86, 0.74, 0.40); glass = vec3(0.10, 0.14, 0.18); }               // yellow
	else if (s == 15) { wall = vec3(0.56, 0.68, 0.78); glass = vec3(0.10, 0.14, 0.18); }               // light blue
	else if (s == 16) { wall = vec3(0.58, 0.60, 0.62); glass = vec3(0.10, 0.14, 0.18); }               // grey
	else if (s == 17) { wall = vec3(0.72, 0.38, 0.26); glass = vec3(0.10, 0.14, 0.18); }               // terracotta
	else if (s == 18) { wall = vec3(0.60, 0.70, 0.56); glass = vec3(0.10, 0.14, 0.18); }               // sage
	else if (s == 19) { wall = vec3(0.86, 0.60, 0.52); glass = vec3(0.10, 0.14, 0.18); }               // salmon
	else if (s == 20) { wall = vec3(0.35, 0.40, 0.52); glass = vec3(0.10, 0.14, 0.18); }               // slate
	else if (s == 21) { wall = vec3(0.78, 0.80, 0.72); glass = vec3(0.10, 0.14, 0.18); }               // pale green
	else if (s == 22) { wall = vec3(0.44, 0.34, 0.26); glass = vec3(0.10, 0.14, 0.18); }               // wood
	else if (s == 23) { wall = vec3(0.92, 0.84, 0.70); glass = vec3(0.10, 0.14, 0.18); }               // sand
	else if (s == 24) { wall = vec3(0.62, 0.64, 0.66); glass = vec3(0.12, 0.16, 0.20); metal = 0.5; }  // corrugated grey
	else if (s == 25) { wall = vec3(0.24, 0.38, 0.55); glass = vec3(0.12, 0.16, 0.20); metal = 0.5; }  // blue steel
	else if (s == 26) { wall = vec3(0.86, 0.87, 0.88); glass = vec3(0.12, 0.16, 0.20); metal = 0.4; }  // white metal
	else if (s == 27) { wall = vec3(0.50, 0.28, 0.20); glass = vec3(0.12, 0.16, 0.20); metal = 0.3; }  // rust
	else if (s == 28) { wall = vec3(0.45, 0.46, 0.46); glass = vec3(0.12, 0.16, 0.20); }               // dark concrete
	else if (s == 29) { wall = vec3(0.70, 0.55, 0.20); glass = vec3(0.12, 0.16, 0.20); metal = 0.4; }  // ochre
	else if (s == 30) { wall = vec3(0.20, 0.45, 0.30); glass = vec3(0.12, 0.16, 0.20); metal = 0.4; }  // green
	else { wall = vec3(0.65, 0.65, 0.68); metal = 0.3; }
}

bool kind_office(int st) {
	return st >= 24 || st == 8 || st == 16 || st == 5 || st == 12 || st == 26;
}

void fragment() {
	int style = int(COLOR.r * 32.0 + 0.5);
	int surf = int(COLOR.g * 10.0 + 0.5);
	float fh = max(COLOR.b * 8.0, 2.6);
	float rnd = COLOR.a;
	float bw = max(UV2.x * 8.0, 1.5);
	float fill = UV2.y;
	vec3 wall; vec3 glass; vec3 frame; float metal;
	palette(style, wall, glass, frame, metal);
	vec3 n = normalize(w_nrm);

	vec3 alb = wall;
	vec3 emis = vec3(0.0);
	float rough = 0.85;
	float met = 0.0;
	float spec = 0.4;
	float lit_boost = 0.0;
	float far = smoothstep(150.0, 700.0, v_dist);

	vec3 conc = texture(concrete_a, w_pos.xz * 0.15 + w_pos.y * 0.07).rgb;

	if (surf == 1) {
		// roof: gravel / membrane with panels
		vec3 g = texture(asph_a, w_pos.xz * 0.5).rgb;
		alb = mix(vec3(0.20, 0.20, 0.21) * (0.8 + 0.5 * g.g), wall * 0.45, step(0.5, hash11(rnd * 91.0)));
		rough = 0.9;
	} else if (surf == 10) {
		float tl = 0.8 + 0.2 * sin(w_pos.x * 5.0 + w_pos.z * 5.0) * sin(w_pos.x * 2.0 - w_pos.z * 2.0) * (1.0 - smoothstep(0.35, 1.2, fwidth(w_pos.x) * 5.0));
		alb = wall * 0.8 * tl;
		rough = 0.8;
	} else if (surf == 6) {
		// parking lot with bays
		vec3 g = texture(asph_a, w_pos.xz * 0.35).rgb;
		alb = g * 1.1;
		float bay = sq_aa(w_pos.x / 2.7 + 0.07, 0.07, fwidth(w_pos.x) / 2.7);
		float row = sq_aa(w_pos.z / 18.0, 0.28, fwidth(w_pos.z) / 18.0);
		alb = mix(alb, vec3(0.8), bay * row * 0.7);
		rough = 0.8;
	} else if (surf == 7) {
		vec3 g = texture(grass_a, w_pos.xz * 0.2).rgb;
		alb = g * vec3(0.8, 0.92, 0.7);
		rough = 0.95;
	} else if (surf == 8) {
		// aviation obstruction light: red blink at night
		float blink = step(0.5, fract(TIME * 0.8 + rnd));
		alb = vec3(0.2, 0.0, 0.0);
		emis = vec3(1.0, 0.05, 0.03) * (0.15 + 5.0 * blink) * (0.3 + night);
	} else if (surf == 4) {
		// neon sign: colour from palette random
		vec3 nc = 0.5 + 0.5 * cos(6.2831 * (rnd + vec3(0.0, 0.33, 0.67)));
		alb = nc * 0.15;
		emis = nc * (0.4 + 2.2 * night);
	} else {
		// ---- facade: windows with frames, reflections, blinds, curtains, interior lights, relief
		vec2 p = vec2(UV.x, UV.y);
		bool curtain = (surf == 9) || (style < 6 && surf != 3);
		float gw = curtain ? 1.9 : bw;                       // bay width
		vec2 cell = vec2(p.x / gw, p.y / fh);
		vec2 f = fract(cell);
		vec2 id = floor(cell);
		// size of one pixel in cell units: thin lines fade out (fine) and per-window randomness is averaged (lod) before they can shimmer
		float cpx = max(length(vec2(dFdx(cell.x), dFdy(cell.x))), length(vec2(dFdx(cell.y), dFdy(cell.y))));
		float fine = smoothstep(0.045, 0.15, cpx);
		float lod = smoothstep(0.14, 0.5, cpx);
		float hrnd = hash21(id + vec2(rnd * 131.0, rnd * 53.0));
		float hrnd2 = hash21(id * 1.37 + vec2(rnd * 17.0, 3.1));
		float hrnd3 = hash21(id * 2.11 + vec2(9.7, rnd * 41.0));
		float shop = 0.0;
		bool ground = p.y < fh * 1.2;
		// opening geometry (0..1 inside the cell)
		float wx = curtain ? 0.97 : mix(0.46, 0.74, hash11(rnd * 17.0));
		float sill = curtain ? 0.30 : mix(0.20, 0.30, hash11(rnd * 29.0));
		float top = curtain ? 0.98 : mix(0.80, 0.92, hash11(rnd * 5.0));
		if (surf == 2 && ground) { wx = 0.9; sill = 0.07; top = 0.84; shop = 1.0; }
		if (surf == 3) { wx = 0.0; }
		float mx = (1.0 - wx) * 0.5;
		vec2 a0 = vec2(mx, sill);
		vec2 a1 = vec2(1.0 - mx, top);
		float fw = curtain ? 0.012 : 0.05;                   // frame fraction
		// pixel footprint (full width) in cell units: exact box-filtered coverage of every thin line below
		float fwx = abs(dFdx(cell.x)) + abs(dFdy(cell.x)) + 1e-5;
		float fwy = abs(dFdx(cell.y)) + abs(dFdy(cell.y)) + 1e-5;
		float wflag = wx > 0.01 ? 1.0 : 0.0;
		float open_m = cov_i(f.x, a0.x, a1.x, fwx) * cov_i(f.y, a0.y, a1.y, fwy) * wflag;
		float glass_m = cov_i(f.x, a0.x + fw, a1.x - fw, fwx) * cov_i(f.y, a0.y + fw * 1.3, a1.y - fw * 1.3, fwy) * wflag;
		float frame_m = max(open_m - glass_m, 0.0);
		// mullions (residential: cross / split; curtain: vertical)
		float mull = 0.0;
		if (!curtain && shop < 0.5) {
			float k = hash11(rnd * 3.7 + 1.0);
			float mv = band_cov(f.x - 0.5, 0.012, fwx);
			if (k < 0.45) mull = mv;
			else if (k < 0.75) mull = max(mv, band_cov(f.y - mix(a0.y, a1.y, 0.62), 0.012, fwy));
		}
		if (curtain) mull = band_cov(min(f.x, 1.0 - f.x), 0.018, fwx);
		mull *= glass_m;
		glass_m *= 1.0 - mull;
		float frame_all = clamp(frame_m + mull * 0.95, 0.0, 1.0);


		// ---- wall material
		float brick = 0.0;
		vec3 wall_col = wall;
		float height = 0.0;                                    // relief for bump mapping
		if (style == 6 || style == 7 || style == 11) {
			vec2 bp = vec2(p.x / 0.24, p.y / 0.08);
			float row = floor(bp.y);
			float off = 0.5 * mod(row, 2.0);
			float bx = fract(bp.x + off);
			float mort_x = smoothstep(0.03, 0.07, bx) * (1.0 - smoothstep(0.93, 0.97, bx));
			float mort_y = smoothstep(0.08, 0.16, fract(bp.y)) * (1.0 - smoothstep(0.88, 0.95, fract(bp.y)));
			float bpx = max(length(vec2(dFdx(bp.x), dFdy(bp.x))), length(vec2(dFdx(bp.y), dFdy(bp.y))));
			float bf = smoothstep(0.22, 0.65, bpx);          // bricks smaller than ~2 px: average colour instead of mortar noise
			float bm = mix(mort_x * mort_y, 0.82, bf);
			vec3 br = wall * mix(0.72 + 0.4 * hash21(vec2(floor(bp.x + off), row) + rnd * 7.0), 0.92, bf);
			wall_col = mix(vec3(0.62, 0.6, 0.56), br, bm);
			height = bm * 0.012 * (1.0 - bf);
			brick = 1.0;
		} else if (style >= 24 && style <= 27) {
			float cor = mix(0.5 + 0.5 * sin(p.x * 6.283 / 0.32), 0.5, smoothstep(0.25, 0.6, max(length(vec2(dFdx(p.x), dFdy(p.x))), 0.0) / 0.32));
			wall_col = wall * (0.72 + 0.28 * cor);
			height = cor * 0.02;
		} else if (curtain) {
			wall_col = wall * (0.8 + 0.2 * conc.g);
		} else {
			float stucco = texture(concrete_a, p * 0.45).g;
			wall_col = wall * (0.8 + 0.34 * stucco);
			height = stucco * 0.006;
		}
		// horizontal floor slab / cornice lines and pilasters
		float slab_h = curtain ? 0.0 : cov_i(f.y, 0.03, 0.09, fwy);
		float slab = 1.0 - slab_h;
		wall_col *= mix(1.0, 0.82, slab * (curtain ? 0.0 : 1.0));
		height += slab * 0.03 * (curtain ? 0.0 : 1.0) * (1.0 - fine);
		float pil = curtain ? 0.0 : band_cov(min(f.x, 1.0 - f.x), 0.045, fwx);
		height += pil * 0.025 * (1.0 - fine);
		wall_col *= 1.0 - 0.07 * pil;
		// sill ledge below each window, lintel above
		if (!curtain && shop < 0.5 && wx > 0.01) {
			float ledge = cov_i(f.y, a0.y - 0.07, a0.y - 0.005, fwy) * cov_i(f.x, a0.x - 0.05, a1.x + 0.05, fwx);
			height += ledge * 0.05 * (1.0 - fine);
			wall_col = mix(wall_col, wall * 1.15, ledge * 0.6);
		}
		// spandrel (curtain wall): opaque tinted panel in the lower part of every floor
		if (curtain) {
			float spand = 1.0 - smoothstep(0.02, 0.04, f.y - 0.02) * 0.0;
		}
		// weathering
		float stain = quality > 0.5 ? smoothstep(0.55, 0.9, texture(concrete_a, vec2(p.x * 0.11, p.y * 0.015)).g) : 0.0;
		float grime = smoothstep(0.0, 14.0, 14.0 - p.y) * 0.12;
		wall_col *= 1.0 - (curtain ? 0.04 : 0.2) * stain - grime * (curtain ? 0.2 : 1.0);
		alb = wall_col;
		rough = 0.84 - 0.1 * metal;

		// ---- window contents
		if (open_m > 0.01) {
			// frame colour
			vec3 fcol = curtain ? vec3(0.18, 0.2, 0.22) * (0.8 + 0.4 * metal) : mix(vec3(0.92, 0.92, 0.9), vec3(0.08, 0.08, 0.09), step(0.55, hash11(rnd * 61.0)));
			alb = mix(alb, fcol, frame_all);
			height += frame_all * 0.02 - glass_m * 0.04;     // glass sits behind the frame
			if (glass_m > 0.01) {
				vec2 gl_uv = vec2((f.x - a0.x - fw) / max(a1.x - a0.x - 2.0 * fw, 0.01), (f.y - a0.y) / max(a1.y - a0.y, 0.01));
				// interior: ceiling band lit, floor dark, depth gradient
				vec3 room_day = mix(vec3(0.05, 0.045, 0.04), vec3(0.18, 0.17, 0.15), smoothstep(0.55, 1.0, gl_uv.y) * (0.4 + 0.6 * hrnd2));
				// interior walls colour variation
				room_day *= 0.7 + 0.8 * mix(hrnd3, 0.5, lod);
				vec3 gcol = curtain ? mix(glass * 0.6, room_day, 0.28) : room_day;
				// reflection variation: huge soft patches (neighbouring buildings / clouds)
				float refl_noise = quality > 0.5 ? texture(concrete_a, w_pos.xy * 0.004 + w_pos.zy * 0.004 + vec2(rnd, 0.0)).g : 0.5;
				gcol += glass * (0.35 + 0.9 * refl_noise) * (curtain ? 1.0 : 0.25);
				// blinds / curtains (residential only)
				float blind = 0.0;
				float cur = 0.0;
				if (!curtain && shop < 0.5) {
					if (hrnd < 0.28) blind = cov_i(gl_uv.y, 1.0 - hrnd2 * 0.9, 2.0, fwy / max(a1.y - a0.y, 0.01)) * (0.6 + 0.4 * sq_aa(gl_uv.y * 18.0, 0.5, 18.0 * fwy / max(a1.y - a0.y, 0.01)));
					else if (hrnd < 0.5) cur = (1.0 - smoothstep(0.0, 0.28 + 0.2 * hrnd3, min(gl_uv.x, 1.0 - gl_uv.x))) * 0.95;
				}
				if (curtain && hrnd < 0.22) blind = cov_i(gl_uv.y, 1.0 - hrnd2, 2.0, fwy / max(a1.y - a0.y, 0.01)) * 0.85;   // office blinds drawn
				blind = mix(blind, curtain ? 0.1 : 0.1, lod);          // averaged over the windows once they are tiny
				cur = mix(cur, 0.08, lod);
				vec3 bcol = mix(vec3(0.85, 0.82, 0.74), vec3(0.45, 0.5, 0.58), mix(hrnd3, 0.5, lod));
				vec3 ccol = mix(0.4 + 0.5 * cos(6.2831 * (hrnd2 + vec3(0.0, 0.33, 0.67))), vec3(0.5), lod);
				gcol = mix(gcol, bcol * 0.55, blind);
				gcol = mix(gcol, ccol * 0.5, cur);
				// ---- smart occupancy by time of day
				float office = (curtain || kind_office(style)) ? 1.0 : 0.0;
				float t = tod;
				float occ;
				if (office > 0.5) {
					occ = 0.85 * smoothstep(6.5, 8.5, t) * (1.0 - smoothstep(18.0, 22.5, t)) + 0.08 + 0.1 * smoothstep(22.5, 24.0, t) * 0.0;
				} else {
					float eve = smoothstep(16.5, 21.0, t) * (1.0 - smoothstep(22.5, 27.0, t + (t < 5.0 ? 24.0 : 0.0)));
					float morn = smoothstep(5.0, 6.5, t) * (1.0 - smoothstep(7.0, 8.5, t)) * 0.35;
					occ = clamp(0.1 + 0.62 * eve + morn, 0.0, 0.85);
				}
				float lit_on = mix(step(hrnd * 0.9 + 0.05 * hrnd2, occ), occ, lod) * (1.0 - 0.9 * blind * 0.5);
				float l_night = night + 0.15 * smoothstep(0.0, 1.0, 1.0 - night) * step(0.5, 1.0 - night) * 0.0;
				vec3 warm = vec3(1.0, 0.72, 0.38);
				vec3 white = vec3(0.95, 0.97, 1.0);
				vec3 cool = vec3(0.55, 0.72, 1.0);
				float ck = hash21(id * 4.3 + rnd * 7.7);
				vec3 lcol = ck < 0.55 ? warm : (ck < 0.8 ? white : cool);
				if (office > 0.5) lcol = mix(white, cool, step(0.6, ck));
				// TV flicker in some residential rooms
				float tv = (!curtain && ck > 0.93) ? mix(0.6 + 0.4 * sin(TIME * (6.0 + 9.0 * hrnd3) + hrnd * 40.0), 1.0, lod) : 1.0;
				if (!curtain && ck > 0.93) lcol = vec3(0.3, 0.5, 1.0);
				lcol = mix(lcol, vec3(0.9, 0.84, 0.76), lod);
				float room_shade = 0.55 + 0.45 * smoothstep(0.0, 0.5, gl_uv.y) * (1.0 - 0.3 * abs(gl_uv.x - 0.5));
				vec3 lamp = lcol * 0.95 * tv * room_shade;
				lamp = mix(lamp, lamp * (bcol * 1.2), blind) ;
				lamp = mix(lamp, lamp * ccol, cur * 0.7);
				vec3 em = lamp * lit_on * l_night;
				if (shop > 0.5) {
					// shop window: bright display at night, dim by day
					vec3 sc = 0.5 + 0.5 * cos(6.2831 * (hrnd2 + vec3(0.1, 0.4, 0.7)));
					em = mix(sc, vec3(1.0, 0.9, 0.7), 0.4) * (0.15 + 2.0 * night) * step(0.25, hrnd);
					gcol = mix(gcol, sc * 0.3, 0.6);
				}
				alb = mix(alb, gcol, glass_m);
				emis += em * glass_m;
				met = glass_m * (curtain ? 0.55 * metal + 0.2 : 0.0);
				spec = 1.0;
				rough = mix(rough, mix(0.03, 0.12, far), glass_m);
			}
		}
		if (surf == 5) {
			float rail = step(0.04, f.y) * step(f.y, 0.2) * step(0.05, f.x) * step(f.x, 0.95);
			float rail_b = smoothstep(0.0, 0.03, f.y - 0.04) * (1.0 - smoothstep(0.17, 0.2, f.y)) * step(0.06, f.x) * step(f.x, 0.94);
			// glass balustrade + slab edge
			alb = mix(alb, mix(wall * 0.5, vec3(0.1, 0.14, 0.18), 0.5), rail_b * (1.0 - open_m));
			height += rail_b * 0.05;
		}
		// bump from relief using screen-space derivatives
		if (quality > 0.5 && far < 0.8) {
		float dh_x = dFdx(height);
		float dh_y = dFdy(height);
		vec3 dpx = dFdx(VERTEX);
		vec3 dpy = dFdy(VERTEX);
		vec3 r1 = cross(dpy, NORMAL);
		vec3 r2 = cross(NORMAL, dpx);
		float det = dot(dpx, r1);
		vec3 grad = sign(det) * (dh_x * r1 + dh_y * r2);
		float bump_scale = (1.0 - far) * (1.0 - fine);
		NORMAL = normalize(abs(det) * NORMAL - grad * 14.0 * bump_scale);
		}
	}

	float dfar = smoothstep(260.0, 900.0, v_dist);
	if (surf != 1 && surf != 6 && surf != 7 && surf != 8 && surf != 4) {
		alb = mix(alb, mix(wall, glass * 1.6, 0.55) , dfar * 0.75);
		emis *= 1.0 - dfar * 0.3;
	}
	float wet = wetness;
	alb *= 1.0 - 0.18 * wet;
	rough = mix(rough, rough * 0.55, wet);
	ALBEDO = alb;
	ROUGHNESS = clamp(rough, 0.03, 1.0);
	METALLIC = met * (quality > 0.5 ? 1.0 : 0.0);
	SPECULAR = spec;
	EMISSION = emis;
}
