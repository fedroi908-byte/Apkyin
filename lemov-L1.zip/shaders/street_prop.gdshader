shader_type spatial;
render_mode cull_back;

global uniform float night;
global uniform float sig_time;
global uniform float wetness;

void fragment() {
	ALBEDO = COLOR.rgb;
	METALLIC = UV2.x;
	ROUGHNESS = mix(0.85, 0.4, UV2.x) * (1.0 - 0.35 * wetness);
	float code = floor(UV.y + 0.5);
	if (code > 0.5) {
		vec3 ec = vec3(1.0, 0.82, 0.55);
		vec3 dk = vec3(0.2, 0.2, 0.18);
		float on = 0.0;
		if (code < 9.5) {
			on = smoothstep(UV.x, UV.x + 0.08, night);
			if (UV2.y > 1.5) {
				on = 0.0;
			} else if (UV2.y > 0.5) {
				on *= step(0.3, fract(sin(floor(TIME * 8.0) * 12.9898) * 43758.5453));
			}
		} else {
			float ax = step(12.5, code);
			float cl = code - 10.0 - 3.0 * ax;
			float u = mod(sig_time - mod(UV.x * 17.37, 50.0) - ax * 25.0, 50.0);
			float st = u < 20.0 ? 2.0 : (u < 23.0 ? 1.0 : 0.0);
			on = (abs(st - cl) < 0.5 && UV.x > -0.5) ? 1.0 : 0.0;
			ec = cl < 0.5 ? vec3(1.0, 0.1, 0.06) : (cl < 1.5 ? vec3(1.0, 0.6, 0.04) : vec3(0.08, 1.0, 0.3));
			dk = ec * 0.12;
		}
		ALBEDO = mix(dk, ec, on);
		EMISSION = ec * on * 2.2;
	}
}
