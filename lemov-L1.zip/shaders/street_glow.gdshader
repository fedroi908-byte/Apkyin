shader_type spatial;
render_mode unshaded, blend_add, depth_draw_never, cull_disabled, skip_vertex_transform, fog_disabled;

global uniform float night;
global uniform float sig_time;

varying vec2 vc;
varying float vi;
varying float vk;

void vertex() {
	float ci = UV2.x;
	vc = vec2((ci > 0.5 && ci < 2.5) ? 1.0 : -1.0, ci > 1.5 ? 1.0 : -1.0);
	float code = floor(UV.y + 0.5);
	float on = 0.0;
	if (code < 1.5) {
		on = smoothstep(UV.x, UV.x + 0.08, night);
	} else {
		float ax = step(12.5, code);
		float cl = code - 10.0 - 3.0 * ax;
		float u = mod(sig_time - mod(UV.x * 17.37, 50.0) - ax * 25.0, 50.0);
		float st = u < 20.0 ? 2.0 : (u < 23.0 ? 1.0 : 0.0);
		on = abs(st - cl) < 0.5 ? mix(0.45, 1.0, night) : 0.0;
	}
	vec3 vv = (MODELVIEW_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float d = length(vv);
	if (code > 0.5) {
		vv.xy += vc * UV2.y * (1.0 + d * 0.01);
		vk = 1.0;
	} else {
		on *= 1.0 - smoothstep(110.0, 200.0, d);
		vk = 0.0;
	}
	vi = on;
	VERTEX = vv;
}

void fragment() {
	float r2 = dot(vc, vc);
	float f = vk > 0.5 ? pow(max(1.0 - sqrt(r2), 0.0), 2.2) * 1.5 : pow(max(1.0 - r2, 0.0), 2.0) * 0.6;
	ALBEDO = COLOR.rgb * f * vi;
}
