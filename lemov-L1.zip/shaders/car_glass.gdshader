shader_type spatial;
render_mode blend_mix, cull_disabled, depth_draw_opaque, specular_schlick_ggx;
// Car glass: follows the crash deformation and grows a crack network with `crack` (0 = intact tinted glass, 1 = shattered with holes). Voronoi cell borders = cracks.
#include "res://shaders/car_crumple.gdshaderinc"

uniform mat4 world_to_car = mat4(1.0);
uniform float crack = 0.0;
uniform vec4 tint : source_color = vec4(0.05, 0.07, 0.09, 0.42);

varying vec3 v_p;
varying vec3 v_n;

vec2 hash2(vec2 p) {
	p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
	return fract(sin(p) * 43758.5453);
}

void vertex() {
	v_p = VERTEX;
	v_n = NORMAL;
	v_crush = 0.0;
	if (zd_on > 0.5) {
		mat4 m = world_to_car * MODEL_MATRIX;
		vec3 cp = (m * vec4(VERTEX, 1.0)).xyz;
		float a;
		VERTEX += crumple(cp, normalize((m * vec4(NORMAL, 0.0)).xyz), a);
		v_crush = a;
	}
}

void fragment() {
	vec2 uv = (abs(v_n.x) > abs(v_n.z) ? v_p.zy : v_p.xy) * 5.0;
	vec2 ip = floor(uv);
	vec2 fp = fract(uv);
	float d1 = 8.0;
	float d2 = 8.0;
	vec2 id1 = vec2(0.0);
	for (int j = -1; j <= 1; j++) {
		for (int i = -1; i <= 1; i++) {
			vec2 g = vec2(float(i), float(j));
			vec2 r = g + hash2(ip + g) - fp;
			float d = dot(r, r);
			if (d < d1) {
				d2 = d1;
				d1 = d;
				id1 = ip + g;
			} else if (d < d2) {
				d2 = d;
			}
		}
	}
	float edge = sqrt(d2) - sqrt(d1);
	vec2 hh = hash2(id1 + 7.0);
	float cr = max(crack, v_crush * 0.9);
	float on = step(hh.x, cr * 1.15) * step(0.001, cr);
	float px = fwidth(edge) * 1.5 + 0.004;
	float ln = (1.0 - smoothstep(0.03, 0.03 + px, edge)) * on;
	float gone = on * step(0.85, cr) * step(0.6, hh.y);          // heavily damaged glass loses whole chunks
	vec3 col = mix(tint.rgb, vec3(0.85, 0.9, 0.95), clamp(ln * 0.85 + on * 0.08, 0.0, 1.0));
	col = mix(col, vec3(0.02), zd2.z * 0.85);
	ALBEDO = col;
	ALPHA = clamp(tint.a + ln * 0.55 + on * cr * 0.22 + zd2.z * 0.4, 0.0, 1.0) * (1.0 - gone);
	ROUGHNESS = mix(0.04, 0.3, on * cr);
	SPECULAR = 1.0;
	METALLIC = 0.0;
}
