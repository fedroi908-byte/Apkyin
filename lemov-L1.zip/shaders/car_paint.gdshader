shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

global uniform float wetness;
global uniform float night;
#include "res://shaders/car_crumple.gdshaderinc"

uniform vec3 base_color : source_color = vec3(0.8, 0.1, 0.1);
uniform vec3 accent_color : source_color = vec3(0.05, 0.05, 0.06);
uniform float flake_amount = 0.18;
uniform float stripe = 0.0;          // 0 none, 1 centre racing stripes, 2 side stripes
uniform float body_len = 4.6;
uniform float body_wid = 1.9;
uniform float wheelbase = 2.8;
uniform float belt_y = 1.0;
uniform float pearl = 0.5;           // colour-shift paint amount
uniform float dirt = 0.0;
uniform float underglow = 0.0;

uniform vec4 dents[16];
uniform vec4 dent_dirs[16];
uniform float damage = 0.0;
uniform mat4 car_to_world;
uniform mat4 world_to_car = mat4(1.0);     // inverse of car_to_world, computed on the CPU (no per-vertex inverse())
uniform int dent_n = 0;                    // number of active dents (0 = the loop below costs nothing)
uniform float panel_lines = 1.0;

varying vec3 l_pos;
varying float v_dent;
varying vec3 l_nrm;
varying vec3 w_pos;
void vertex() {
	vec3 cp = (world_to_car * MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	vec3 disp = vec3(0.0);
	float dsum = 0.0;
	for (int i = 0; i < dent_n; i++) {
		float amt = dents[i].w;
		if (amt > 0.0) {
			vec3 d = cp - dents[i].xyz;
			float r = 0.55 + amt * 1.4;
			float f = exp(-dot(d, d) / (r * r));
			float rough = 0.55 + 0.45 * sin(d.x * 17.0 + d.z * 13.0 + d.y * 9.0);
			disp += dent_dirs[i].xyz * amt * f * (0.7 + 0.5 * rough);
			dsum += f * amt;
		}
	}
	float cr = 0.0;
	if (zd_on > 0.5) {
		disp += crumple(cp, normalize((world_to_car * MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz), cr);
	}
	v_crush = cr;
	v_dent = clamp(dsum * 3.0, 0.0, 1.0);
	VERTEX += disp;                          // the body mesh sits at the car origin (no rotation), so car space == model space
	l_pos = cp + disp;
	l_nrm = (world_to_car * MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz;
	w_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

float h21(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

float line(float d, float w, float px) {
	return 1.0 - smoothstep(w, w + px, abs(d));
}

void fragment() {
	vec3 n = normalize(l_nrm);
	float px = 0.004 + 0.0008 * length(VERTEX);
	vec3 col = base_color;
	// pearl: colour shifts toward accent with view angle
	float fres = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 2.5);
	col = mix(col, mix(col, accent_color * 1.8 + col * 0.3, 0.65), fres * pearl);
	// metallic flakes: sparkles in a fine cell grid; each flake has its own orientation vs the view
	vec3 fp = floor(l_pos * 700.0);
	float fr = h21(fp.xy + fp.z * 17.3);
	float sparkle = step(0.82, fr) * pow(abs(sin(fr * 90.0 + dot(VIEW, vec3(7.0, 3.0, 5.0)))), 20.0);
	col += sparkle * flake_amount * 0.9;
	float rough = 0.22;
	// panel gaps: doors, hood, trunk, fuel flap (only on mostly vertical sides and on top)
	float gap = 0.0;
	float side = smoothstep(0.55, 0.85, abs(n.x));
	float top = smoothstep(0.6, 0.9, n.y);
	float zf = body_len * 0.5;
	float door_f = wheelbase * 0.30;
	float door_r = -wheelbase * 0.30;
	float door_m = wheelbase * 0.02;
	gap += side * line(l_pos.z - door_f, 0.004, px) * step(0.4, l_pos.y) * step(l_pos.y, belt_y + 0.02);
	gap += side * line(l_pos.z - door_r, 0.004, px) * step(0.4, l_pos.y) * step(l_pos.y, belt_y + 0.02);
	gap += side * line(l_pos.z - door_m, 0.004, px) * step(0.4, l_pos.y) * step(l_pos.y, belt_y + 0.02);
	gap += side * line(l_pos.y - 0.4, 0.004, px) * step(door_r, l_pos.z) * step(l_pos.z, door_f);
	gap += top * line(l_pos.z - zf * 0.52, 0.004, px);            // hood line
	gap += top * line(l_pos.z + zf * 0.62, 0.004, px);            // trunk line
	gap += top * line(abs(l_pos.x) - body_wid * 0.40, 0.003, px) * step(zf * 0.52, l_pos.z);   // hood edge
	col *= 1.0 - clamp(gap * panel_lines, 0.0, 1.0) * 0.75;
	// door handles
	float hx = line(l_pos.z - (door_f + door_m) * 0.5 + 0.35, 0.09, px * 3.0) * line(l_pos.y - belt_y + 0.08, 0.012, px);
	hx += line(l_pos.z - (door_r + door_m) * 0.5 + 0.35, 0.09, px * 3.0) * line(l_pos.y - belt_y + 0.08, 0.012, px);
	col = mix(col, vec3(0.04), side * clamp(hx, 0.0, 1.0));
	// stripes
	float st = 0.0;
	if (stripe > 0.5 && stripe < 1.5) {
		st = line(abs(l_pos.x) - 0.2, 0.07, px) * top;
		st += line(l_pos.x, 0.07, px) * 0.0;
	} else if (stripe > 1.5) {
		st = side * line(l_pos.y - 0.62, 0.05, px) + side * line(l_pos.y - 0.5, 0.015, px);
	}
	col = mix(col, accent_color * 1.4, clamp(st, 0.0, 1.0));
	// lower dirt and rain streaks
	float low = smoothstep(0.62, 0.22, l_pos.y);
	col *= 1.0 - (0.35 * low * dirt);
	float wet = wetness;
	rough = mix(rough, 0.06, wet * 0.5);
	col *= 1.0 - 0.1 * wet;
	// underglow
	vec3 em = vec3(0.0);
	float ug = smoothstep(0.34, 0.2, l_pos.y) * underglow * (0.3 + 0.7 * night);
	em += accent_color * ug * 3.0 + (accent_color + vec3(0.2)) * ug;
	col = mix(col, vec3(0.05, 0.045, 0.045), v_dent * 0.5 + damage * 0.18 * h21(floor(l_pos.xz * 9.0)));
	col = mix(col, vec3(0.015), zd2.z * 0.9);
	rough += v_dent * 0.5;
	float bare = 0.0;
	if (v_crush > 0.02) {
		// crushed panels: paint flaked off to bare metal, soot, wrinkled shading
		float cn = h21(floor(l_pos.xz * 33.0) + floor(l_pos.y * 27.0) * 3.1);
		bare = step(0.6, cn) * smoothstep(0.2, 0.8, v_crush);
		col = mix(col, vec3(0.5, 0.51, 0.53), bare * 0.7);
		col = mix(col, vec3(0.03), v_crush * 0.4 * (1.0 - bare));
		rough += v_crush * 0.45;
		float a1 = l_pos.x * 23.0 + l_pos.y * 9.0;
		float a2 = l_pos.z * 19.0 + l_pos.y * 13.0;
		vec3 nn = normalize(n + vec3(23.0 * cos(a1) * sin(a2), 0.0, 19.0 * sin(a1) * cos(a2)) * 0.016 * v_crush);
		NORMAL = normalize((VIEW_MATRIX * car_to_world * vec4(nn, 0.0)).xyz);
	}
	ALBEDO = col;
	METALLIC = mix(0.65, 0.9, bare);
	ROUGHNESS = rough + 0.25 * low * dirt + bare * 0.15;
	SPECULAR = 0.7;
	CLEARCOAT = 1.0 - clamp(v_crush * 1.5, 0.0, 1.0);
	CLEARCOAT_ROUGHNESS = 0.03;
	EMISSION = em;
}
