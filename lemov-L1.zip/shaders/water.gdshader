shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_disabled, diffuse_lambert, specular_schlick_ggx;

global uniform float night;

uniform sampler2D heightmap : filter_nearest, repeat_disable;
uniform float world_size = 10000.0;
uniform float hn = 2048.0;
uniform float hmin = -70.0;
uniform float hrange = 1000.0;
uniform float level = 0.0;
uniform vec3 shallow_col : source_color = vec3(0.10, 0.55, 0.55);
uniform vec3 deep_col : source_color = vec3(0.01, 0.07, 0.17);
uniform float flow = 0.0;           // >0: river (ripples stretched along uv.y)
uniform float wave_amp = 1.0;

varying vec3 w_pos;

float hfetch(ivec2 c) {
	int m = int(hn) - 1;
	c = clamp(c, ivec2(0), ivec2(m));
	vec2 t = texelFetch(heightmap, c, 0).rg;
	return hmin + (t.r * 255.0 + t.g * 65280.0) / 65535.0 * hrange;
}
float H(vec2 xz) {
	vec2 u = (xz + world_size * 0.5) / world_size * hn - 0.5;
	ivec2 i = ivec2(floor(u));
	vec2 f = fract(u);
	float a = mix(hfetch(i), hfetch(i + ivec2(1, 0)), f.x);
	float b = mix(hfetch(i + ivec2(0, 1)), hfetch(i + ivec2(1, 1)), f.x);
	return mix(a, b, f.y);
}

float hash(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

// analytic gradient of a few travelling waves
vec2 wave_grad(vec2 p, float t) {
	vec2 g = vec2(0.0);
	const vec4 W0 = vec4(0.8, 0.6, 0.11, 1.1);
	const vec4 W1 = vec4(-0.5, 0.86, 0.19, 1.5);
	const vec4 W2 = vec4(0.97, -0.25, 0.37, 2.3);
	const vec4 W3 = vec4(-0.2, -0.98, 0.71, 3.1);
	vec4 ws[4] = vec4[4](W0, W1, W2, W3);
	float amps[4] = float[4](0.42, 0.28, 0.16, 0.09);
	for (int i = 0; i < 4; i++) {
		vec2 d = ws[i].xy;
		float k = ws[i].z;
		float ph = dot(d, p) * k + t * ws[i].w;
		g += d * k * amps[i] * cos(ph);
	}
	return g * wave_amp;
}

void vertex() {
	w_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	float t = TIME;
	vec2 p = w_pos.xz;
	vec2 pp = flow > 0.0 ? vec2(p.x * 0.8, p.y * 0.8) : p;
	vec2 g = wave_grad(pp, t);
	// fine ripples
	float n1 = vnoise(p * 0.9 + vec2(t * 0.35, t * 0.2));
	float n2 = vnoise(p * 1.7 - vec2(t * 0.28, -t * 0.4));
	g += (vec2(n1, n2) - 0.5) * 0.18 * wave_amp;
	vec3 wn = normalize(vec3(-g.x, 1.0, -g.y));
	NORMAL = normalize((VIEW_MATRIX * vec4(wn, 0.0)).xyz);

	float ground = H(p);
	float depth = max(level - ground, 0.0);
	float dnorm = clamp(depth / 45.0, 0.0, 1.0);
	vec3 col = mix(shallow_col, deep_col, pow(dnorm, 0.45));
	// seabed visible in shallows
	col = mix(col * 1.35 + vec3(0.04, 0.06, 0.03), col, smoothstep(0.0, 6.0, depth));
	// foam along the shore
	float shore = 1.0 - smoothstep(0.0, 1.7, depth);
	float fn = vnoise(p * 0.55 + vec2(0.0, t * 0.6)) * 0.6 + vnoise(p * 1.9 - vec2(t * 0.5, 0.0)) * 0.4;
	float ring = smoothstep(0.35, 0.8, fn + 0.55 * sin(depth * 3.0 - t * 1.4 + fn * 4.0)) * (1.0 - smoothstep(0.0, 4.0, depth)) * 0.6;
	float foam = clamp(shore * (0.55 + fn) + ring, 0.0, 1.0);
	col = mix(col, vec3(0.92, 0.96, 0.98), foam);
	// river: whitewater on fast sections is not simulated; slightly murky
	if (flow > 0.0) {
		col = mix(col, vec3(0.12, 0.28, 0.30), 0.35);
	}
	ALBEDO = col;
	ROUGHNESS = mix(0.06, 0.55, foam);
	SPECULAR = 0.8;
	METALLIC = 0.0;
	ALPHA = clamp(0.30 + depth * 0.55, 0.0, 0.94) * (1.0 - 0.0 * foam);
	ALPHA = max(ALPHA, foam * 0.95);
	EMISSION = vec3(0.0);
}
