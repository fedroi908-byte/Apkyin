shader_type spatial;
render_mode diffuse_lambert, specular_schlick_ggx;
// Cheap car paint for LOW/MEDIUM phones: no clear-coat, no flake hash, no panel gaps; keeps colour shift, stripes, dirt, wet look, dents.

global uniform float wetness;
global uniform float night;
#include "res://shaders/car_crumple.gdshaderinc"

uniform vec3 base_color : source_color = vec3(0.8, 0.1, 0.1);
uniform vec3 accent_color : source_color = vec3(0.05, 0.05, 0.06);
uniform float flake_amount = 0.18;
uniform float stripe = 0.0;
uniform float body_len = 4.6;
uniform float body_wid = 1.9;
uniform float wheelbase = 2.8;
uniform float belt_y = 1.0;
uniform float pearl = 0.5;
uniform float dirt = 0.0;
uniform float underglow = 0.0;
uniform vec4 dents[16];
uniform vec4 dent_dirs[16];
uniform float damage = 0.0;
uniform mat4 car_to_world;
uniform mat4 world_to_car = mat4(1.0);
uniform int dent_n = 0;
uniform float panel_lines = 0.0;

varying vec3 l_pos;
varying float v_dent;
void vertex() {
	vec3 cp = (world_to_car * MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	vec3 disp = vec3(0.0);
	float dsum = 0.0;
	for (int i = 0; i < dent_n; i++) {
		float amt = dents[i].w;
		if (amt > 0.0) {
			vec3 d = cp - dents[i].xyz;
			float r = 0.55 + amt * 1.4;
			float f = exp(-dot(d, d) / (r * r));
			disp += dent_dirs[i].xyz * amt * f;
			dsum += f * amt;
		}
	}
	float cr = 0.0;
	if (zd_on > 0.5) {
		disp += crumple(cp, normalize((world_to_car * MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz), cr);
	}
	v_crush = cr;
	v_dent = clamp(dsum * 3.0, 0.0, 1.0);
	VERTEX += disp;
	l_pos = cp + disp;
}

float line(float d, float w, float px) {
	return 1.0 - smoothstep(w, w + px, abs(d));
}

void fragment() {
	vec3 col = base_color;
	float fres = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 2.0);
	col = mix(col, mix(col, accent_color * 1.8 + col * 0.3, 0.65), fres * pearl);
	if (stripe > 0.5) {
		float px = 0.01;
		float st = 0.0;
		if (stripe < 1.5) {
			st = line(abs(l_pos.x) - 0.2, 0.07, px) * step(0.8, l_pos.y);
		} else {
			st = line(l_pos.y - 0.62, 0.05, px);
		}
		col = mix(col, accent_color * 1.4, clamp(st, 0.0, 1.0));
	}
	float low = smoothstep(0.62, 0.22, l_pos.y);
	col *= 1.0 - (0.35 * low * dirt);
	col *= 1.0 - 0.1 * wetness;
	col = mix(col, vec3(0.05, 0.045, 0.045), v_dent * 0.5 + damage * 0.12);
	col = mix(col, vec3(0.03), v_crush * 0.45);
	col = mix(col, vec3(0.015), zd2.z * 0.9);
	float ug = smoothstep(0.34, 0.2, l_pos.y) * underglow * (0.3 + 0.7 * night);
	ALBEDO = col;
	METALLIC = 0.55;
	ROUGHNESS = mix(0.26, 0.1, wetness * 0.5) + v_dent * 0.4 + v_crush * 0.4 + 0.2 * low * dirt;
	SPECULAR = 0.65;
	EMISSION = accent_color * ug * 3.0;
}
