shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;
// Generic car surface (trim, plastic, chrome, lamps, interior) that follows the crash deformation. Replaces StandardMaterial3D on body meshes.
#include "res://shaders/car_crumple.gdshaderinc"

uniform mat4 world_to_car = mat4(1.0);
uniform vec4 albedo : source_color = vec4(1.0);
uniform float use_vc = 1.0;            // vertex colour is the albedo (game-LOD models)
uniform float vc_srgb = 0.0;
uniform sampler2D albedo_tex : source_color, filter_linear_mipmap, repeat_enable;
uniform float use_tex = 0.0;
uniform vec4 uv_so = vec4(1.0, 1.0, 0.0, 0.0);
uniform float metallic_v = 0.1;
uniform float rough_v = 0.55;
uniform float spec_v = 0.5;
uniform vec3 emit_col : source_color = vec3(0.0);
uniform float emit_energy = 0.0;

void vertex() {
	v_crush = 0.0;
	if (zd_on > 0.5) {
		mat4 m = world_to_car * MODEL_MATRIX;
		vec3 cp = (m * vec4(VERTEX, 1.0)).xyz;
		float a;
		VERTEX += crumple(cp, normalize((m * vec4(NORMAL, 0.0)).xyz), a);
		v_crush = a;
	}
}

void fragment() {
	vec3 col = albedo.rgb;
	if (use_vc > 0.5) {
		vec3 vc = vc_srgb > 0.5 ? pow(COLOR.rgb, vec3(2.2)) : COLOR.rgb;
		col *= vc;
	}
	if (use_tex > 0.5) {
		col *= texture(albedo_tex, UV * uv_so.xy + uv_so.zw).rgb;
	}
	col = mix(col, vec3(0.02), zd2.z * 0.9);
	col = mix(col, vec3(0.03), v_crush * 0.5);
	ALBEDO = col;
	METALLIC = metallic_v;
	ROUGHNESS = clamp(rough_v + v_crush * 0.3 + zd2.z * 0.3, 0.0, 1.0);
	SPECULAR = spec_v;
	EMISSION = emit_col * emit_energy * (1.0 - zd2.z * 0.8);
}
