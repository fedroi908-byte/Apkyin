shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

global uniform float wetness;
global uniform float night;
global uniform float quality;

uniform sampler2D asph_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D asph_n : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D asph_r : hint_default_white, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D sand_a : source_color, filter_linear_mipmap_anisotropic, repeat_enable;

// vertex data:
//  COLOR.r = style/10   (0 dirt, 1 street, 2 avenue, 3 highway, 4 runway, 5 track, 6 mountain, 7 taxi, 8 junction patch)
//  COLOR.g = width/64   (junction: half size/64)
//  COLOR.b = per-road random
//  UV  = (across 0..1, along metres)
//  UV2 = (metres from start, metres to end)
varying vec3 w_pos;
varying float v_dist;

void vertex() {
	w_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	v_dist = length((MODELVIEW_MATRIX * vec4(VERTEX, 1.0)).xyz);
}

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

float aa_line(float d, float half_w, float px) {
	return 1.0 - smoothstep(half_w - px, half_w + px, abs(d));
}

// box-filtered square wave: average of (fract(u) < duty) over a window of width w (cycles) -> no stair steps / shimmer at distance
float sq_aa(float u, float duty, float w) {
	w = max(w, 1e-4);
	float a = u - 0.5 * w;
	float b = u + 0.5 * w;
	return ((floor(b) - floor(a)) * duty + min(fract(b), duty) - min(fract(a), duty)) / w;
}

float dash(float s, float period, float duty) {
	return sq_aa(s / period, duty, fwidth(s) / period);
}

void fragment() {
	int style = int(COLOR.r * 10.0 + 0.5);
	float width = COLOR.g * 64.0;
	float rnd = COLOR.b;
	vec2 wuv = w_pos.xz;
	vec3 asph = texture(asph_a, wuv * 0.30).rgb;
	vec3 asph2 = texture(asph_a, wuv * 0.037).rgb;
	vec3 alb = asph * (0.75 + 0.5 * asph2.g) * 1.05;
	float lum = dot(alb, vec3(0.333));
	alb = mix(vec3(lum), alb, 0.35) * vec3(1.04, 1.0, 0.94);
	vec3 nrm_tex = texture(asph_n, wuv * 0.30).rgb;
	float rough = texture(asph_r, wuv * 0.30).r;

	float m = (UV.x - 0.5) * width;          // metres from road centre line
	float s = UV.y;
	float px = 0.05 + 0.0015 * v_dist;       // antialias width grows with distance
	float mark = 0.0;
	vec3 mark_col = vec3(0.86);
	float yellow = 0.0;
	float rubber = 0.0;
	float far = smoothstep(80.0, 260.0, v_dist);

	if (style == 0) {
		// dirt track: mix sand colour, ruts
		vec3 dirt = texture(sand_a, wuv * 0.18).rgb * vec3(0.78, 0.66, 0.5);
		float rut = smoothstep(0.35, 0.0, abs(abs(m) - 1.0)) * 0.35;
		float edge = smoothstep(width * 0.5, width * 0.5 - 1.1, abs(m));
		alb = mix(alb * 0.5, dirt, 0.85) * (1.0 - rut);
		rough = 0.95;
	} else {
		float hw = width * 0.5;
		// wear: tyre tracks and oil drip in lane centres
		float lanes = max(floor(width / 3.8), 2.0);
		float lane_w = width / lanes;
		float lm = mod(m + hw, lane_w) - lane_w * 0.5;
		rubber = (aa_line(lm - 0.85, 0.30, 0.25) + aa_line(lm + 0.85, 0.30, 0.25)) * 0.5;
		rubber *= smoothstep(0.35, 0.75, texture(asph_a, vec2(s * 0.021, m * 0.04)).g) * 0.9;
		alb *= 1.0 - 0.28 * rubber;
		rough = mix(rough, 0.55, rubber * 0.5);
		float edge_off = hw - 0.45;
		if (style == 1) {
			yellow = aa_line(m, 0.07, px) * dash(s, 10.0, 0.5);
			mark += aa_line(abs(m) - edge_off, 0.06, px) * 0.8;
		} else if (style == 2) {
				// avenue: double yellow median, lane dashes between every lane, edge lines
				yellow = max(aa_line(m - 0.16, 0.06, px), aa_line(m + 0.16, 0.06, px));
				mark += aa_line(abs(m) - edge_off, 0.09, px);
				float ln = (hw - 0.45) / max(floor(hw / 3.6), 1.0);
				float k = abs(m) / ln;
				mark += aa_line((fract(k + 0.5) - 0.5) * ln, 0.07, px) * dash(s, 9.0, 0.35) * step(1.5, k) * step(k, hw / ln - 0.6);
			} else if (style == 3) {
				if (width > 20.0) {
					// highway: raised concrete median with yellow edges, 3 lanes per side, solid edges
					float med = 1.0 - smoothstep(0.9, 1.0, abs(m) / 1.1);
					yellow = max(aa_line(abs(m) - 1.25, 0.09, px), 0.0);
					mark += aa_line(abs(m) - edge_off, 0.14, px);
					float ln = (hw - 1.4) / 3.0;
					float k = (abs(m) - 1.4) / ln;
					mark += aa_line((fract(k + 0.5) - 0.5) * ln, 0.08, px) * dash(s, 12.0, 0.33) * step(0.5, k) * step(k, 2.6);
					alb = mix(alb, vec3(0.55, 0.55, 0.53) * (0.9 + 0.2 * asph2.g), med);
				} else {
					yellow = (width > 15.0) ? max(aa_line(m - 0.14, 0.06, px), aa_line(m + 0.14, 0.06, px)) : aa_line(m, 0.07, px) * dash(s, 14.0, 0.55);
					mark += aa_line(abs(m) - edge_off, 0.09, px);
					if (width > 15.0) mark += aa_line(abs(m) - hw * 0.5, 0.07, px) * dash(s, 12.0, 0.33);
				}
			} else if (style == 6) {
			yellow = aa_line(m, 0.07, px) * dash(s, 11.0, 0.5);
			mark += aa_line(abs(m) - edge_off, 0.08, px);
		} else if (style == 7) {
			yellow = aa_line(m, 0.1, px);
			mark += aa_line(abs(m) - edge_off, 0.12, px) * 0.0;
		} else if (style == 4) {
			// runway: centre dashes, edge lines, threshold bars, numbers area
			mark += aa_line(m, 0.45, px) * dash(s, 50.0, 0.6);
			mark += aa_line(abs(m) - (hw - 0.8), 0.25, px);
			float to_end = min(UV2.x, UV2.y);
			float bars = step(0.0, to_end - 12.0) * step(to_end, 42.0);
			float bar = sq_aa((abs(m) - 4.0) / 3.2, 0.55, fwidth(m) / 3.2) * step(4.0, abs(m)) * step(abs(m), hw - 3.0);
			mark += bars * bar;
			float touch = step(0.0, to_end - 300.0) * step(to_end, 340.0) * step(2.0, abs(m)) * step(abs(m), 8.0) * sq_aa(abs(m) / 6.0, 0.7, fwidth(m) / 6.0);
			mark += touch;
			alb *= 1.12;
		} else if (style == 5) {
			mark += aa_line(abs(m) - edge_off, 0.12, px) * 0.0;
			// start / finish chequer
			float sf = step(s, 3.0) * step(0.0, s);
			float ck = mod(floor(m / 1.0) + floor(s / 1.0), 2.0);
			float s0 = (UV2.x < 3.0) ? 1.0 : 0.0;
			alb = mix(alb, vec3(mix(0.04, 0.95, ck)), s0 * 0.95);
		} else if (style == 8) {
			// junction patch: UV spans the whole square, COLOR.g is half size in metres/64
			vec2 p = (UV - 0.5) * (width);          // metres from patch centre
			float inner = width * 0.5 - 3.0;
			vec2 ap = abs(p);
			// zebra bands on the four sides
			float wpx = fwidth(p.x) * 0.8 + 0.01;
			float wpy = fwidth(p.y) * 0.8 + 0.01;
			float band_x = smoothstep(inner - wpx, inner + wpx, ap.x) * (1.0 - smoothstep(inner - wpy, inner + wpy, ap.y));
			float band_y = smoothstep(inner - wpy, inner + wpy, ap.y) * (1.0 - smoothstep(inner - wpx, inner + wpx, ap.x));
			float zebra_x = sq_aa(p.y / 1.3, 0.52, fwidth(p.y) / 1.3) * band_x;
			float zebra_y = sq_aa(p.x / 1.3, 0.52, fwidth(p.x) / 1.3) * band_y;
			mark += max(zebra_x, zebra_y) * 0.92;
			// stop lines just inside the zebra
			float sl_x = step(inner - 0.9, ap.x) * step(ap.x, inner - 0.5) * step(ap.y, inner) * step(0.0, ap.y - 0.0);
			float sl_y = step(inner - 0.9, ap.y) * step(ap.y, inner - 0.5) * step(ap.x, inner) * step(0.0, ap.x - 0.0);
			mark += max(sl_x * step(0.3, abs(p.y)), sl_y * step(0.3, abs(p.x))) * 0.0;
			// fade the patch edge into the road (no visible seam)
		}
	}

	float wet = wetness;
	float puddle = smoothstep(0.55, 0.8, texture(asph_a, wuv * 0.045).g) * wet;
	alb *= 1.0 - 0.38 * wet;
	vec3 mcol = mix(mark_col, vec3(0.95, 0.72, 0.1), yellow);
	float mk = clamp(mark + yellow, 0.0, 1.0) * (1.0 - 0.45 * wet) * (1.0 - far * 0.4);
	alb = mix(alb, mcol * (0.9 + 0.1 * rnd), mk);
	ALBEDO = alb;
	float rr = mix(rough * 0.95, 0.12, puddle);
	rr = mix(rr, 0.42 * rough, wet * (1.0 - puddle));
	ROUGHNESS = clamp(rr, 0.05, 1.0);
	SPECULAR = 0.35 + 0.45 * wet + 0.2 * mk;
	NORMAL_MAP = mix(nrm_tex, vec3(0.5, 0.5, 1.0), far);
	NORMAL_MAP_DEPTH = 0.9 * (1.0 - 0.6 * puddle);
	// retro-reflective paint glows slightly at night under headlights/streetlights
	EMISSION = mcol * mk * night * 0.04;
}
