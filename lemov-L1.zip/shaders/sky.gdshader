shader_type sky;

global uniform vec3 sun_dir;
global uniform float night;
global uniform float quality;

uniform vec3 zenith_col = vec3(0.16, 0.36, 0.78);
uniform vec3 horizon_col = vec3(0.68, 0.80, 0.95);
uniform vec3 ground_col = vec3(0.10, 0.12, 0.14);
uniform vec3 sun_col = vec3(1.0, 0.95, 0.85);
uniform float cloud_cover = 0.45;
uniform float cloud_dark = 0.0;
uniform float time_s = 0.0;

float hash21(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}
float hash31(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.zyx + 31.32);
	return fract((p.x + p.y) * p.z);
}
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash21(i), hash21(i + vec2(1, 0)), f.x), mix(hash21(i + vec2(0, 1)), hash21(i + vec2(1, 1)), f.x), f.y);
}
float fbm(vec2 p, int oct) {
	float a = 0.5;
	float s = 0.0;
	for (int i = 0; i < 5; i++) {
		if (i >= oct) break;
		s += a * vnoise(p);
		p = p * 2.03 + vec2(17.0, 9.0);
		a *= 0.5;
	}
	return s;
}

void sky() {
	vec3 dir = normalize(EYEDIR);
	float y = dir.y;
	vec3 sd = normalize(sun_dir);

	// base gradient
	float hz = pow(1.0 - clamp(y, 0.0, 1.0), 3.2);
	vec3 col = mix(zenith_col, horizon_col, hz);
	// warm glow around the sun in the lower sky
	float sdot = max(dot(dir, sd), 0.0);
	float glow = pow(sdot, 5.0) * (1.0 - clamp(sd.y * 1.4, 0.0, 1.0)) * 0.55;
	col += sun_col * glow * (1.0 - night);
	if (y < 0.0) {
		col = mix(horizon_col * 0.85, ground_col, smoothstep(0.0, -0.25, y));
	}

	// sun disc + halo (only while it is above the horizon)
	float sun_vis = smoothstep(-0.06, 0.04, sd.y);
	col += sun_col * (pow(sdot, 900.0) * 40.0 + pow(sdot, 40.0) * 0.55 + pow(sdot, 6.0) * 0.12) * sun_vis * (1.0 - 0.8 * cloud_cover * 0.5);

	// moon + stars
	if (night > 0.02 && y > -0.05) {
		vec3 md = normalize(vec3(-sd.x, abs(sd.y) * 0.8 + 0.25, -sd.z * 0.6 + 0.3));
		float mdot = dot(dir, md);
		float disc = smoothstep(0.99955, 0.99975, mdot);
		col += vec3(0.85, 0.9, 1.0) * disc * 2.2 * night;
		col += vec3(0.4, 0.5, 0.75) * pow(max(mdot, 0.0), 220.0) * 0.5 * night;
		vec3 sp = dir * 220.0;
		vec3 cell = floor(sp);
		float h = hash31(cell);
		vec3 fp = fract(sp) - 0.5;
		float star = step(0.9925, h) * smoothstep(0.30, 0.0, length(fp.xy + (hash31(cell + 3.1) - 0.5) * 0.4));
		float tw = 0.65 + 0.35 * sin(time_s * (1.5 + h * 4.0) + h * 40.0);
		col += vec3(0.85, 0.9, 1.0) * star * tw * night * smoothstep(0.0, 0.25, y) * 1.4;
		// faint milky band
		float band = smoothstep(0.55, 1.0, vnoise(dir.xz * 3.0 + dir.y * 5.0)) * smoothstep(0.1, 0.5, y);
		col += vec3(0.05, 0.06, 0.1) * band * night * (quality > 0.5 ? 1.0 : 0.0);
	}

	// clouds
	if (quality > 0.5 && y > 0.015 && cloud_cover > 0.02) {
		vec2 uv = dir.xz / (y + 0.22) * 0.55 + vec2(time_s * 0.004, time_s * 0.0017);
		int oct = quality > 1.5 ? 5 : 3;
		float n = fbm(uv, oct);
		float cov = 1.0 - cloud_cover * 0.78;
		float c = smoothstep(cov, cov + 0.26, n);
		// self-shadowing: sample towards the sun
		float n2 = fbm(uv + sd.xz * 0.06 / (y + 0.4), oct);
		float lit = clamp(1.15 - (n2 - n) * 5.0, 0.15, 1.2);
		vec3 base = mix(horizon_col * 0.9 + 0.12, sun_col * 1.05, clamp(sd.y * 1.3 + 0.2, 0.0, 1.0));
		vec3 ccol = base * (0.45 + 0.65 * lit) * (1.0 - 0.55 * cloud_dark);
		ccol = mix(ccol, vec3(0.03, 0.035, 0.05) + zenith_col * 0.4, night);
		float fade = smoothstep(0.015, 0.16, y);
		col = mix(col, ccol, c * fade * (0.92 - 0.25 * cloud_dark));
		// silver lining
		col += sun_col * pow(sdot, 10.0) * c * 0.22 * (1.0 - night) * (1.0 - c * 0.4);
	}

	COLOR = col;
}
