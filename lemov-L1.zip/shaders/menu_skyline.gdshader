shader_type spatial;
render_mode cull_back;
global uniform float night;
varying vec3 wp;
float h(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void vertex(){ wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment(){
	vec3 base = vec3(0.045, 0.06, 0.09);
	vec2 g = vec2((wp.x + wp.z) * 0.22, wp.y * 0.30);
	vec2 id = floor(g);
	vec2 f = fract(g);
	float win = step(0.2, f.x) * step(f.x, 0.8) * step(0.25, f.y) * step(f.y, 0.78);
	float lit = step(0.62, h(id + floor(wp.xz * 0.02)));
	vec3 warm = mix(vec3(1.0, 0.72, 0.38), vec3(0.5, 0.8, 1.0), step(0.7, h(id.yx)));
	ALBEDO = base;
	ROUGHNESS = 0.35;
	METALLIC = 0.4;
	EMISSION = warm * win * lit * 0.9;
}
