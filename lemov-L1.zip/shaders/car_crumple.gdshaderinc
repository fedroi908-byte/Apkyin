// Shared by every car shader (paint, parts, glass): zone crumple + flaps (bonnet / boot / doors).
// Car space: x = left, y = up, z = forward. Values come from CarDamage (0 = new .. 1 = destroyed).
uniform vec4 zd0 = vec4(0.0);          // front-left, front-centre, front-right, side-left
uniform vec4 zd1 = vec4(0.0);          // side-right, rear-left, rear-centre, rear-right
uniform vec4 zd2 = vec4(0.0);          // roof, underbody, burn (charring), 0
uniform vec4 zd3 = vec4(0.0);          // bonnet flap, boot flap, door-left flap, door-right flap
uniform vec3 zd_dim = vec3(1.9, 1.3, 4.6);   // body width, height, length
uniform float zd_on = 0.0;             // 0 = undamaged car: the vertex code below is skipped entirely
varying float v_crush;

// p: vertex in car space, n: its normal in car space. amt = 0..1 deformation strength (for darkening / wrinkled shading).
vec3 crumple(vec3 p, vec3 n, out float amt) {
	float hw = zd_dim.x * 0.5;
	float hl = zd_dim.z * 0.5;
	float H = zd_dim.y;
	float t = clamp(p.x / hw, -1.0, 1.0);
	float zf = t >= 0.0 ? mix(zd0.y, zd0.x, t) : mix(zd0.y, zd0.z, -t);
	float zr = t >= 0.0 ? mix(zd1.z, zd1.y, t) : mix(zd1.z, zd1.w, -t);
	float wr = 0.8 + 0.2 * sin(p.x * 5.0 + p.y * 3.0) * sin(p.z * 4.5 + p.x * 2.0);     // low frequency only: the game meshes are coarse, fine waves would tear the triangles
	float upr = smoothstep(0.35, 0.85, p.y / H);
	vec3 d = vec3(0.0);
	// bonnet flap: hinged at the windscreen base, flung up and back
	if (zd3.x > 0.01) {
		float a = zd3.x * 1.1;
		float m = smoothstep(0.10 * zd_dim.z, 0.16 * zd_dim.z, p.z) * smoothstep(0.42, 0.62, p.y / H) * smoothstep(0.35, 0.65, n.y) * (1.0 - smoothstep(0.40 * zd_dim.x, 0.47 * zd_dim.x, abs(p.x)));
		vec3 q = p - vec3(0.0, 0.62 * H, 0.14 * zd_dim.z);
		vec3 r = vec3(q.x, q.y * cos(a) + q.z * sin(a), -q.y * sin(a) + q.z * cos(a));
		d += (r - q) * m;
	}
	// boot flap
	if (zd3.y > 0.01) {
		float a = zd3.y * 0.9;
		float m = smoothstep(-0.16 * zd_dim.z, -0.22 * zd_dim.z, p.z) * smoothstep(0.42, 0.62, p.y / H) * smoothstep(0.35, 0.65, n.y) * (1.0 - smoothstep(0.40 * zd_dim.x, 0.47 * zd_dim.x, abs(p.x)));
		vec3 q = p - vec3(0.0, 0.62 * H, -0.18 * zd_dim.z);
		vec3 r = vec3(q.x, q.y * cos(a) - q.z * sin(a), q.y * sin(a) + q.z * cos(a));
		d += (r - q) * m;
	}
	// doors: hinged at the front edge, swung outward
	for (int k = 0; k < 2; k++) {
		float sd = k == 0 ? 1.0 : -1.0;
		float ang = (k == 0 ? zd3.z : zd3.w) * 0.95;
		if (ang > 0.01) {
			float px = p.x * sd;
			float m = smoothstep(0.34 * zd_dim.x, 0.44 * zd_dim.x, px) * smoothstep(0.26, 0.34, p.y / H) * (1.0 - smoothstep(0.70, 0.78, p.y / H)) * (1.0 - smoothstep(0.17 * zd_dim.z, 0.23 * zd_dim.z, p.z)) * smoothstep(-0.16 * zd_dim.z, -0.10 * zd_dim.z, p.z);
			vec3 q = vec3(px - 0.47 * zd_dim.x, p.y, p.z - 0.20 * zd_dim.z);
			vec3 r = vec3(q.x * cos(ang) - q.z * sin(ang), q.y, q.x * sin(ang) + q.z * cos(ang));
			vec3 dd = (r - q) * m;
			d += vec3(dd.x * sd, dd.y, dd.z);
		}
	}
	// front end: the nose shortens, the bonnet folds up in waves, the wings splay out
	float ef = smoothstep(hl - 1.7, hl, p.z);
	d.z -= zf * 0.85 * ef * ef * wr;
	d.y += zf * 0.28 * ef * upr * (0.55 + 0.45 * sin((hl - p.z) * 5.5));
	d.x += sign(p.x) * zf * 0.07 * ef * wr;
	// rear end
	float er = smoothstep(hl - 1.4, hl, -p.z);
	d.z += zr * 0.7 * er * er * wr;
	d.y += zr * 0.2 * er * upr * (0.55 + 0.45 * sin((hl + p.z) * 5.5));
	// sides: the door skins fold inward, strongest at the middle of the car
	float em = exp(-p.z * p.z / (zd_dim.z * zd_dim.z * 0.09));
	d.x -= smoothstep(0.45 * hw, hw, p.x) * zd0.w * 0.42 * em * wr;
	d.x += smoothstep(0.45 * hw, hw, -p.x) * zd1.x * 0.42 * em * wr;
	// roof pushed down
	d.y -= zd2.x * 0.34 * smoothstep(0.55 * H, 0.95 * H, p.y) * wr;
	amt = clamp(length(d) * 2.2, 0.0, 1.0);
	return d;
}
